#include "bitmap.h"
#include "stdlib.h"
#include "stdio.h"
#include"os_constant.h"


ListItem* BitMap::allocatelist()
{
    for (int i = 0; i < 50; ++i)
    {
        if (!LIST_SET_STATUS[i])
        {
            LIST_SET_STATUS[i] = true;
            return (ListItem *)((int)LIST_SET + LIST_SIZE * i);
        }
    }
}
void BitMap::releaseLIST(ListItem *list)
{
    int index = ((int)list - (int)LIST_SET) / LIST_SIZE;
    LIST_SET_STATUS[index] = false;
}

BitMap::BitMap()
{
}

void BitMap::initialize(char *bitmap, const int length)
{
    this->bitmap = bitmap;
    this->length = length;

    int bytes = ceil(length, 8);

    for (int i = 0; i < bytes; ++i)
    {
        bitmap[i] = 0;
    }
    
    for (int i = 0; i < MAX_LIST_AMOUNT; ++i)
    {
        LIST_SET_STATUS[i] = false;
    }
    ListItem* p=allocatelist();
    memset(p, 0, sizeof(struct ListItem));
    p->index=0;
    p->len=length;
    this->freelist.push_back(p);
}

bool BitMap::get(const int index) const
{
    int pos = index / 8;
    int offset = index % 8;

    return (bitmap[pos] & (1 << offset));
}

void BitMap::set(const int index, const bool status)
{
    int pos = index / 8;
    int offset = index % 8;

    // 清0
    bitmap[pos] = bitmap[pos] & (~(1 << offset));

    // 置1
    if (status)
    {
        bitmap[pos] = bitmap[pos] | (1 << offset);
    }
}

int BitMap::allocate(const int count)
{
    if (count == 0)return -1;
    int start=0;
    ListItem* temp = freelist.head.next;
   temp = freelist.head.next;
    while(temp){
        printf("temp=%d  ",temp->len);
        if(temp->len >= count){
            start=temp->index;
            ListItem* p=allocatelist();
            memset(p, 0, sizeof(struct ListItem));
            p->index=temp->index+count;
            p->len=temp->len-count;
            freelist.erase(temp);
            releaseLIST(temp);
            if(temp->len-count>0){
            ListItem* t = freelist.head.next; 
            int i=1;   
            while(t&&t->len < p->len){ 
                t=t->next;
                i+=1;
            }
            if(t){freelist.insert(i, p);}
            else{freelist.push_back(p);}
            }
            for (int i = 0; i < count; ++i)
            {
                set(start + i, true);
            }
            return start;
        }else{
            temp=temp->next;
        }
    }
    return -1;
}

void BitMap::release(const int index, const int count)
{
    for (int i = 0; i < count; ++i)
    {
        set(index + i, false);
    }
    ListItem* p=allocatelist();
    memset(p, 0, sizeof(struct ListItem));
    p->index=index;
    p->len=count;
    ListItem* t = freelist.head.next; 
    int i=0;   
    while(t&&t->len < p->len){ 
        printf("t=%d ",t->len);
        t=t->next;
        i+=1;
    }
    if(t){freelist.insert(i, p);}
    else{freelist.push_back(p);}
    }

char *BitMap::getBitmap()
{
    return (char *)bitmap;
}

int BitMap::size() const
{
    return length;
}

