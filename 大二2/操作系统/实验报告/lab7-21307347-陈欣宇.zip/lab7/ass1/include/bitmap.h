#ifndef BITMAP_H
#define BITMAP_H

#include "os_type.h"

class BitMap
{
public:
    int length;
    char *bitmap;
public:
    BitMap();
    void initialize(char *bitmap, const int length);
    bool get(const int index) const; // true=allocated，false=free
    void set(const int index, const bool status);// 设置第index个资源true=allocated，false=free
    int allocate(const int count); // 分配count个连续的资源，若没有则返回-1，否则返回分配的第1个资源单元序号
    void release(const int index, const int count);// 释放第index个资源开始的count个资源
    char *getBitmap();
    int size() const;
private:  // 禁止Bitmap之间的赋值
    BitMap(const BitMap &) {}
    void operator=(const BitMap&) {}
};

#endif