import os          
import subprocess   
import shutil

while True:
    current_dir = os.getcwd()
    print(f'{current_dir}>', end='')# 显示命令提示符
    
    user_input = input()# 获取用户输入的命令

    # 解析命令和参数
    command_parts = user_input.split()
    command = command_parts[0]
    args = command_parts[1:]
    strs = user_input[len(command)+1:len(user_input)]

    if command == 'cd':# 改变当前工作目录
        if len(args) == 0: # 没有提供目标目录，则切换到用户目录
            os.chdir(os.path.expanduser("~"))
        else:
            try:
                os.chdir(args[0])
            except FileNotFoundError:
                print(f"cd: no such file or directory: {args[0]}")
            except NotADirectoryError:
                print(f"cd: not a directory: {args[0]}")
        continue

    if command == 'pwd':# 显示当前工作目录
        print(os.getcwd())
        continue

    if command == 'ls': # 列出当前目录的内容
        result = subprocess.run(["cmd", "/c", "dir"], capture_output=True, text=True)
        print(result.stdout)
        continue


    if command == 'cat':# 显示文件内容
        if len(args) == 0:
            print("cat: missing operand")
        else:
            for file in args:
                try:
                    with open(file, 'r') as f:
                        content = f.read()
                        print(content)
                except FileNotFoundError:
                    print(f"cat: no such file or directory: {file}")
                except IsADirectoryError:
                    print(f"cat: Is a directory: {file}")
        continue

    if command == 'echo':# 显示文本
        if len(args) == 0:
            print("echo: missing operand")
        else:
            print(strs)
        continue

    if command == 'rm':# 删除文件
        if len(args) == 0:
            print("rm: missing operand")
        else:
            for file in args:
                try:
                    os.remove(file)
                except FileNotFoundError:
                    print(f"rm: no such file or directory: {file}")
                except IsADirectoryError:
                    print(f"rm: Is a directory: {file}")
        continue

    if command == 'cp': # 复制文件
        if len(args) < 2:
            print("cp: missing operand")
        else:
            try:
                shutil.copy2(args[0], args[1])
                print(f"File '{args[0]}' copied to '{args[1]}'")
            except FileNotFoundError:
                print(f"cp: no such file or directory: {args[0]}")
            except IsADirectoryError:
                print(f"cp: Is a directory: {args[0]}")
        continue

    if command == 'mv':# 移动/重命名文件
        if len(args) < 2:
            print("mv: missing operand")
        else:
            try:
                shutil.move(args[0], args[1])
                print(f"File '{args[0]}' moved to '{args[1]}'")
            except FileNotFoundError:
                print(f"mv: no such file or directory: {args[0]}")
            except IsADirectoryError:
                print(f"mv: Is a directory: {args[0]}")
        continue

    if command == 'mkdir':# 创建目录
        if len(args) == 0:
            print("mkdir: missing operand")
        else:
            for directory in args:
                try:
                    os.mkdir(directory)
                    print(f"Directory '{directory}' created")
                except FileExistsError:
                    print(f"mkdir: cannot create directory '{directory}': File exists")
        continue

    if command == 'touch':
        # 创建空文件或更新文件的访问时间和修改时间
        if len(args) == 0:
            print("touch: missing operand")
        else:
            for file in args:
                try:
                    with open(file, 'a'):
                        os.utime(file, None)
                    print(f"File '{file}' created")
                except IsADirectoryError:
                    print(f"touch: cannot touch '{file}': Is a directory")
        continue

    if command == 'exit':# 退出Shell
        break

    print('No instructions exist for the time being')
