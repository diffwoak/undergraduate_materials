import torch
import numpy as np

t1 = [1, 2, 3]
np_array = np.array(t1)
data = torch.from_numpy(np_array)
print(data)
t2=torch.zeros([8,2,10])
#t2[0][1][8]+=0.5
Cy  = torch.zeros(2)
print(Cy)