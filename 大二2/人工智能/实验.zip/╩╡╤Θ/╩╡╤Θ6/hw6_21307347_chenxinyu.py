"""
第5次作业, 用遗传算法解决TSP问题
本次作业可使用`numpy`库和`matplotlib`库以及python标准库
请不要修改类名和方法名
"""
import torch
import numpy as np
import copy
import pandas as pd
from random import *
def ranlist(n):   #生成随机排序
    la = [i for i in range(n) ]
    shuffle(la)
    return la
class wisconsin:
    def __init__(self, train_filename):
        train = pd.read_csv(train_filename, sep=",", skiprows=0, header=None)
        self.n=len(train[0]) #存在EOF
        n=self.n
        self.Cy  = torch.zeros(2)
        self.Cxy = torch.zeros([9,2,10])
        for i in range(n):
            ty=0
            if train[10][i]==2:
                self.Cy[0]+=1
            else:
                self.Cy[1]+=1
                ty=1
            j=1
            while j<10:
                self.Cxy[j-1][ty][int(train[j][i])-1]+=1
                j+=1
        for i in range(9):
            for j in range(2):
                for k in range(10):
                    self.Cxy[i][j][k]=(self.Cxy[i][j][k]+1)/(self.Cy[j]+10)
        print("Cxy:  "+str(self.Cxy))
        for j in range(2):
            self.Cy[j]=(self.Cy[j]+1)/(n+2)
        #print("Cy:  "+str(self.Cy))
    def testres(self,test_file):
        test = pd.read_csv(test_file, sep=",", skiprows=0, header=None)
        res=[]
        for i in range(len(test[0])):
            c=[]
            j=0
            while j<=10:
                c.append(test[j][i])
                j+=1
            #res.append(self.oneres(c))
            x , y , z=self.oneres(c)
            res.append(z)
            print("p1="+str(x)+"  p2="+str(y))
        return res
    def oneres(self,line):
        p1,p2=1,1
        ty=0
        if line[10]==2:
            p1*=self.Cy[0]
            p2*=self.Cy[1]
        else : 
            p1*=self.Cy[1]
            p2*=self.Cy[0]
            ty=1
        j = 1
        while j<10:
            p1*=(self.Cxy[j-1][ty][int(line[j])-1])
            p2*=(self.Cxy[j-1][1-ty][int(line[j])-1])
            j+=1
        if p1>p2:return p1,p2,True
        else : return p1,p2,False
if __name__ == "__main__":
    wis=wisconsin("breast-cancer-wisconsin-train.data") #汇入训练集
    res = wis.testres("breast-cancer-wisconsin-test.data") #测试集结果返回 
    print(res)

