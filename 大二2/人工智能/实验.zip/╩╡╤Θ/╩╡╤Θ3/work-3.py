import copy
from operator import add
from functools import reduce
class step:
    def __init__(self,n,ff1=0,ff2=0,ss=[]) -> None:
        self.num=n
        self.f1=ff1
        self.f2=ff2
        self.s=list(ss)
    def remov(self,l):
        if l in self.s:
            self.s.remove(l)
def judge(x):#判断是变量、常量还是函数
    var=['xx','yy','zz','uu','vv','ww']
    if x in var:
        return 1
    elif len(x)==1:
        return 2
    else: 
        return 3
def change(f,t2,t1):
    for i in range(len(f)):
        if f[i]==t2:
            f[i]=t1
        elif judge(f[i])==3 and t2 in f[i]:
            f[i]=f[i].replace(t2,t1) 
    return
def MGU(f1, f2):
    """
    :param f1: str
    :param f2: str
    :return: dict
    """
    d={}
    i=0
    while f1[i]!='(':
        i+=1
    if f1[0:i+1]!=f2[0:i+1]:
        return {}
    t1=f1[i+1:len(f1)-1].replace(',',' ').split()
    t2=f2[i+1:len(f2)-1].replace(',',' ').split()
    n=len(t1)    
    stk=[]
    for i in range(n):
        if t1==t2 and stk==[]:
            return d
        if judge(t1[i])==1 and judge(t2[i])==1:#1都是变量
            change(t2,t2[i],t1[i])
            stk.append(t1[i])
        elif judge(t1[i])==1:#2变量+常量或函数
            d[t1[i]]=t2[i]
            change(t1,t1[i],t2[i])
            if t1[i] in stk:
                stk.remove(t1[i])
        elif judge(t2[i])==1:
            d[t2[i]]=t1[i]
            change(t2,t2[i],t1[i])
            if t2[i] in stk:
                stk.remove(t2[i])
        elif judge(t1[i])+judge(t2[i])==5: #3常量+函数
            return {}
        elif judge(t1[i])+judge(t2[i])==4: #4都是常量
            if t1[i]!=t2[i]:
                return {}
        elif judge(t1[i])+judge(t2[i])==6:#5都是函数
            g1,g2=list(t1[i]),list(t2[i])
            while g1[0]==g2[0]:
                if g1[0]=='(':
                    g1.pop()
                    g2.pop()
                del g1[0]
                del g2[0]
            g1,g2="".join(g1),"".join(g2)
            if g1==g2:
                continue
            elif judge(g1)+judge(g2)==2:#都是变量
                change(t2,g2,g1)
                stk.append(g1)
            elif judge(g1)==1:#变量+常量或函数
                d[g1]=g2
                change(t1,g1,g2)
                if g1 in stk:
                    stk.remove(g1)
            elif judge(g2)==1:
                d[g2]=g1
                change(t2,g2,g1)
                if g2 in stk:
                    stk.remove(g2)
            elif judge(g1)+judge(g2)>=4:
                return {}
        if stk!=[]:
            return {}
    return d
def opp(c):
    if '~' in c:
        return c.replace('~','')
    else:
        return '~'+c

def ResolutionFOL(KB):
    """
    :param KB: set(tuple(str))
    :return: list[str]
    """
    a=[]
    res=[]
    cou=0
    for tu in KB:
        cou+=1
        t=step(cou,0,0,tu)
        a.append(t)        
        ss=str(cou)+" ("
        n=len(tu)
        for i in range(n):
            ss+="'"+tu[i]+"'"
            if i==0 or i<n-1:
                ss+=","
        ss+=")"
        res.append(ss)
        print(ss)##########333
    done=[]#用于记录已经归结的步骤，避免重复
    for i in range(len(a)+1):
        done.append([])   
    end=False
    while True:
        if end: break
        if a==[]:
            end=True
        else:
            aa=0
            while aa<len(a):
                fa=copy.deepcopy(a[aa])
                aa+=1
                for i in fa.s:
                    if end: break
                    for mot in a[:]:
                        mo=copy.deepcopy(mot)
                        if end: break
                        if mo.num==fa.num or fa.num in done[mo.num]:continue
                        #改为相反且存在字典j= list(filter(lambda c:c==opp(i),mo.s))
                        j= list(filter(lambda c:MGU(c,opp(i))!={}or c==opp(i),mo.s))
                        if j==[]:continue
                        else:
                            d=MGU(j[0],opp(i))
                            cou+=1
                            x=fa.num
                            y=mo.num
                            fa.remov(i)
                            mos=copy.deepcopy(mo.s)
                            mos.remove(j[0])
                            if d!={}:
                                for p in range(len(fa.s)):
                                    for key in d:
                                        if key in fa.s[p]:
                                            fa.s[p]=fa.s[p].replace(key,d[key])
                                for p in range(len(mos)):
                                    for key in d:
                                        if key in mos[p]:
                                            mos[p]=mos[p].replace(key,d[key])
                            ss=reduce(add,(fa.s,mos))#合并列表
                            t=step(cou,x,y,ss)
                            a.append(t)
                            done[x].append(y)
                            done.append([])
                            #加入res
                            st=str(cou)+" R["+str(x)+","+str(y)+"]{"
                            kk=0
                            for key in d:
                                if kk!=0:
                                    st+=","
                                st+=key+"="+d[key]
                                kk+=1
                            st+="}: ("
                            n=len(ss)
                            for ii in range(n):
                                st+="'"+ss[ii]+"'"
                                if ii==0 or ii<n-1:
                                    st+=","
                            st+=")"
                            res.append(st)
                            print(st)########
                            #添加完毕
                            if fa.s==[] and mos==[]:
                                end=True
                        
    #输出优化
    """
    n=len(res)
    tep=res.pop()
    ma=n-y-1
    le=tep.split()
    tep=str(n-ma)+tep[len(le[0]):len(tep)]
    while ma>0:
        res.pop()
        ma-=1
    res.append(tep)
    """
    return res


if __name__ == '__main__':
    KB2 = {('On(a,b)',), ('On(b,c)',), ('Green(a)',), ('~Green(c)',), ('~On(xx,yy)', '~Green(xx)', 'Green(yy)')}
    result2 = ResolutionFOL(KB2)
    for r in result2:
        print(r)
"""
已有实现：
1命题逻辑的归结:返回输出
2最一般合一算法:返回可行的字典
目标：一阶逻辑的归结
步骤：
主要在归结中进行：修改命题逻辑归结的具体实现
修改：
在opp中 加入 最一般合一(改函数名避免重复)
在归结输出中 加入 {xx=a}即对应的字典


过程出现问题：
前面的用完就删，后面需要与前面归结时找不到
解决方式：
建立列表记录已归结的步骤
每次归结的步骤排除自身、已经归结的(不必删除)
"""