"""
第3次作业, 请不要修改输入输出的数据类型和格式
"""
import copy
from operator import add
from functools import reduce
class step:
    def __init__(self,n,ff1=0,ff2=0,ss=[],dd={}) -> None:
        self.num=n
        self.f1=ff1
        self.f2=ff2
        self.s=list(ss)
        self.d=copy.deepcopy(dd)
    def remov(self,l):
        if l in self.s:
            self.s.remove(l)
            
def opp(c):#用于ResolutionProp或ResolutionFOL
    if '~' in c:
        return c.replace('~','')
    else:
        return '~'+c
def addres1(res,a,bas):#a列表记录步骤，res为提取步骤，用于ResolutionProp
    n=len(a)  
    cho=[False]
    cha=[0]
    for i in range(n):
        if i<bas:
            cho.append(True)
        else:cho.append(False)
        cha.append(i+1)
    i=n
    cho[n]=True
    while i>bas :
        if cho[i]==True:
            cho[a[i-1].f1]=True
            cho[a[i-1].f2]=True
        i-=1
    i=bas+1
    cou=bas+1
    while i<=n:
        if cho[i]==True:
            cha[a[i-1].num]=cou
            a[i-1].num=cou
            a[i-1].f1=cha[a[i-1].f1]
            a[i-1].f2=cha[a[i-1].f2]
            #加入res
            st=str(cou)+" R["+str(a[i-1].f1)+","+str(a[i-1].f2)+"]: ("
            ss=a[i-1].s
            nn=len(ss)
            for ii in range(nn):
                st+="'"+ss[ii]+"'"
                if ii==0 or ii<n-1:
                    st+=","
            st+=")"
            res.append(st)
            #添加完毕
            cou+=1
        i+=1

def judge(x):#判断是变量、常量还是函数,用于MGU
    var=['xx','yy','zz','uu','vv','ww']
    if x in var:
        return 1
    elif len(x)==1:
        return 2
    else: 
        return 3
def change(f,t2,t1):#用于MGU
    for i in range(len(f)):
        if f[i]==t2:
            f[i]=t1
        elif judge(f[i])==3 and t2 in f[i]:
            f[i]=f[i].replace(t2,t1) 


def addres2(res,a,bas):#用于ResolutionFOL
    n=len(a)  
    cho=[False]
    cha=[0]
    for i in range(n):
        if i<bas:
            cho.append(True)
        else:cho.append(False)
        cha.append(i+1)
    i=n
    cho[n]=True
    while i>bas :
        if cho[i]==True:
            cho[a[i-1].f1]=True
            cho[a[i-1].f2]=True
        i-=1
    i=bas+1
    cou=bas+1
    while i<=n:
        if cho[i]==True:
            cha[a[i-1].num]=cou
            a[i-1].num=cou
            a[i-1].f1=cha[a[i-1].f1]
            a[i-1].f2=cha[a[i-1].f2]
            #加入res
            st=str(cou)+" R["+str(a[i-1].f1)+","+str(a[i-1].f2)+"]{"
            ss=a[i-1].s
            kk=0
            for key in a[i-1].d:
                if kk!=0:
                    st+=","
                st+=key+"="+a[i-1].d[key]
                kk+=1
            st+="}: ("
            nn=len(ss)
            for ii in range(nn):
                st+="'"+ss[ii]+"'"
                if ii==0 or ii<n-1:
                    st+=","
            st+=")"
            res.append(st)
            #添加完毕
            cou+=1
        i+=1
def novar(c):#用于ResolutionFOL
    var=['xx','yy','zz','uu','vv','ww']
    for i in var:
        if i in c:
            return False
    return True


def ResolutionProp(KB):
    a=[]
    res=[]
    done=[] # 记录已有 归结 操作，避免重复
    done.append([])
    cou=0 #第几步
    for tu in KB:
        cou+=1 
        a.append(step(cou,0,0,tu))
        ss=str(cou)+" ("#填入res  
        for i in range(len(tu)):
            ss+="'"+tu[i]+"'"
            if i==0 or i<len(tu)-1:
                ss+=","
        ss+=")"
        res.append(ss)#填完
        done.append([])
    bas=cou  
    end=False
    aa=0
    while aa<len(a):
        fa=copy.deepcopy(a[aa])
        aa+=1
        for i in fa.s:
            if end: break
            if novar(i)==False:continue
            for mot in a:
                if end: break
                mo=copy.deepcopy(mot)
                if mo.num==fa.num or fa.num in done[mo.num]:continue
                j= list(filter(lambda c:c==opp(i),mo.s))#得到s中与i相反的元素
                if j==[]:continue
                else:
                    cou+=1
                    #faa=step(fa.num,fa.f1,fa.f2,fa.s,fa.d)
                    faa=copy.deepcopy(fa)
                    faa.remov(i)
                    mos=copy.deepcopy(mo.s)
                    mos.remove(j[0])
                    ss=reduce(add,(faa.s,mos))#合并列表
                    x,y=fa.num,mo.num
                    if x>y: x,y=y,x
                    a.append(step(cou,x,y,ss))
                    done.append([])
                    done[x].append(y)
                    done[y].append(x)
                    if faa.s==[] and mos==[]:
                        end=True
    addres1(res,a,bas)
    return res


def MGU(f1, f2):
    d={}
    i=0
    while f1[i]!='(':
        i+=1
    if f1[0:i+1]!=f2[0:i+1]:
        return {}
    t1=f1[i+1:len(f1)-1].replace(',',' ').split()
    t2=f2[i+1:len(f2)-1].replace(',',' ').split()
    n=len(t1)
    stk=[]
    for i in range(n):
        if t1==t2 and stk==[]:
            return d
        if judge(t1[i])==1 and judge(t2[i])==1:#1都是变量
            change(t2,t2[i],t1[i])
            stk.append(t1[i])
        elif judge(t1[i])==1:#2变量+ 常量或函数
            d[t1[i]]=t2[i]
            change(t1,t1[i],t2[i])
            if t1[i] in stk:
                stk.remove(t1[i])
        elif judge(t2[i])==1:
            d[t2[i]]=t1[i]
            change(t2,t2[i],t1[i])
            if t2[i] in stk:
                stk.remove(t2[i])
        elif judge(t1[i])+judge(t2[i])==5: #3常量+函数
            return {}
        elif judge(t1[i])+judge(t2[i])==4: #4都是常量
            if t1[i]!=t2[i]:
                return {}
        elif judge(t1[i])+judge(t2[i])==6:#5都是函数
            if t1[i]==t2[i]:continue
            g1,g2=list(t1[i]),list(t2[i])
            while g1[0]==g2[0]:
                if g1[0]=='(':
                    g1.pop()
                    g2.pop()
                del g1[0]
                del g2[0]
            g1,g2="".join(g1),"".join(g2)
            if judge(g1)+judge(g2)==2:#都是变量
                change(t2,g2,g1)
                stk.append(g1)
            elif judge(g1)==1:#变量+ 常量或函数
                d[g1]=g2
                change(t1,g1,g2)
                if g1 in stk:
                    stk.remove(g1)
            elif judge(g2)==1:
                d[g2]=g1
                change(t2,g2,g1)
                if g2 in stk:
                    stk.remove(g2)
            elif judge(g1)+judge(g2)>=4:
                return {}
    if stk!=[]:
        return {}
    return d


def ResolutionFOL(KB):
    """
    :param KB: set(tuple(str))
    :return: list[str]
    """
    a=[]
    res=[]
    done=[]#用于记录已经归结的步骤，避免重复
    done.append([])   
    cou=0
    for tu in KB:
        cou+=1
        a.append(step(cou,0,0,tu))        
        ss=str(cou)+" ("#填入
        for i in range(len(tu)):
            ss+="'"+tu[i]+"'"
            if i==0 or i<len(tu)-1:
                ss+=","
        ss+=")"
        res.append(ss)#填完
        done.append([])   
    bas=cou
    end=False
    aa=0
    while aa<len(a):
        if end: break
        #fa=step(a[aa].num,a[aa].f1,a[aa].f2,a[aa].s,a[aa].d)
        fa=copy.deepcopy(a[aa])
        aa+=1
        for i in fa.s:
            if end: break
            if novar(i)==False:continue
            for mo in a:
                if end: break
                #mo=copy.deepcopy(a[bb])
                #mo=step(a[bb].num,a[bb].f1,a[bb].f2,a[bb].s,a[bb].d)
                #bb+=1
            #for mot in a[:]:
                #mo=copy.deepcopy(mot)
                if mo.num==fa.num or fa.num in done[mo.num] or mo.num in done[fa.num]:continue #改为相反且存在字典
                j= list(filter(lambda c:(MGU(c,opp(i))!={} or (c==opp(i)and novar(c))),mo.s))
                if j==[]:continue
                else:
                    d=MGU(j[0],opp(i))
                    #print(str(cou))###
                    cou+=1
                    x,y=fa.num,mo.num
                    if y<x:x,y=y,x
                    #faa=step(a[aa].num,a[aa].f1,a[aa].f2,a[aa].s,a[aa].d)
                    faa=copy.deepcopy(fa)
                    faa.remov(i)
                    mos=copy.deepcopy(mo.s)
                    mos.remove(j[0])
                    if d!={}:
                        for p in range(len(faa.s)):
                            for key in d:
                                if key in faa.s[p]:
                                    faa.s[p]=faa.s[p].replace(key,d[key])
                        for p in range(len(mos)):
                            for key in d:
                                if key in mos[p]:
                                    mos[p]=mos[p].replace(key,d[key])
                    ss=reduce(add,(faa.s,mos))#合并列表
                    a.append(step(cou,x,y,ss,d))
                    done[x].append(y)
                    done[y].append(x)
                    done.append([])
                    if faa.s==[] and mos==[]:
                        end=True
    addres2(res,a,bas)
    return res


if __name__ == '__main__':
    # 测试程序
    KB1 = {('FirstGrade',), ('~FirstGrade', 'Child'), ('~Child',)}
    result1 = ResolutionProp(KB1)
    for r in result1:
        print(r)   

    print(MGU('P(xx,a)', 'P(b,yy)'))
    print(MGU('P(a,xx,f(g(yy)))', 'P(zz,f(zz),f(uu))'))
    
    KB2 = {('On(a,b)',), ('On(b,c)',), ('Green(a)',), ('~Green(c)',), ('~On(xx,yy)', '~Green(xx)', 'Green(yy)')}
    result2 = ResolutionFOL(KB2)
    for r in result2:
        print(r)
    
