import copy
from operator import add
from functools import reduce
class step:
    def __init__(self,n,ff1=0,ff2=0,ss=[]) -> None:
        self.num=n
        self.f1=ff1
        self.f2=ff2
        self.s=list(ss)
    def remov(self,l):
        if l in self.s:
            self.s.remove(l)
def opp(c):
    if '~' in c:
        return c.replace('~','')
    else:
        return '~'+c
def ResolutionProp(KB):
    """
    :param KB: set(tuple(str))
    :return: list[str]
    """
    a=[]
    res=[]
    cou=0
    for tu in KB:
        cou+=1
        t=step(cou,0,0,tu)
        a.append(t)        
        ss=str(cou)+" ("
        n=len(tu)
        for i in range(n):
            ss+="'"+tu[i]+"'"
            if i==0 or i<n-1:
                ss+=","
        ss+=")"
        res.append(ss)
        
    end=False
    while True:
        if end: break
        if a==[]:
            end=True
        else:
            fa=a[0]
            del a[0]
        for i in fa.s:
            if end: break
            for mo in a[:]:
                if end: break
                j= list(filter(lambda c:c==opp(i),mo.s))
                if j==[]:continue
                else:
                    cou+=1
                    x=fa.num
                    y=mo.num#
                    fa.remov(i)
                    mos=copy.deepcopy(mo.s)
                    mos.remove(j[0])
                    ss=reduce(add,(fa.s,mos))#合并列表
                    t=step(cou,x,y,ss)
                    a.append(t)
                    #加入res
                    st=str(cou)+" R["+str(x)+","+str(y)+"]: ("
                    n=len(ss)
                    for ii in range(n):
                        st+="'"+ss[ii]+"'"
                        if ii==0 or ii<n-1:
                            st+=","
                    st+=")"
                    res.append(st)
                    #添加完毕
                    if fa.s==[] and mos==[]:
                        end=True
                        
    #输出优化
    """
    n=len(res)
    tep=res.pop()
    ma=n-y-1
    le=tep.split()
    tep=str(n-ma)+tep[len(le[0]):len(tep)]
    while ma>0:
        res.pop()
        ma-=1
    res.append(tep)
    """
    return res

if __name__ == '__main__':
    # 测试程序
    KB1 = {('FirstGrade',), ('~FirstGrade', 'Child'), ('~Child',),("fir","Child"),("~fir",)}
    result1 = ResolutionProp(KB1)
    for r in result1:
        print(r)