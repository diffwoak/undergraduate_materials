def judge(x):#判断是变量、常量还是函数
    var=['xx','yy','zz','uu','vv','ww']
    if x in var:
        return 1
    elif len(x)==1:
        return 2
    else: 
        return 3
def change(f,t2,t1):
    for i in range(len(f)):
        if f[i]==t2:
            f[i]=t1
        elif judge(f[i])==3 and t2 in f[i]:
            f[i]=f[i].replace(t2,t1) 
    return
def MGU(f1, f2):
    """
    :param f1: str
    :param f2: str
    :return: dict
    """
    d={}
    i=0
    while f1[i]!='(':
        i+=1
    if f1[0:i+1]!=f2[0:i+1]:
        return {}
    t1=f1[i+1:len(f1)-1].replace(',',' ').split()
    t2=f2[i+1:len(f2)-1].replace(',',' ').split()
    n=len(t1)    
    stk=[]
    for i in range(n):
        if t1==t2 and stk==[]:
            return d
        if judge(t1[i])==1 and judge(t2[i])==1:#1都是变量
            change(t2,t2[i],t1[i])
            stk.append(t1[i])
        elif judge(t1[i])==1:#2变量+常量或函数
            d[t1[i]]=t2[i]
            change(t1,t1[i],t2[i])
            if t1[i] in stk:
                stk.remove(t1[i])
        elif judge(t2[i])==1:
            d[t2[i]]=t1[i]
            change(t2,t2[i],t1[i])
            if t2[i] in stk:
                stk.remove(t2[i])
        elif judge(t1[i])+judge(t2[i])==5: #3常量+函数
            return {}
        elif judge(t1[i])+judge(t2[i])==4: #4都是常量
            if t1[i]!=t2[i]:
                return {}
        elif judge(t1[i])+judge(t2[i])==6:#5都是函数
            g1,g2=list(t1[i]),list(t2[i])
            while g1[0]==g2[0]:
                if g1[0]=='(':
                    g1.pop()
                    g2.pop()
                del g1[0]
                del g2[0]
            g1,g2="".join(g1),"".join(g2)
            if g1==g2:
                continue
            elif judge(g1)+judge(g2)==2:#都是变量
                change(t2,g2,g1)
                stk.append(g1)
            elif judge(g1)==1:#变量+常量或函数
                d[g1]=g2
                change(t1,g1,g2)
                if g1 in stk:
                    stk.remove(g1)
            elif judge(g2)==1:
                d[g2]=g1
                change(t2,g2,g1)
                if g2 in stk:
                    stk.remove(g2)
            elif judge(g1)+judge(g2)>=4:
                return {}
        if stk!=[]:
            return {}
    return d

if __name__ == '__main__':
    print(MGU('P(xx,a)', 'P(b,yy)'))
    print(MGU('P(a,xx,f(g(yy)))', 'P(zz,f(zz),f(uu))'))