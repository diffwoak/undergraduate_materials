def BinarySearch(nums, target):
    """
    :param nums: list[int]
    :param target: int
    :return: int
    """
    n=len(nums)
    l, r = 0, n-1
    while l<r:
        mid=(l+r)>>1
        if nums[mid]==target:
            return mid
        if nums[mid]<target:
            l=mid+1
        elif nums[mid]>target:
            r=mid-1
    return -1
def MatrixAdd(A, B):
    """
    :param A: list[list[int]]
    :param B: list[list[int]]
    :return: list[list[int]]
    """
    n= len(A)
    s=[]
    for i in range(n):
        s.append([])
        for j in range(n):
            s[i].append(A[i][j]+B[i][j])
    return s
def MatrixMul(A, B):
    """
    :param A: list[list[int]]
    :param B: list[list[int]]
    :return: list[list[int]]
    """
    n= len(A)
    s=[]
    for i in range(n):
        s.append([])
        for j in range(n):
            ans=0
            for k in range(n):
                ans+=(A[i][k]*B[k][j])
            s[i].append(ans)
    return s
def ReverseKeyValue(dict1):
    """
    :param dict1: dict
    :return: dict
    """
    d={}
    for key in dict1:
        d[dict1[key]]=key
    return d


if __name__ == "__main__":
    print("输出", BinarySearch([-1, 0, 3, 5, 9, 12], 9), "答案", 4)
    print("输出", MatrixAdd([[1,0],[0,1]], [[1,2],[3,4]]), "答案", [[2, 2], [3, 5]])
    print("输出", MatrixMul([[1,0],[0,1]], [[1,2],[3,4]]), "答案", [[1, 2], [3, 4]])
    print("输出", ReverseKeyValue({'Alice':'001', 'Bob':'002'}), "答案", {'001':'Alice', '002':'Bob'})