import pandas as pd
import numpy as np
from pprint import pprint

from math import log
import matplotlib.pyplot as plt
# 代码功能：计算香农熵
#我们要用到对数函数，所以我们需要引入math模块中定义好的log函数（对数函数）
import trees
import treePlotter

def train_test_prune_split(df, train_size, test_size):
    train_size = round(train_size * len(df))
    test_size = round(test_size * len(df))
    post_prune_size = len(df) - train_size - test_size
    
    # Using random sampling to split the data
    np.random.seed(10)
    shuffled_indices = np.random.permutation(len(df))

    train_indices = shuffled_indices[:train_size]
    test_indices = shuffled_indices[train_size:train_size + test_size]
    post_prune_indices = shuffled_indices[train_size + test_size:]

    train_df = df.iloc[train_indices]
    test_df = df.iloc[test_indices]
    prune_df = df.iloc[post_prune_indices]

    return train_df, test_df, prune_df
if __name__ == '__main__':
    # Load and read nursery data set into pandas dataframe 
    nurseryDF = pd.read_csv("nursery.data", names=["parents", "has_nurs", "form", "children", 
                                                    "housing", "finance", "social", "health",
                                                    "label"])

    fr = open('nursery.data')
    lenses=[inst.strip().split(',') for inst in fr.readlines()]
    lenses.pop()
    lenses=lenses[0:12000]
    print(np.array(lenses).shape)
    #print(lenses)
    lensesLabels=["parents", "has_nurs", "form", "children", 
                "housing", "finance", "social", "health","label"]

    #lensesTree = trees.createTree(lenses,lensesLabels,'ID3')
    lensesTree = trees.createTree(lenses,lensesLabels,'C45')
    treePlotter.createPlot(lensesTree)

    """with open('nursery.data', 'r') as f:
        names = f.read()
        print(names)"""
    #print(nurseryDF["parents"][1])
    # Print information about dataframe
    #nurseryDF.info()
    #display(nurseryDF)
    # Calling the function to split the dataset 分为60%训练 20%测试 20%之后剪枝
    """train_df, test_df, prune_df = train_test_prune_split(nurseryDF, 0.6, 0.2)"""
    
    