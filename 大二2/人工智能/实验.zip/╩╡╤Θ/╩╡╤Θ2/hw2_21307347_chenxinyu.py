class StuData:
    """
    本次作业中, 类方法的输入参数名可自定义, 但参数数据类型需保证测试程序正常运行
    请不要更改类方法的名
    """
    def __init__(self,filename):
        self.data = []
        with open(filename) as file:
            for line in file.readlines():
                s=line.split()
                s1=[s[0],s[1],s[2],int(s[3])]
                self.data.append(s1)

    def AddData(self,name,stu_num,gender,age):
        self.data.append([name,stu_num,gender,age])
        pass

    def SortData(self,type):
        if type=="name":
            self.data.sort(key=lambda ele: ele[0],reverse=False)
        elif type=="stu_num":
            self.data.sort(key=lambda ele: ele[1],reverse=False)
        elif type=="gender":
            self.data.sort(key=lambda ele: ele[2],reverse=False)
        elif type=="age":
            self.data.sort(key=lambda ele: ele[3],reverse=False)
        pass

    def ExportFile(self,filename):
        with open(filename,'w') as file:
            for s in self.data:
                file.write(s[0]+" "+s[1]+" "+s[2]+" "+str(s[3])+"\n")
        pass


if __name__ == '__main__':
    # 测试程序
    s1 = StuData('student_data.txt')
    s1.AddData(name="Bob", stu_num="003", gender="M", age=20)
    s1.SortData('age')
    s1.ExportFile('new_stu_data.txt')