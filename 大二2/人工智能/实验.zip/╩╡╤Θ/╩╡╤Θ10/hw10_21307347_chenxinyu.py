import torch
import torch.nn as nn
import torch.optim as optim
import torch.nn.functional as F
import gym
import numpy as np
import matplotlib.pyplot as plt
device = 'cpu'
eps = 1
eps_min = 0.01
eps_decay = 0.995
input_size = 4
output_size = 2
hidden_size = 16
buffer_capacity = 5000
update_target = 50
batch_size = 16
episode = 400
min_test_size = 500
gamma = 0.95
lr = 0.005

class Net1(nn.Module):
    def __init__(self) -> None:
        super().__init__()
        self.l1 = nn.Linear(input_size, hidden_size)
        self.l2 = nn.Linear(hidden_size,output_size)

    def forward(self, x):
        x = torch.Tensor(x)
        x = F.relu(self.l1(x))
        x = self.l2(x)
        return x


class Net2(nn.Module):
    def __init__(self) -> None:
        super().__init__()
        self.l1 = nn.Linear(4, 1)

    def forward(self, x):
        return self.l1(x) + 1


class MyAgent:
    def __init__(self) -> None:
        #self.net1 = Net1().to(device)
        #self.net2 = Net2().to(device)

        self.eval_net = Net1()
        self.target_net = Net1()
        self.optim = optim.Adam(self.eval_net.parameters(),lr=lr)
        self.eps = eps
        self.buffer = ReplayBuffer(buffer_capacity)
        self.loss_fn = nn.MSELoss()
        self.learn_step = 0

    def get_action(self, state, eval_mode=False):
        """v1 = self.net1(torch.Tensor(state)).mean()
        v2 = self.net2(torch.Tensor(state))
        return 1 if v1 + v2 > 0 else 0"""
        if eval_mode==False and np.random.uniform() <= self.eps:
            a = np.random.randint(0,2)
        else:
            a_value = self.eval_net(state)
            a = torch.max(a_value,dim=-1)[1].numpy()
        return int(a)

    def store_transition(self, *transition):
        self.buffer.push(*transition)


    def learn(self):
        if self.eps > eps_min:
            self.eps *= eps_decay
        if self.learn_step % update_target==0:
            self.target_net.load_state_dict(self.eval_net.state_dict())
        self.learn_step+=1
        s,a,r,s_next,done = self.buffer.sample(batch_size)
        a = torch.LongTensor(a) 
        done = torch.IntTensor(done)
        r = torch.FloatTensor(r)
        q_eval = self.eval_net(s).gather(-1,a.unsqueeze(-1)).squeeze(-1)
        q_next = self.target_net(s_next).detach()
        q_target = r + gamma*(1-done)*torch.max(q_next,dim=-1)[0]
        loss = self.loss_fn(q_eval,q_target)
        self.optim.zero_grad()
        loss.backward()
        self.optim.step()


    def load_model(self, file_name):
        self.eval_net.load_state_dict(torch.load(file_name + ".pth"))
        #self.net2.load_state_dict(torch.load(file_name + "_net2.pth"))
    
    def save_model(self):
        torch.save(self.eval_net.state_dict(), 'hw10_21307347_chenxinyu.pth')

class ReplayBuffer:
    def __init__(self, capacity):
        self.buffer=[]
        self.capacity = capacity
    
    def len(self):
        return len(self.buffer)
    
    def push(self, *transition):
        if len(self.buffer) == self.capacity:
            self.buffer.pop(0)
        self.buffer.append(transition)
    
    def sample(self, n):
        index = np.random.choice(len(self.buffer),n)
        batch = [self.buffer[i] for i in index]
        return zip(*batch)
    
    def clean(self):
        self.buffer.clean()
def test(agent):
    env = gym.make("CartPole-v1")
    s1 = env.reset()[0]
    r_total = 0
    for t in range(8000):
        a = agent.get_action(s1, eval_mode=True)
        s2, reward, done, _, _ = env.step(a)
        r_total += reward
        if done:
            break
        s1 = s2
    return r_total
def draw(x,y):
    plt.figure()
    plt.xlabel('episode')
    plt.ylabel('reward')
    plt.plot(x, y, color='blue')
    plt.show()

if __name__ == '__main__':
    agent = MyAgent()
    #env = gym.make("CartPole-v1", render_mode="human")
    env = gym.make("CartPole-v1")
    r_max= 500
    x,y=[],[]
    for i_episode in range(episode):
        s = env.reset()
        s = s[0]
        ep_r = 0
        done = False
        while not done:
            #env.render()

            a = agent.get_action(s)
            s_next, r, done, info,_ = env.step(a)     
            #r1 = (env.x_threshold - abs(s[0])) / env.x_threshold - 0.8
            #r2 = (env.theta_threshold_radians - abs(s[2])) /env.theta_threshold_radians - 0.5
            #reward = r1 + r2
            agent.store_transition(s, a, r, s_next,done)    
            ep_r += r
            s = s_next
            if agent.buffer.len() >= min_test_size:  #capacity
                agent.learn()
        print("episode=",i_episode," ep_r=",ep_r)
        
        x.append(i_episode)
        y.append(test(agent))
        if ep_r>r_max:
            if test(agent)>800:
                r_max = ep_r
                print("save")
                agent.save_model()
    print("r_max=",r_max)    
    draw(x,y)
            

