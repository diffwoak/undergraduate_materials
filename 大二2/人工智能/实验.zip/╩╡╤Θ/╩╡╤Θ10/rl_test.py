import gym
import time
from hw10_21307347_chenxinyu import MyAgent
def run_test(agent):
    r_list = []
    test_time = 5
    for seed in range(test_time):
        env = gym.make("CartPole-v1", render_mode="human")
        s1 = env.reset(seed=seed)[0]
        # Starting interaction with the environment
        r_total = 0
        for t in range(2000):
            a = agent.get_action(s1, eval_mode=True)
            s2, reward, done, _, _ = env.step(a)
            r_total += reward
            # Restarting the environment (Game Over)
            if done:
                print("done")
                break
            # Moving to the next state
            s1 = s2
        r_list.append(r_total)
    return sum(r_list)/test_time



if __name__ == "__main__":
    file_name = "hw10_21307347_chenxinyu"
    #exec("from %s import MyAgent"%file_name)
    agent = MyAgent()
    agent.load_model(file_name)
    r_total = run_test(agent)
    print("total reward: %.2f" % r_total)