from typing import List, Tuple
import heapq


class State:
    def __init__(self, puzzle: List[List[int]], g: int, h: int, parent=None, move=None):
        self.puzzle = puzzle
        self.g = g
        self.h = h
        self.parent = parent
        self.move = move

    def f(self):
        return self.g + self.h

    def __lt__(self, other):
        return self.f() < other.f()

    def __eq__(self, other):
        return self.puzzle == other.puzzle

    def __hash__(self):
        return hash(str(self.puzzle))


def get_blank(puzzle: List[List[int]]) -> Tuple[int, int]:
    for i in range(4):
        for j in range(4):
            if puzzle[i][j] == 0:
                return i, j


def get_child_puzzle(puzzle: List[List[int]], move: Tuple[int, int], blank: Tuple[int, int]) -> List[List[int]]:
    child_puzzle = [row[:] for row in puzzle]
    i, j = blank
    x, y = move
    child_puzzle[i][j], child_puzzle[i+x][j+y] = child_puzzle[i+x][j+y], child_puzzle[i][j]
    return child_puzzle


def get_manhattan_distance(puzzle: List[List[int]]) -> int:
    distance = 0
    for i in range(4):
        for j in range(4):
            if puzzle[i][j] == 0:
                continue
            row = (puzzle[i][j] - 1) // 4
            col = (puzzle[i][j] - 1) % 4
            distance += abs(i - row) + abs(j - col)
    return distance


def get_solution(state: State) -> List[Tuple[List[List[int]], str]]:
    solution = []
    while state.parent is not None:
        solution.append((state.puzzle, state.move))
        state = state.parent
    solution.append((state.puzzle, None))
    solution.reverse()
    return solution


def A_star(puzzle: List[List[int]]) -> List[Tuple[List[List[int]], str]]:
    open_list = []
    closed_list = set()
    blank = get_blank(puzzle)
    root = State(puzzle, 0, get_manhattan_distance(puzzle), None, None)
    heapq.heappush(open_list, root)
    while open_list:
        state = heapq.heappop(open_list)
        if state.h == 0:
            return get_solution(state)
        closed_list.add(state)
        blank = get_blank(state.puzzle)
        moves = [(0, 1), (1, 0), (0, -1), (-1, 0)]
        for move in moves:
            x, y = move
            if 0 <= blank[0]+x < 4 and 0 <= blank[1]+y < 4:
                child_puzzle = get_child_puzzle(state.puzzle, move, blank)
                child_state = State(child_puzzle, state.g+1, get_manhattan_distance(child_puzzle), state, move)
                if child_state in closed_list:
                    continue
                heapq.heappush(open_list, child_state)
    return []

if __name__ == '__main__':
    # 可自己创建更多用例并分析算法性能
    puzzle1 = [[1, 2, 3, 4], [5, 6, 7, 8], [9, 10, 11, 12], [0, 13, 14, 15]]
    puzzle2 = [[5, 1, 2, 4], [9, 6, 3, 8], [13, 15, 10, 11], [14, 0, 7, 12]]
    sol1 = A_star(puzzle1)
    sol2 = A_star(puzzle2)
    print(sol1)
    print(sol2)
