"""
第4次作业, 选择其中一种算法实现即可.
Puzzle问题的输入数据类型为二维嵌套list, 空位置用 `0`表示. 输出的解数据类型为 `list`, 是移动数字方块的次序.
"""
import copy
def h(puzzle):
    k=1
    num=0
    for i in range(len(puzzle)):
        for j in range(len(puzzle[0])):
            if puzzle[i][j]!=0 and puzzle[i][j]!=k:
                x=k//len(puzzle[0])
                y=(k%len(puzzle[0]))-1
                if y==-1: y=0
                num+=abs(i-x)+abs(j-y)
            k+=1
    return num
class A:
    def __init__(self,puz,stp,g,faa=[]) -> None:
        self.puzz = copy.deepcopy(puz)
        self.step = stp
        self.g    = g
        self.f    = g + h(self.puzz)
        self.fa   = faa
def judge(s,t,open,close,stp):
    for i in close:
        if i.puzz==s:
            return
    for i in open:
        if i.puzz==s:
            return
    
    ta=[]
    ta.append(t)
    tep=A(s,stp,t.g+1,ta)
    open.append(tep)
def A_star(puzzle):
    a = A(puzzle,0,0)
    open=[]
    close=[]
    open.append(a)
    t=open[0]
    while len(open)!=0:
        t=open[0]
        for tt in open:
            if t.f>tt.f:
                t=tt
        open.remove(t)
        close.append(t)
        ##########3
        #print(t.step)
        #for i in range(len(t.puzz)):
        #    s=''
        #    for j in range(len(t.puzz[0])):
        #        s+=(str)(t.puzz[i][j])+'  '
        #    print(s)
        #print(' ')
        if h(t.puzz)==0:
            break #跳出，后续操作
        x,y=-1,-1
        for i in range(len(t.puzz)):
            for j in range(len(t.puzz[0])):
                if t.puzz[i][j]==0:
                    x,y=i,j
        moves = [(0, 1), (1, 0), (0, -1), (-1, 0)]
        for move in moves:
            xx, yy = move
            if 0 <= xx+x < 4 and 0 <= yy+y < 4:
                s=copy.deepcopy(t.puzz)
                s[x][y]=s[x+xx][y+yy]
                s[x+xx][y+yy]=0
                judge(s,t,open,close,s[x][y])
    res=[]
    while t.fa!=[]:
        res.insert(0,t.step)
        t=t.fa[0]
    return res

def IDA_star(puzzle):
    

    pass
if __name__ == '__main__':
    # 可自己创建更多用例并分析算法性能
    puzzle1 = [[1, 2, 3, 4], [5, 6, 7, 8], [9, 10, 11, 12], [0, 13, 14, 15]]
    #puzzle2 = [[5, 1, 3, 4], [2, 7, 8, 12], [9, 6, 11, 15], [0, 13, 10, 14]]
    #puzzle2 = [[5, 1, 2, 4], [9, 6, 3, 8], [13, 15, 10, 11], [14, 0, 7, 12]]
    #puzzle2 = [[6, 10, 3, 15], [14, 8, 7, 11], [5, 1, 0, 2], [13, 12, 9, 4]]
    #puzzle2 = [[11, 3, 1, 7], [4, 6, 8, 2], [15, 9, 10, 13], [14, 12, 5, 0]]
    sol1 = A_star(puzzle1)
    #sol2 = A_star(puzzle2)
    print(sol1)
    #print(sol2)
