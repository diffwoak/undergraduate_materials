"""
第5次作业, 用遗传算法解决TSP问题
本次作业可使用`numpy`库和`matplotlib`库以及python标准库
请不要修改类名和方法名
"""
import numpy as np
import matplotlib.pyplot as plt
import copy
import pandas as pd
from random import *
def ranlist(n):   #生成随机排序
    la = [i for i in range(n) ]
    shuffle(la)
    return la
def cross(aa,bb,n):#交叉返回两个子代
    a,b=aa[:],bb[:]
    [x,y] = [randrange(n) for i in range(2)]
    if x>y: x,y=y,x
    d1,d2={},{}
    i=x
    while i<=y:
        d2[a[i]]=b[i]
        d1[b[i]]=a[i]
        a[i],b[i]=b[i],a[i]
        i+=1
    for i in range(n):
        if i < x or i > y:
            while a[i] in d1.keys():
                a[i]=d1[a[i]]
            while b[i] in d2.keys():
                b[i]=d2[b[i]]
    return a,b
def var(aa,n):#变异
    a=aa[:]
    [x,y] = [randrange(n) for i in range(2)]
    if x>y: x,y=y,x
    i,j=x,y
    while i<j:
        a[i],a[j]=a[j],a[i]
        i+=1
        j-=1
    return a
class GeneticAlgTSP:
    def __init__(self, tsp_filename):
        skip=0
        with open(tsp_filename) as file:
            for line in file.readlines():
                if line[0]!='1': skip+=1
                else: break
        df = pd.read_csv(tsp_filename, sep=" ", skiprows=skip, header=None)
        self.n=len(df)-1 #存在EOF
        n=self.n
        self.city_x = np.array(df[1][0:n])
        self.city_y = np.array(df[2][0:n])# 读取文件数据, 存储到该成员中
        self.d = np.arange(n*n,dtype=float).reshape(n, n)
        for i in range(n):
            j=i
            while j<n:
                dd=(self.city_x[i]-self.city_x[j])**2+(self.city_y[i]-self.city_y[j])**2
                self.d[i][j]=np.sqrt(dd)
                self.d[j][i]=self.d[i][j]
                j+=1
        self.population=[] # 初始化种群, 会随着算法迭代而改变
        for i in range(40):
            self.population.append(ranlist(n))
    def fit(self,a,n):#计算适应度
        sum=0
        for i in range(n):
            if i<n-1:
                dd=self.d[a[i]][a[i+1]]
            else:
                dd=self.d[a[i]][a[0]]
            sum+=dd
        return sum       
    def draw(self,p,fre,num):
        plt.figure(1)
        plt.scatter(self.city_x, self.city_y, color='red', marker='.')
        for i in range(len(p)-1):
            plt.plot([self.city_x[p[i]],self.city_x[p[i+1]]], [self.city_y[p[i]],self.city_y[p[i+1]]], color='blue')
        plt.plot([self.city_x[p[len(p)-1]],self.city_x[p[0]]], [self.city_y[p[len(p)-1]],self.city_y[p[0]]], color='blue')
        fig=plt.figure(2)
        x=[i for i in range(len(fre))]
        ax = fig.add_subplot(111)
        ax.set(title='TSP simulated annealing',ylabel='Current optimal', xlabel='Annealing times')
        plt.plot(x, fre, color='blue')
        plt.show()
    def iterate(self, num_iterations):
        # 基于self.population进行迭代,返回当前较优路径
        p=self.population[:]
        fre=[] #记录路径收敛曲线
        count=0
        for t in range(num_iterations):#迭代次数
            if t%100==0:print("t="+str(t))
            C,score=[],[]
            for i in p:
                score.append(self.fit(i,self.n))
            while len(C)<50:
                #从population选出两个父母
                rannum = [randrange(len(p)) for i in range(8)]
                if score[rannum[0]]<score[rannum[1]]:
                    f1,f2=rannum[0],rannum[1]
                else:
                    f1,f2=rannum[1],rannum[0]
                for i in rannum:
                    if score[i] < score[f1]:
                        f1,f2=i,f1
                    elif score[i] < score[f2]:
                        f1,f2=f1,i
                a,b=cross(p[f1],p[f2],self.n)#交叉得到子代
                a,b=var(a,self.n),var(b,self.n)#变异
                C.append(a)#C.append
                C.append(b)
            #C并入p，                
            for i in range(len(C)):
                p.append(C[i])
                score.append(self.fit(C[i],self.n))
            tep=score[0]
            for i in range(20):#选择排序，取前30个适应度强的个体
                j=i
                c=j
                while j < len(p):
                    if score[c]>score[j]:c=j
                    j+=1
                p[c],p[i]=p[i],p[c]
                score[c],score[i]=score[i],score[c]
            p=p[0:30]  # 得到下一代
            fre.append(score[0])  
            if tep==score[0]:#计数
                count+=1
            else: count=0
            if count>5000:break
        #选出最佳
        print("fit=",end=str(score[0]))
        self.draw(p[0],fre,num_iterations)
        return p[0]

if __name__ == "__main__":
    tsp = GeneticAlgTSP("dj38.tsp")  # 读取Djibouti城市坐标数据
    T = 250
    tour = tsp.iterate(T) 
    #print(tour)  # 打印路径(以列表的形式)

