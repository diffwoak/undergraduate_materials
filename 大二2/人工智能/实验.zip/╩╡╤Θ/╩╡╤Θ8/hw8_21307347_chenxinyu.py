import numpy as np
from grid_env import MiniWorld


class DPAgent:
    def __init__(self, env):
        self.env = env
        self.n_state = env.observation_space.n  # 36
        self.n_action = env.action_space.n      # 4

    def iteration(self, threshold=1e-3):
        values = np.zeros([self.n_state])   # 36
        # 我们约定a=0,1,2,3 对应动作["^", ">", "v", "<"]
        # policy[s][a]为在状态s下采取动作a的概率
        policy = np.zeros([self.n_state, self.n_action])    # 36 * 4
        """
        策略迭代算法
        """
        mov = [[0,1],[1,0],[0,-1],[-1,0]]
        while 1:
            while 1:    # evaluation
                d = 0
                for s in range(self.n_state):
                    x,y = self.env._state_to_xy(s)
                    v = self.env.grids.get_value(x, y)
                    v_new = 0
                    for m in mov:
                        mx,my = x+m[0],y+m[1]
                        if mx<0 or my<0 or mx>=self.env.n_width or my>=self.env.n_height or self.env.grids.get_dtype(mx, my):
                            mx,my = x,y
                        v_new += 0.25*(self.env.R[s] + 0.9*(self.env.grids.get_value(mx, my)))
                    self.env.grids.set_value(x,y,v_new)
                    d = max(d, abs(v-v_new))
                    values[s] = v_new
                if d < threshold: break
            stable = True   # improvement
            for s in range(self.n_state):
                old_ply = policy[s].copy()  # 4
                new_ply = []
                x,y = self.env._state_to_xy(s)
                for m in mov:
                    mx,my = x+m[0],y+m[1]
                    if mx<0 or my<0 or mx>=self.env.n_width or my>=self.env.n_height or self.env.grids.get_dtype(mx, my):
                        mx,my = x,y
                    s1 = self.env._xy_to_state(mx,my)
                    new_ply.append(self.env.R[s1] + 0.9*(self.env.grids.get_value(mx, my)))
                t = max(new_ply)
                p_t = 1/float(new_ply.count(t))
                for i in range(4):
                    if new_ply[i] == t:
                        policy[s][i] = p_t
                    else: policy[s][i] = 0
                if not(old_ply == policy[s]).all(): stable = False
            if stable: break
        return values, policy


if __name__ == "__main__":
    env = MiniWorld()
    agent = DPAgent(env)

    values, policy = agent.iteration(threshold=1e-3)
    print(values)
    env.show_values(values, sec=3)  # 将values渲染成颜色格子, 显示3秒
    env.show_policy(policy)  # 在终端打印每个状态下的动作
