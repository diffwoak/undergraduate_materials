
# import ui_
# ui_.run_app()

import auto_ui_
auto_ui_.run_app()
