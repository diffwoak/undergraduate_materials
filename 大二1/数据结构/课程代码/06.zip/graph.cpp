
// 图

#ifndef __GRAPH_CPP__
#define __GRAPH_CPP__

#include "dict.cpp"
#include "set.cpp"

template <typename N, typename E, hash_function_type C=hash_function>
class Graph
{
	struct Node {
		N label;
		Dict<N, E, C> out_edges;
		Set<N> in_edges;
		Node() {} // 作为哈希表键值对中的值需要有默认构造函数
		Node(const N & n) : label(n) {}
	};

	Dict<N, Node, C> _nodes;

public:
	int size() const {
		return _nodes.size();
	}

	int out_degree(const N & n) const {
		const Node & n1 = _nodes.get(n);
		return n1.out_edges.size();
	}

	int in_degree(const N & n) const {
		const Node & n1 = _nodes.get(n);
		return n1.in_edges.size();
	}

	List<N> next_nodes(const N & n) const {
		const Node & n1 = _nodes.get(n);
		return n1.out_edges.keys();
	}

	List<N> prev_nodes(const N & n) const {
		const Node & n1 = _nodes.get(n);
		return n1.in_edges;
	}

	void clear() {
		_nodes.clear();
	}

	void add_node(const N & n) {
		if (! has_node(n))
			_nodes.put(n, Node(n));
	}

	bool has_node(const N & n) const {
		return _nodes.has(n);
	}

	void remove_node(const N & n) {
		Node & n1 = _nodes.get(n);
		List<N> next = n1.out_edges.keys();
		I(i, next.size())
			remove_edge(n, next.get(i));
		List<N> prev = n1.in_edges;
		I(i, prev.size())
			remove_edge(prev.get(i), n);
		_nodes.remove(n);
	}

	void add_edge(const N & first, const N & second, const E & e) {
		Node & n1 = _nodes.get(first);
		Node & n2 = _nodes.get(second);
		if (! n1.out_edges.has(second)) {
			n1.out_edges.put(second, e);
			n2.in_edges.add(first);
		}
	}

	bool has_edge(const N & first, const N & second) const {
		const Node & n1 = _nodes.get(first);
		return n1.out_edges.has(second);
	}

	const E & get_edge(const N & first, const N & second) const {
		const Node & n1 = _nodes.get(first);
		return n1.out_edges.get(second);
	}

	E & get_edge(const N & first, const N & second) {
		Node & n1 = _nodes.get(first);
		return n1.out_edges.get(second);
	}

	void remove_edge(const N & first, const N & second) {
		Node & n1 = _nodes.get(first);
		Node & n2 = _nodes.get(second);
		n1.out_edges.remove(second);
		n2.in_edges.remove(first);
	}

	// 结点的数据(N)是结点的键，不能改变。如果要变，需要删除后重新添加。
	List<N> nodes() const {
		return _nodes.keys();
	}

};

// 图输入输出

template <typename N, typename E>
ostream & operator << (ostream & out, const Graph<N,E> & graph) {
	out << graph.size() << endl;
	List<N> ns = graph.nodes();
	int n = ns.size();
	I(i, n) {
		N n1 = ns.get(i);
		out << n1 << " " << graph.out_degree(n1) << endl;
	}
	I(i, n) {
		N n1 = ns.get(i);
		List<N> ns2 = graph.next_nodes(n1);
		I(j, ns2.size()) {
			N n2 = ns2.get(j);
			out << n1 << " " << n2 << " " << graph.get_edge(n1, n2) << endl;
		}
	}
	return out;
}

template <typename N, typename E>
istream & operator >> (istream & in, Graph<N,E> & graph) {
	graph.clear();
	int size;
	in >> size;
	List<int> out_degrees;
	I(i, size) {
		N n1;
		int out_degree;
		in >> n1 >> out_degree;
		graph.add_node(n1);
		out_degrees.push(out_degree);
	}
	I(i, size) {
		I(j, out_degrees.get(i)) {
			N n1, n2;
			E e;
			in >> n1 >> n2 >> e;
			graph.add_edge(n1, n2, e);
		}
	}
	return in;
}

template <typename N, typename E>
Graph<N, E> load_graph(const string & path) {
	Graph<N, E> graph;
	ifstream in(path.c_str());
	if (in.fail())
		throw runtime_error("Failed to load graph");
	in >> graph;
	in.close();
	return graph;
}

template <typename N, typename E>
void save_graph(const Graph<N, E> & graph, const string & path) {
	ofstream out(path.c_str());
	if (out.fail())
		throw runtime_error("Failed to save graph");
	out << graph;
	out.close();
}

#endif