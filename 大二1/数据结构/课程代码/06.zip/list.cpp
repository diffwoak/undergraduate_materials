// 以下的List数据结构包含了: 顺序表, 顺序栈, 循环队列 中的功能。

#ifndef __LIST_CPP__
#define __LIST_CPP__

#include <iostream>
#include <fstream>
#include <exception>
using namespace std;

#define I(i,n) for (size_t i = 0; i < n; ++ i)

template <typename E, int INIT_SIZE=2>
class List {
	E * elements;
	int _head;
	int length;
	int capacity;

	void _init() {
		elements = new E[INIT_SIZE];
		_head = 0;
		length = 0;
		capacity = INIT_SIZE;
	}

	void _copy(const List & src) {
		length = 0; // clear
		I(i, src.length) {
			const E & e = src.get(i);
			insert(i, e);
		}	
	}

	void _swap(List && src) {
		elements = src.elements;
		_head = src._head;
		length = src.length;
		capacity = src.capacity;
		src._init();
	}

	void _throw_exception(int index, int length) const {
		stringstream ss;
		ss << "索引 "<<index<<" 越界: [0,"<<length<<")";
		throw out_of_range(ss.str().c_str());
	}

public:
	List() {
		_init();
	}

	virtual ~List() {
		delete [] elements;
	}

	List(const List & src) {
		_init();
		_copy(src);
	}

	List(List && src) {
		elements = src.elements;
		_head = src._head;
		length = src.length;
		capacity = src.capacity;
		src._init();
	}

	List & operator = (const List & src) {
		_copy(src);
		return *this;
	}

	List & operator = (List && src) {
		delete [] elements;
		_swap(move(src));
		return *this;
	}

	int size() const {
		return length;
	}

	void clear() {
		length = 0;
	}

	const E & get(int index) const {
		int i = _head + index;
		if (i >= capacity)
			i -= capacity;
		return elements[i];
	}

	E & get(int index) {
		if (index < 0 || index >= length)
			_throw_exception(index, length);
		int i = _head + index;
		if (i >= capacity)
			i -= capacity;
		return elements[i];
	}

	int find(const E & e) {
		for (int i = 0; i < length; ++ i) {
			int j = _head + i;
			if (j >= capacity)
				j -= capacity;
			if (elements[j] == e)
				return i;
		}
		return -1; // 失败
	}

	void insert(int index, const E & e) {
		if (index < 0 || index > length)
			_throw_exception(index, length+1);
		if (length == capacity) {
			int capacity2 = capacity * 2;
			E * tmp = new E[capacity2];
			for (int i = 0; i < length; ++ i) {
				int j = _head + i;
				if (j >= capacity)
					j -= capacity;
				tmp[i] = elements[j];
			}
			delete [] elements;
			elements = tmp;
			capacity = capacity2;
			_head = 0;
		}
		for (int i = length-1; i >= index; -- i) {
			int j = _head + i + 1;
			if (j >= capacity)
				j -= capacity;
			int k = _head + i;
			if (k >= capacity)
				k -= capacity;
			elements[j] = elements[k];
		}
		int i = _head + index;
		if (i >= capacity)
			i -= capacity;
		elements[i] = e;
		++ length;
	}

	void remove(int index) {
		if (index < 0 || index >= length)
			_throw_exception(index, length);
		for (int i = index - 1; i >= 0; -- i) {
			int j = _head + i + 1;
			if (j >= capacity)
				j -= capacity;
			int k = _head + i;
			if (k >= capacity)
				k -= capacity;
			elements[j] = elements[k];
		}
		++ _head;
		if (_head >= capacity)
			_head -= capacity;
		-- length;
	}

	// stack operations

	const E & top() const {
		return get(length-1);
	}

	E & top() {
		return get(length-1);
	}

	void push(const E & e) {
		insert(length, e);
	}

	void pop() {
		remove(length-1);
	}

	// queue operations

	const E & head() const {
		return get(0);
	}

	E & head() {
		return get(0);
	}

	void enqueue(const E & e) {
		insert(length, e);
	}

	void dequeue() {
		remove(0);
	}

};

// 输入输出

template <typename E>
ostream & operator << (ostream & out, const List<E> & list) {
	int n = list.size();
	out << n << endl;
	I(i, n)
		out << list.get(i) << " ";
	return out;
}

template <typename E>
istream & operator >> (istream & in, List<E> & list) {
	list.clear();
	int size;
	in >> size;
	I(i, size) {
		E e;
		in >> e;
		list.push(e);
	}
	return in;
}

template <typename E>
List<E> load_list(const string & path) {
	List<E> list;
	ifstream in(path.c_str());
	if (in.fail())
		throw runtime_error("Failed to load list");
	in >> list;
	in.close();
	return list;
}

template <typename E>
void save_list(const List<E> & list, const string & path) {
	ofstream out(path.c_str());
	if (out.fail())
		throw runtime_error("Failed to save list");
	out << list;
	out.close();
}

#endif