
#include "graph.cpp"

#ifndef __GRAPH_UTILS_CPP__
#define __GRAPH_UTILS_CPP__

// 无向图最小生成树：普里姆(Prim)算法  

// O(d)
template <typename N, typename E>
void _recompute_costs(const Graph<N,E> & graph, const N & added,
		Dict<N,E> & costs, Dict<N,N> & nearest, Graph<N,E> & tree) {
	costs.remove(added);
	nearest.remove(added);
	List<N> next_nodes = graph.next_nodes(added);
	int degree = next_nodes.size();
	I(i, degree) {
		N node = next_nodes.get(i);
		if (tree.has_node(node)) continue;
		E new_cost = graph.get_edge(added, node);
		if ((not costs.has(node)) or costs.get(node) > new_cost) {
			costs.put(node, new_cost);
			nearest.put(node, added);
		}
	}
}

// O(n)
template<typename N, typename E>
N _arg_min(const Dict<N,E> & costs) {
	List<N> nodes = costs.keys();
	N min_cost_node = nodes.get(0);
	E min_cost = costs.get(min_cost_node);
	int n = nodes.size();
	I(i,n) {
		if (i==0) continue;
		N node = nodes.get(i);
		E cost = costs.get(node);
		if (min_cost > cost) {
			min_cost = cost;
			min_cost_node = node;
		}
	}
	return min_cost_node;
}

// O(n^2)
template<typename N, typename E>
Graph<N,E> minimum_spanning_tree_prim(const Graph<N,E> & graph) {
	N to_add = graph.nodes().get(0);
	Graph<N,E> tree; // 存放了最小生成树中的点和边
	Dict<N,E> costs; // 还不在树中的结点离树中的结点的最小距离
	Dict<N,N> nearest; // 还不在树中的结点离树中最小距离的结点
	// 加上下面两行，使的后面的程序简单些
	costs.put(to_add, E());
	nearest.put(to_add, to_add);
	// O(n)
	while (true) {
		tree.add_node(to_add);
		N added = to_add;
		_recompute_costs(graph, to_add, costs, nearest, tree); 
		if (costs.size()==0) break;
		to_add = _arg_min(costs);
		tree.add_node(to_add);
		E edge = graph.get_edge(nearest.get(to_add), to_add);
		tree.add_edge(nearest.get(to_add), to_add, edge);
		tree.add_edge(to_add, nearest.get(to_add), edge);
	}
	return tree;
}

// 无向图最小生成树：克鲁斯卡尔(Kruskal)算法  

template <typename N, typename E>
class _Edge {
public:
	N first;
	N second;
	E cost;
	_Edge() {}
	_Edge(const N & first, const N & second, const E & cost) :
		first(first), second(second), cost(cost) {}
};

template<typename N, typename E>
List<_Edge<N, E> > _get_edges(const Graph<N,E> & graph) {
	List<N> nodes = graph.nodes();
	List<_Edge<N, E>> edges;
	int n = nodes.size();
	I(i, n) {
		N n1 = nodes.get(i);
		List<N> next_nodes = graph.next_nodes(n1);
		int m = next_nodes.size();
		I(j, m) {
			N n2 = next_nodes.get(j);
			edges.push(_Edge<N, E>(n1, n2, graph.get_edge(n1, n2)));
		}
	}
	return edges;
} 

template<typename N, typename E>
void _sort_edges(List<_Edge<N, E> > & list) {
	int n = list.size();
	for (int i = n-1; i > 0; -- i)
		for (int j = 0; j < i; ++ j)
			if (list.get(j).cost > list.get(j+1).cost)
				swap(list.get(j), list.get(j+1));
}

template<typename N, typename E>
void _init_components(Dict<N, int> & component_id, 
					Dict<int, List<N>> & components, 
					const Graph<N,E> & graph) {
	List<N> nodes = graph.nodes();
	int n = nodes.size();
	I(i, n) {
		N node = nodes.get(i);
		List<N> component;
		component.push(node);
		components.put(i, component);
		component_id.put(node, i);
	}
}

template<typename N>
void _combine_components(int c1, int c2, 
				Dict<N, int> & component_id, 
				Dict<int, List<N>> & components) {
	List<N> & component1 = components.get(c1);
	List<N> & component2 = components.get(c2);
	if (component1.size() < component2.size()) {
		swap(c1, c2);
		swap(component1, component2); // O(1)
	}
	int m = component2.size();
	I(j, m) {
		N node2 = component2.get(j);
		component_id.put(node2, c1);
		component1.push(node2);
	}
	components.remove(c2);	
} 


// O(eloge)
template<typename N, typename E>
Graph<N,E> minimum_spanning_tree_kruskal(const Graph<N,E> & graph) {
	Dict<int, List<N>> components; // 连通分量id -> 连通分量
	Dict<N, int> component_id; // 结点 -> 连通分量id
	_init_components(component_id, components, graph);
	List<_Edge<N, E> > edges = _get_edges(graph); // 所有边
	_sort_edges(edges); // 把边升序排序 O(eloge)
	int k = edges.size();
	Graph<N,E> tree; // 存放了最小生成树中的点和边
	I(i, k) { // O(e)
		_Edge<N, E>  edge = edges.get(i);
		int c1 = component_id.get(edge.first);
		int c2 = component_id.get(edge.second);
		if (c1==c2)
			continue;
		// 添加边和两个端点到树中
		tree.add_node(edge.first);
		tree.add_node(edge.second);
		tree.add_edge(edge.first, edge.second, edge.cost);
		tree.add_edge(edge.second, edge.first, edge.cost);
		// 合并连通分量 每个联通分量约被合并平均O(logn)次，总平均复杂度O(nlogn)
		_combine_components(c1, c2, component_id, components);
	}
	return tree;
}

// 有向图中从某个源点到其余各顶点的最短路径：迪杰斯特拉(Dijkstra)算法

template<typename N, typename E>
class Dijkstra
{	
	N src;
	Dict<N,E> distance; // 每个结点离src的最终最短路径的长度
	Dict<N,N> prev; // 每个结点离src的最短路径上的前一个结点

	void _recompute_costs(const Graph<N,E> & graph, const N & added,
						Dict<N,E> & costs) {
		E cost = costs.get(added);
		costs.remove(added);
		List<N> next_nodes = graph.next_nodes(added);
		int degree = next_nodes.size();
		I(i, degree) {
			N node = next_nodes.get(i);
			if (distance.has(node)) continue;
			E new_cost = cost + graph.get_edge(added, node);
			if ((not costs.has(node)) or costs.get(node) > new_cost) {
				costs.put(node, new_cost);
				prev.put(node, added);
			}
		}
	}

public:
	// O(n^2), 
	Dijkstra(const Graph<N,E> & graph, const N & src) {
		this->src = src;
		Dict<N,E> costs; // 每个结点离src的暂时最短路径的长度 
		costs.put(src, E());
		while (true) { // O(n)
			if (costs.size()==0) br eak;
			N to_add = _arg_min(costs); // O(n)
			distance.put(to_add, costs.get(to_add));
			_recompute_costs(graph, to_add, costs); // O(d)
		}
	}

	E get_path_distance_to(const N & node) const {
		return distance.get(node);
	}

	bool has_path_to(const N & node) const {
		return prev.has(node);
	}

	List<N> get_path_to(N node) const {
		List<N> path;
		path.insert(0, node);
		while (node != src) {
			node = prev.get(node);
			path.insert(0, node);
		}
		return path;
	}

};

// 有向图中所有个源点到其余各顶点的最短路径：弗洛伊德算法(Floyd)算法

template<typename N, typename E>
class Floyd
{
	Graph<N,E> distance; // distance.get_edge(i,j): 记录结点i和j之间的最短路径长度
	Dict<N,Dict<N,N> > prev; // prev.get(i).get(j): 到i的最短路径上j的前一结点的序号

public:
	// O(n^3)
	Floyd(const Graph<N,E> & graph): distance(graph) {
		List<N> nodes = graph.nodes();
		int n = nodes.size();
		I(i, n)
			prev.put(nodes.get(i), Dict<N,N>());
		I(k, n) {
			N nk = nodes.get(k);
			I(i, n) {
				N ni = nodes.get(i);
				if (nk==ni or not distance.has_edge(ni,nk))
					continue;
				E dik = distance.get_edge(ni,nk);
				I(j, n) {
					N nj = nodes.get(j);
					if (nj==ni or nj==nk or not
						distance.has_edge(nk,nj)) 
						continue;
					if (not prev.get(nk).has(nj))
						prev.get(nk).put(nj,nk);
					// if D[i,j] > D[i,k]+D[k,j]
					E dkj = distance.get_edge(nk,nj);
					if (not distance.has_edge(ni,nj))
						distance.add_edge(ni,nj,dik+dkj);
					else if (distance.get_edge(ni,nj) <= dik+dkj)
						continue;
					// D[i,j] = D[i,k]+D[k,j]
					distance.get_edge(ni,nj) = dik+dkj;
					// path[i,j] = path[k,j]
					prev.get(ni).put(nj, prev.get(nk).get(nj));
				}
			}
		}
	}

	bool has_path(const N & src, const N & dst) const {
		if (not prev.has(src)) return false;
		return prev.get(src).has(dst);
		// return distance.has_edge(src, dst);
	}

	E get_path_distance(const N & src, const N & dst) const {
		return distance.get_edge(src, dst);
	}

	List<N> get_path(const N & src, const N & dst) const {
		List<N> path;
		N node = dst;
		path.insert(0, node);
		while (node != src) {
			node = prev.get(src).get(node);
			path.insert(0, node);
		}
		return path;
	}
};

// 拓扑排序
template<typename N, typename E>
List<N> topological_sort(const Graph<N,E> & graph) {
	Dict<N, int> in_degrees; // 初始化是每个结点的入度
	List<N> nodes = graph.nodes();
	int n = nodes.size();
	List<N> queue; // 存放排序结果
	I(i, n) {
		N ni = nodes.get(i);
		int in_degree = graph.in_degree(ni);
		if (in_degree==0)
			queue.enqueue(ni); // 先加入度为0的结点
		else
			in_degrees.put(ni, in_degree);
	}
	int head = 0;
	while (head < queue.size()) {
		N node = queue.get(head); // 逐个取出入度为0的结点
		++ head;
		List<N> next = graph.next_nodes(node);
		I(i, next.size()) {
			// 把取出的入度为0的所有结点的后继的入度减1
			N ni = next.get(i);
			int in_degree = in_degrees.get(ni) - 1;
			if (in_degree==0)
				queue.enqueue(ni); // 加入新的入度为0的结点
			else
				in_degrees.put(ni, in_degree);
		}
	}
	return queue;
}

// 关键路径
template<typename N, typename E>
Graph<N,E> critical_path(const Graph<N,E> & graph) {
	List<N> nodes = topological_sort(graph);
	int n = nodes.size();
	// 最早发生时间
	Dict<N,E> earliest;
	E zero;
	I(i, n)
		earliest.put(nodes.get(i), zero);
	I(i, n) {
		N node = nodes.get(i);
		List<N> next_nodes = graph.next_nodes(node);
		I(j, next_nodes.size()) {
			N next = next_nodes.get(j);
			E edge = graph.get_edge(node, next);
			// 每个结点最早发生时间 > 每一前驱的最早发生时间 + 边的延迟
			if (earliest.get(next) < earliest.get(node) + edge)
				earliest.get(next) = earliest.get(node) + edge;
		}
	}
	// 最晚发生时间
	Dict<N,E> latest;
	E max = earliest.get(nodes.get(n-1));
	I(i, n)
		latest.put(nodes.get(i), max);
	for (int i = n-1; i >= 0; -- i) {
		N node = nodes.get(i);
		List<N> prev_nodes = graph.prev_nodes(node);
		I(j, prev_nodes.size()) {
			N prev = prev_nodes.get(j);
			E edge = graph.get_edge(prev, node);
			// 每个结点最晚发生时间 + 边的延迟 < 每一后继的最晚发生时间 
			if (latest.get(prev) > latest.get(node) - edge)
				latest.get(prev) = latest.get(node) - edge;
		}		
	}
	// 关键路径
	Graph<N,E> critical;
	I(i, n) {
		N node = nodes.get(i);
		List<N> next_nodes = graph.next_nodes(node);
		I(j, next_nodes.size()) {
			N next = next_nodes.get(j);
			E edge = graph.get_edge(node, next);
			// 如果 前一个结点最早发生时间 + 边的延迟 == 后一个结点的最晚发生时间
			// 那么 这条边的延迟如果增加，将增加某个最后结点的最晚发生时间
			if (earliest.get(node) + edge == latest.get(next)) {
				critical.add_node(node);
				critical.add_node(next);
				critical.add_edge(node, next, edge);
			}		
		}
	}
	return critical;
}

#endif
