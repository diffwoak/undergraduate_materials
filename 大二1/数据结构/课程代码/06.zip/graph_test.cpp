
/*
测试: g++ -g -fno-omit-frame-pointer -fsanitize=address -fPIE -std=c++11 graph_test.cpp
		ASAN_OPTIONS=detect_leaks=1 ./a.out
*/

#include "graph.cpp"

int main() {
	string path = "graph_test.txt";
	Graph<string, int> graph = load_graph<string, int>(path);
	while (true) {
		string node;
		cin >> node;
		if (node == "#save")
			save_graph(graph, path);
		else if (node == "#print") {
			cout << graph;
		}
		else if (node == "#dfs") {
			string start;
			cin >> start;
			List<string> dfs = depth_first_search(graph, start);
			cout << dfs << endl;
		}
		else if (node == "#bfs") {
			string start;
			cin >> start;
			List<string> bfs = breadth_first_search(graph, start);
			cout << bfs << endl;
		}
		else if (node[0] == '+') {
			node = node.substr(1);
			graph.add_node(node);
		}
		else if (node[0] == '-') {
			node = node.substr(1);
			graph.remove_node(node);
		}
		else if (node[0] == '*') {
			node = node.substr(1);
			string node2;
			int edge;
			cin >> node2 >> edge;
			graph.add_edge(node, node2, edge);
		}
		else if (node[0] == '/') {
			node = node.substr(1);
			string node2;
			cin >> node2;
			graph.remove_edge(node, node2);
		}
		else
			cout << "unknown command: " << node << endl;
	}
}
