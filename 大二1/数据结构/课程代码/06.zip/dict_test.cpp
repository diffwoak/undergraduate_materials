
/*
测试: g++ -g -fno-omit-frame-pointer -fsanitize=address -fPIE -std=c++11 dict_test.cpp
		ASAN_OPTIONS=detect_leaks=1 ./a.out
*/

#include "list.cpp"
#include "dict.cpp"

int main() {
	string path = "dict_test.txt";
	Dict<string, string> dict = load_dict<string, string>(path);
	while (true) {
		string key;
		cin >> key;
		if (key == "#save")
			save_dict(dict, path);
		else if (key == "#print") {
			int n = dict.size();
			List<string> keys = dict.keys();
			List<string> values = dict.values();
			I(i, n)
				cout << keys.get(i) << ": " << values.get(i) << endl;
		}
		else if (key == "#inspect")
			dict._inspect();
		else if (key[0] == '+') {
			key = key.substr(1);
			string val;
			cin >> val;
			dict.put(key, val);
		}
		else if (key[0] == '-') {
			key = key.substr(1);
			dict.remove(key);
		}
		else
			cout << dict.get(key) << endl;
	}
}
