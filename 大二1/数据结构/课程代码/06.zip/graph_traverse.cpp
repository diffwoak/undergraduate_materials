
/*
测试: g++ -g -fno-omit-frame-pointer -fsanitize=address -fPIE -std=c++11 graph_traverse.cpp
		ASAN_OPTIONS=detect_leaks=1 ./a.out
*/

#include "graph.cpp"

// 图的遍历

// 深度优先搜索遍历图的时间复杂度为 O(n + e)
template <typename N, typename E>
List<N> depth_first_search(const Graph<N, E> & graph, const N & start) {
	List<N> res;
	List<N> stack;
	Set<N> visited;
	stack.push(start);
	visited.add(start);
	while (stack.size() > 0) {
		N n1 = stack.top();
		res.push(n1);
		stack.pop();
		List<N> next = graph.next_nodes(n1);
		I(i, next.size()) {
			N n2 = next.get(i);
			if (! visited.has(n2)) {
				stack.push(n2);
				visited.add(n2);
			}
		}
	}
	return res;
}

// 广度优先搜索遍历图的时间复杂度为 O(n + e)
template <typename N, typename E>
List<N> breadth_first_search(const Graph<N, E> & graph, const N & start) {
	List<N> queue;
	Set<N> visited;
	queue.enqueue(start);
	visited.add(start);
	int queue_head = 0;
	while (queue_head < queue.size()) {
		N n1 = queue.get(queue_head);
		++ queue_head;
		List<N> next = graph.next_nodes(n1);
		I(i, next.size()) {
			N n2 = next.get(i);
			if (! visited.has(n2)) {
				queue.enqueue(n2);
				visited.add(n2);
			}
		}
	}
	return queue;
}

int main() {
	string path = "graph_test.txt";
	Graph<string, int> graph = load_graph<string, int>(path);
	while (true) {
		string node;
		cin >> node;
		if (node == "#dfs") {
			string start;
			cin >> start;
			List<string> dfs = depth_first_search(graph, start);
			cout << dfs << endl;
		}
		else if (node == "#bfs") {
			string start;
			cin >> start;
			List<string> bfs = breadth_first_search(graph, start);
			cout << bfs << endl;
		}
	}
}
