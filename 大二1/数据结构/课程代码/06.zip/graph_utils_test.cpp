
/*
测试: g++ -g -fno-omit-frame-pointer -fsanitize=address -fPIE -std=c++11 graph_utils_test.cpp
		ASAN_OPTIONS=detect_leaks=1 ./a.out
*/

#include "graph_utils.cpp"

int main() {
	// 无向图最小生成树：普里姆(Prim)算法  
	Graph<string, int> g1 = load_graph<string, int>("graph-6-19.txt");
	Graph<string, int> g2 = minimum_spanning_tree_prim(g1);
	cout << g2 << endl;

	// 无向图最小生成树：克鲁斯卡尔(Kruskal)算法  
	Graph<string, int> g3 = minimum_spanning_tree_kruskal(g1);
	cout << g3 << endl;

	// 有向图中从某个源点到其余各顶点的最短路径：迪杰斯特拉(Dijkstra)算法
	Graph<string, int> g4 = load_graph<string, int>("graph-6-22.txt");
	cout << g4 << endl;
	List<string> ns4 = g4.nodes();
	Dijkstra<string, int> dijkstra(g4, "v0");
	I(i, ns4.size()) {
		string node = ns4.get(i);
		if (not dijkstra.has_path_to(node)) continue;
		cout << node << " 距离 " << 
			dijkstra.get_path_distance_to(node) << endl;
		cout << "路径" << dijkstra.get_path_to(node) << endl;
	}
	cout << endl;

	// 有向图中所有个源点到其余各顶点的最短路径：弗洛伊德算法(Floyd)算法
	Graph<string, int> g5 = load_graph<string, int>("graph-6-24.txt");
	Floyd<string, int> floyd(g5);
	List<string> ns5 = g5.nodes();
	I(s, ns4.size()) {
		string src = ns4.get(s);
		I(d, ns4.size()) {
			string dst = ns4.get(d);
			if (not floyd.has_path(src,dst)) continue;
			cout << "距离 " << src << " " << dst << " = " 
				<< floyd.get_path_distance(src,dst) << endl;
			cout << "路径" << floyd.get_path(src,dst) << endl;
		}
		cout << endl;
	}

	// 拓扑排序
	Graph<string, int> g6 = load_graph<string, int>("graph-6-26.txt");
	List<string> l6 = topological_sort(g6);
	cout << l6 << endl;
	cout << endl;

	// 关键路径
	Graph<string, int> g7 = load_graph<string, int>("graph-6-28.txt");
	Graph<string, int> g8 = critical_path(g7);
	cout << g8 << endl;
}
