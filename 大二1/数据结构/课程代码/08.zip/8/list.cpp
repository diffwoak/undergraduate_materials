// 以下的List数据结构包含了: 顺序表, 顺序栈, 循环队列 中的功能。

#ifndef __LIST_CPP__
#define __LIST_CPP__

#include <iostream>
#include <sstream>
#include <fstream>
#include <exception>
using namespace std;
#include<time.h>
#include<stdlib.h>

#define I(i,n) for (size_t i = 0; i < n; ++ i)

template <typename E>
class List {
	E * _elements;
	int _head;
	int _length;
	int _capacity;
	static bool _srand;

	void _init(int init_size) {
		_elements = new E[init_size];
		_head = 0;
		_length = 0;
		_capacity = init_size;
	}

	void _copy(const List & src) {
		_length = 0; // clear
		I(i, src._length) {
			const E & e = src.get(i);
			insert(i, e);
		}	
	}

	void _swap(List && src) {
		_elements = src._elements;
		_head = src._head;
		_length = src._length;
		_capacity = src._capacity;
		src._init(2);
	}

	void _throw_exception(int index, int length) const {
		// stringstream ss;
		// ss << "索引 "<<index<<" 越界: [0,"<<length<<")";
		// throw out_of_range(ss.str().c_str());
		cout << "索引 "<<index<<" 越界: [0,"<<length<<")";
		char * p = 0;
		cout << *p; // 引发指针错误
	}

	void _resize(int capacity) {
		E * tmp = new E[capacity];
		if (_length > capacity)
			_length = capacity;
		for (int i = 0; i < _length; ++ i) {
			int j = _head + i;
			if (j >= _capacity)
				j -= _capacity;
			tmp[i] = _elements[j];
		}
		delete [] _elements;
		_elements = tmp;
		_capacity = capacity;
		_head = 0;		
	}

public:
	List(int init_size=2) {
		_init(init_size);
	}

	virtual ~List() {
		delete [] _elements;
	}

	List(const List & src) {
		_init(src._length);
		_copy(src);
	}

	List(List && src) {
		_swap(move(src));
	}

	List & operator = (const List & src) {
		_copy(src);
		return *this;
	}

	List & operator = (List && src) {
		delete [] _elements;
		_swap(move(src));
		return *this;
	}

	bool operator == (const List & src) {
		if (_length != src._length) return false;
		for (int i = 0; i < _length; ++ i) {
			int j = i + _head;
			if (j >= _capacity)
				j -= _capacity;
			int j2 = i + src._head;
			if (j2 >= src._capacity)
				j2 -= src._capacity;
			if (_elements[j] != src._elements[j2])
				return false;
		}
		return true;
	}

	int size() const {
		return _length;
	}

	void clear() {
		_length = 0;
	}

	const E & get(int index) const {
		int i = _head + index;
		if (i >= _capacity)
			i -= _capacity;
		return _elements[i];
	}

	E & get(int index) {
		if (index < 0 or index >= _length)
			_throw_exception(index, _length);
		int i = _head + index;
		if (i >= _capacity)
			i -= _capacity;
		return _elements[i];
	}

	int find(const E & e) {
		for (int i = 0; i < _length; ++ i) {
			int j = _head + i;
			if (j >= _capacity)
				j -= _capacity;
			if (_elements[j] == e)
				return i;
		}
		return -1; // 失败
	}

	void insert(int index, const E & e) {
		if (index < 0 or index > _length)
			_throw_exception(index, _length+1);
		if (_length == _capacity) {
			_resize(2 * _capacity);
		}
		for (int i = _length-1; i >= index; -- i) {
			int j = _head + i + 1;
			if (j >= _capacity)
				j -= _capacity;
			int k = _head + i;
			if (k >= _capacity)
				k -= _capacity;
			_elements[j] = _elements[k];
		}
		int i = _head + index;
		if (i >= _capacity)
			i -= _capacity;
		_elements[i] = e;
		++ _length;
	}

	void remove(int index) {
		if (index < 0 or index >= _length)
			_throw_exception(index, _length);
		if (index < _length/2) {
			for (int i = index - 1; i >= 0; -- i) {
				int j = _head + i + 1;
				if (j >= _capacity)
					j -= _capacity;
				int k = _head + i;
				if (k >= _capacity)
					k -= _capacity;
				_elements[j] = _elements[k];
			}
			++ _head;
			if (_head >= _capacity)
				_head -= _capacity;
		}
		else {
			for (int i = index; i < _length-1; ++ i) {
				int j = _head + i;
				if (j >= _capacity)
					j -= _capacity;
				int k = _head + i + 1;
				if (k >= _capacity)
					k -= _capacity;
				_elements[j] = _elements[k];
			}		
		}
		-- _length;
	}

	// stack operations

	const E & top() const {
		return get(_length-1);
	}

	E & top() {
		return get(_length-1);
	}

	void push(const E & e) {
		insert(_length, e);
	}

	void pop() {
		-- _length;
	}

	// queue operations

	const E & head() const {
		return get(0);
	}

	E & head() {
		return get(0);
	}

	void enqueue(const E & e) {
		insert(_length, e);
	}

	void dequeue() {
		++ _head;
		if (_head >= _capacity)
			_head -= _capacity;
		-- _length;
	}

	// rand

	void resize(int length) {
		_resize(length);
	}

	void rand(int length, int min, int max) {
		if (not _srand) {
			srand((int)time(0));
			_srand = true;
		}
		if (_length!=length or _head!=0)
			_resize(length);
		int range = max-min+1;
		_length = length;
		I(i, _length)
			_elements[i] = min + ::rand() % range;
	}

	void insertion_sort() { // O(n^2), 空间复杂度 O(1)
		if (_head!=0)
			_resize(_length); // 使_head==0
		for (int i = 1; i < _length; ++ i) { // O(n)
			E e_i = _elements[i];
			int j = i;
			for (; j > 0; -- j) { // O(n)
				E e_j = _elements[j-1];
				if (e_j <= e_i) break; // 换成<排序仍然正确，
										// 但不再是稳定排序
				_elements[j] = e_j;
			}
			_elements[j] = e_i;
		}
	}

	void binary_insertion_sort() { // O(n^2), 空间复杂度 O(1)
		if (_head!=0)
			_resize(_length); // 使_head==0
		for (int i = 1; i < _length; ++ i) { // O(n)
			E e_i = _elements[i];
			int low = 0;
			int high = i;
			while (low < high) { // O(logn)
				int mid = (low+high-1)/2;
				if (_elements[mid] <= e_i) low = mid+1;
				else high = mid;
			}
			for (int j = i; j > high; -- j) // O(n)
				_elements[j] = _elements[j-1];
			_elements[high] = e_i;
		}
	}

	void bubble_sort() { // O(n^2), 空间复杂度 O(1)
		if (_head!=0)
			_resize(_length); // 使_head==0
		bool sorted = false;
		// 把 0..i 位置中的最大值放入 i
		for (int i = _length-1; (i > 0) and (not sorted); -- i) { // O(n)
			sorted = true;
			for (int j = 0; j < i; ++ j) {
				E e_j = _elements[j];
				E e_j_1 = _elements[j+1];
				if (e_j <= e_j_1) continue;
				sorted = false;
				_elements[j] = e_j_1;
				_elements[j+1] = e_j;
			}
		}
	}

	void quick_sort(int low=0, int high=-1) { // O(nlogn)
		if (_head!=0)
			_resize(_length); // 使_head==0
		if (high==-1)
			high = _length;
		if (low+1 >= high) return;
		E pivot = _elements[low];
		// cout << "pivot " << pivot << endl;
		int front = low;
		int end = high;
		while (true) {
			-- end;
			while (front < end and not (_elements[end] <= pivot))
				-- end;
			if (front==end) break;
			_elements[front] = _elements[end];
			++ front;
			while (front < end and _elements[front] <= pivot)
				++ front;
			if (front==end) break;
			_elements[end] = _elements[front];
		}
		_elements[front] = pivot;
		quick_sort(low, front); // 存储 O(logn)
		quick_sort(front+1, high);
	}

	void selection_sort() { // O(n^2)
		for (int i = _length-1; i > 0; -- i) { // O(n)
			// 选择 0..i 中的最大者 放入 i
			E max = _elements[i];
			int max_index = i;
			for (int j = 0; j < i; ++ j)
				if (max <= _elements[j]) { // O(n)
					max = _elements[j];
					max_index = j;
				}
			if (max_index != i)
				swap(_elements[max_index], _elements[i]);
		}
	}

	void heap_adjust(int i=0, int size=-1) { // 大顶堆 reheap-down
		if (_head!=0)
			_resize(_length);
		if (size==-1)
			size = _length;
		while (i<size) {
			int max_child = -1;
			if (2*i+1 < size)
				max_child = 2*i+1;
			if (2*i+2 < size and _elements[2*i+1] <= _elements[2*i+2])
				max_child = 2*i+2;
			if (max_child==-1 or not (_elements[i] <= _elements[max_child]))
				return;
			swap(_elements[i], _elements[max_child]);
			i = max_child;
		}
	}

	void heapify() { // 建大顶堆
		for (int i = _length/2; i>=0; -- i)
			heap_adjust(i);
	}

	void heap_sort() {
		heapify();
		// 提取 n-1 次最大值
		for (int i = _length-1; i>0; -- i) {
			swap(_elements[i],_elements[0]);
			heap_adjust(0, i);
		}
	}

	void merge_sort(int low=0, int high=-1) {
		if (_head!=0)
			_resize(_length); // 使_head==0
		if (high==-1)
			high = _length;
		if (high-low <= 1) return;
		int mid = (low+high)/2;
		merge_sort(low, mid);
		merge_sort(mid, high);
		// merge
		E * tmp = new E[high-low]; // 归并需要的额外空间
		for (int i = 0; i < high-low; ++ i)
			tmp[i] = _elements[i+low];
		int idx = low;
		int idx1 = low;
		int idx2 = mid;
		while (idx1<mid or idx2<high) {
			int k = 0;
			if (idx1==mid) k = idx2 ++;
			else if (idx2==high) k = idx1 ++;
			else if (tmp[idx1-low] <= tmp[idx2-low]) k = idx1 ++;
			else k = idx2 ++ ;
			_elements[idx ++] = tmp[k-low];
		}
		delete [] tmp;
	}

	typedef int (*radix_sort_func)(const E & e);

	void radix_sort(List<radix_sort_func> & func) {
		if (_head!=0)
			_resize(_length); // 使_head==0
		for (int r = 0; r < func.size(); ++ r) {
			List<List> buckets;
			for (int i = 0; i < _length; ++ i) {
				E e = _elements[i];
				int radix_index = func.get(r)(e);
				while (buckets.size() <= radix_index)
					buckets.push(List());
				buckets.get(radix_index).push(e);
			}
			clear();
			for (int i = 0; i < buckets.size(); ++ i)
				for (int j = 0; j < buckets.get(i).size(); ++ j)
					push(buckets.get(i).get(j));
		}
	}

};

template <typename E>
bool List<E>::_srand = false;

// 输入输出

template <typename E>
ostream & operator << (ostream & out, const List<E> & list) {
	int n = list.size();
	out << n << endl;
	I(i, n)
		out << list.get(i) << " ";
	return out;
}

template <typename E>
istream & operator >> (istream & in, List<E> & list) {
	list.clear();
	int size;
	in >> size;
	I(i, size) {
		E e;
		in >> e;
		list.push(e);
	}
	return in;
}

template <typename E>
List<E> load_list(const string & path) {
	List<E> list;
	ifstream in(path.c_str());
	if (in.fail())
		throw runtime_error("Failed to load list");
	in >> list;
	in.close();
	return list;
}

template <typename E>
void save_list(const List<E> & list, const string & path) {
	ofstream out(path.c_str());
	if (out.fail())
		throw runtime_error("Failed to save list");
	out << list;
	out.close();
}

#endif