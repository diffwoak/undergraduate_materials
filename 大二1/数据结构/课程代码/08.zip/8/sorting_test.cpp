
#include "list.cpp"
#include <iostream>
using namespace std;
#include <assert.h>

// 测试: g++ -g -fno-omit-frame-pointer -fsanitize=address -fPIE -std=c++11 sorting_test.cpp
//		ASAN_OPTIONS=detect_leaks=1 ./a.out

int radix_func1(const double & e) {
	return int(e)%10;
}
int radix_func2(const double & e) {
	return int(e/10)%10;
}

void test() {
	List<double> rand_list;
	rand_list.rand(100, 11, 99);

	List<double> list_ = rand_list;
	list_.insertion_sort();
	// cout << list_ << endl;

	List<double> list;
	list = rand_list;
	list.binary_insertion_sort();
	assert(list_==list);

	list = rand_list;
	list.bubble_sort();
	assert(list_==list);

	list = rand_list;
	list.quick_sort();
	assert(list_==list);

	list = rand_list;
	list.selection_sort();
	assert(list_==list);

	list = rand_list;
	list.selection_sort();
	assert(list_==list);

	list = rand_list;
	list.heap_sort();
	assert(list_==list);

	list = rand_list;
	list.merge_sort();
	assert(list_==list);

	list = rand_list;
	List<List<double>::radix_sort_func> radix_sort_func;
	radix_sort_func.push(radix_func1);
	radix_sort_func.push(radix_func2);
	list.radix_sort(radix_sort_func);
	assert(list_==list);

}

int main() {
	for (int i = 0; i < 100; ++ i)
		test();
}