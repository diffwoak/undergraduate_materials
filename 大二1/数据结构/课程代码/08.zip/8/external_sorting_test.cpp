
#include "external_sorting.cpp"

/* 测试: 
g++ -g -fno-omit-frame-pointer -fsanitize=address -fPIE -std=c++11 external_sorting_test.cpp
ASAN_OPTIONS=detect_leaks=1 ./a.out
*/

#include <iostream>
#include <fstream>
using namespace std;
#include<time.h>
#include<stdlib.h>
#include<stdio.h>
#include <cmath>

template <typename E>
void create_random_file(const char file[], size_t size, 
						void (* random_data_generator)(int size, E data[])) {
	cout << "正在产生数据 " << size << " 个，类型: " << typeid(E).name() << " ..." << endl;
	fstream fs(file, ios::out|ios::binary);
	const int buf_size = 1024;
	E buf[buf_size];
	size_t num_bufs_ = size/buf_size;
	size_t num_bufs = (size_t)ceil(num_bufs_);
	int total_written = 0;
	for (size_t i = 0; i < num_bufs; ++ i) {
		random_data_generator(buf_size, buf);
		int write_size = (num_bufs_!=num_bufs and i==num_bufs-1) ? 
						(size%buf_size): buf_size;
		total_written += write_size;
		fs.write((char *)&buf, sizeof(E)*write_size);
	}
	assert (size==total_written);
	fs.close();
}

void random_double_generator(int size, double data[]) {
	double min=0, max=1000;
	static bool _srand = false;
	if (not _srand) {
		srand((int)time(0));
		_srand = true;
	}
	for (int i = 0; i < size; ++ i) {
    	data[i] = (double)rand() / RAND_MAX;
    	data[i] = min + (max-min) * data[i];
	}
}

void _check_head_and_tail(const char file[]) {
	ifstream fin(file, ios::in|ios::binary);
	const int size = 8;
	double data[size];
	fin.read((char *)&data, sizeof(double)*size);
	for (int i = 0; i < size; ++ i)
		cout << data[i] << " ";
	cout << endl;
	fin.seekg(-sizeof(double)*size, ios::end);
	fin.read((char *)&data, sizeof(double)*size);
	for (int i = 0; i < size; ++ i)
		cout << data[i] << " ";
	cout << endl;
	fin.close();
}

void _check_order(const char file[]) {
	ifstream fin(file, ios::in|ios::binary);
	int i = 0;
	double prev = 0;
	while (fin) {
		double data;
		fin.read((char*)&data, sizeof(double));
		if (! fin) break;
		if (prev > data)
			cout << i << " " << prev << " " << data << endl;
		assert(prev <= data);
		prev = data;
		++ i;
	}
	fin.close();
}

int main() { // 运行 337.02秒, 使用2.15GB SSD空间
	const char infile[] = "external_sorting_test/in";
	const char outfile[] = "external_sorting_test/out";
	remove(outfile);
	int total_size = 1024*1024*1024/sizeof(double); // 要生成1GB的文件 
	create_random_file(infile, total_size, random_double_generator);
	int w = 64*1024/sizeof(double); // 排序段内存大小
	int k = 64; // k路归并排序
	Sort<double>(infile, outfile, w, k);
	remove(infile);
	_check_head_and_tail(outfile);
	_check_order(outfile);
}