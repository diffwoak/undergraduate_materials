
#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
using namespace std;
#include <assert.h>
#include <stdio.h>
#include "list.cpp"
#include "dict.cpp"

template <typename E>
class Sort
{
	class _E
	{
	public:
		int segment_id;
		E e;
		_E() {} 
		_E(int segment_id, const E & e) : 
			segment_id(segment_id), e(e) {}
		bool operator <= (const _E & _e) { // 因为要构造小顶堆，所以把 <= 逻辑上实现为 =>
			if (segment_id > _e.segment_id) return true;
			if (segment_id < _e.segment_id) return false;
			return e >= _e.e;
		}
	};

	class _F
	{
	public:
		_F() {} 
		_F(int file_id) : 
			file_id(file_id), filesize(0) {}
		int file_id;
		int filesize;
		bool operator <= (const _F & _f) { // 因为要构造小顶堆，所以把 < 逻辑上实现为 >
			return filesize >= _f.filesize;
		}
	};

	// 临时文件的路径： external_sorting_test/temp0 ...
	string _temp_file(int file_id) {
		stringstream tmp_file;
		tmp_file << "external_sorting_test/temp" << file_id;
		return tmp_file.str();
	}

	// 读入文件，生成多个临时文件
	List<_F> _create_sorted_segments(const string & file, int read_buf_size) {
		ifstream fin(file.c_str(), ios::in);
		ofstream fout;
		int segment_id = 0;
		int file_id = -1;
		List<_E> heap(read_buf_size); // 小顶堆
		List<_F> tempfiles;
		while (heap.size() < read_buf_size) {
			double data;
			fin.read((char *)&data, sizeof(E));
			if (! fin) break;
			heap.push(_E(segment_id, data));
		}
		heap.heapify();
		while (heap.size() > 0) {
			if (file_id < segment_id) {
				if (file_id!=-1)
					fout.close();
				file_id += 1;
				string temp_file = _temp_file(file_id);
				tempfiles.push(_F(file_id));
				fout.open(temp_file.c_str(), ios::out|ios::binary);
			}
			_E head = heap.head();
			fout.write((char *)&head.e, sizeof(E));
			++ tempfiles.top().filesize;
			if (! fin) {
				swap(heap.head(), heap.top());
				heap.pop();
				heap.heap_adjust();
				if (heap.size()>0 and segment_id<heap.head().segment_id)
					segment_id = heap.head().segment_id;
				continue;		
			}
			double data;
			fin.read((char *)&data, sizeof(E));
			if (! fin)
				continue;
			if (head.e <= data)
				heap.head().e = data;
			else
				heap.head() = _E(segment_id+1, data);
			heap.heap_adjust();
			if (segment_id < heap.head().segment_id)
				segment_id = heap.head().segment_id;
		}
		fout.close();
		fin.close();
		return tempfiles;
	}

	void _merge_sort(const string & outfile, List<_F> & tempfiles, int k) {
		List<_F> heap;
		int m = tempfiles.size();
		for (int i = 0; i < m; ++ i)
			heap.push(tempfiles.get(i));
		heap.heapify();
		int num_children = (m-1)%(k-1)+1;
		if (num_children==1)
			num_children = k;
		Dict<int,List<int> > huffman_tree;
		while (heap.size() > 1) {
			_F new_root = _F(tempfiles.size());
			huffman_tree.put(new_root.file_id, List<int>());
			for (int i = 0; i < num_children; ++ i) {
				_F & c = heap.head();
				new_root.filesize += c.filesize;
				huffman_tree.get(new_root.file_id).push(c.file_id);
				if (i == num_children-1)
					heap.head() = new_root;
				else {
					swap(heap.head(), heap.top());
					heap.pop();
				}
				heap.heap_adjust();
			}
			tempfiles.push(new_root);
			num_children = k;
		}
		int root_id = heap.head().file_id;
		// cout << huffman_tree << endl;
		_merge_sort_1(root_id, outfile, huffman_tree);
	}

	class _S
	{
	public:
		int i;
		E e;
		_S() {}
		_S(int i, const E & e): i(i), e(e) {}
		bool operator <= (const _S & s) {
			return e >= s.e;
		}
	};

	void _merge_sort_1(int node_id, const string & outfile,
						Dict<int,List<int> > & huffman_tree) {
		if (not huffman_tree.has(node_id))
			return;
		List<int> & children = huffman_tree.get(node_id);
		for (int i = 0; i < children.size(); ++ i) {
			_merge_sort_1(children.get(i), _temp_file(children.get(i)), huffman_tree);
		}
		ofstream fout(outfile, ios::out|ios::binary);
		assert(fout);
		List<ifstream *> fis;
		for (int i = 0; i < children.size(); ++ i) {
			ifstream * fi = new ifstream(_temp_file(children.get(i)));
			assert (*fi);
			fis.push(fi);
		}
		List<_S> heap;
		for (int i = 0; i < children.size(); ++ i) {
			ifstream * fi = fis.get(i);
			E e;
			fi->read((char *)&e, sizeof(E));
			if (! *fi) {
				fi->close();
				delete fi;
				fis.get(i) = 0;
				continue;
			}
			heap.push(_S(i, e));
		}
		heap.heapify();
		while (heap.size() > 0) {
			_S s = heap.head();
			fout.write((char *)&s.e, sizeof(E));
			ifstream * fi = fis.get(s.i);
			if (fi!=0) {
				E e;
				fi->read((char *)&e, sizeof(E));
				heap.head().e = e;
				if (! *fi) {
					fi->close();
					delete fi;
					fis.get(s.i) = 0;
					fi = 0;
				}
			}
			if (fi==0) {
				swap(heap.head(), heap.top());
				heap.pop();
			}
			heap.heap_adjust();
		}
		fout.close();
		for (int i = 0; i < children.size(); ++ i)
			remove(_temp_file(children.get(i)).c_str());
	}

public:
	Sort(const string & infile, const string & outfile, int w, int k) {
		cout << "正在生成段 ..." << endl;
		List<_F> tempfiles = _create_sorted_segments(infile, w);
		cout << "正在归并 ..." << endl;
		_merge_sort(outfile, tempfiles, k);
	}

};