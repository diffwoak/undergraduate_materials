// 字典(哈希表)

#ifndef __DICT_CPP__
#define __DICT_CPP__

#include <string>
#include <iostream>
#include <fstream>
#include <sstream>
#include <exception>
using namespace std;
#include "list.cpp"

class NoSuchKeyException : public runtime_error {
public:
	NoSuchKeyException(const string & key) : 
		runtime_error(key.c_str()) {}
};

size_t circular_shift(size_t bits, int shift_bits) {
	const int num_bits = 8 * sizeof(size_t);
	shift_bits = shift_bits % num_bits;
	return bits << shift_bits | bits >> (num_bits - shift_bits);
}

size_t hash_function(const string & key) {
	size_t code = 0;
	I(i, key.size())
		code ^= circular_shift(key[i], i * 5);
	return code;
}

size_t hash_function(size_t key) {
	return key;
}

typedef size_t (* hash_function_type)(size_t key);

template <typename K, typename V, hash_function_type HF=hash_function>
class Dict // Dict, HashTable, HashMap, Map
{
	class Tuple // Entry
	{
	public:
		K key;
		V value;
		bool in_use;
		Tuple() : in_use(false) {}
	};

	List<Tuple> tuples;
	size_t _size;

	size_t canonical_index(const K & key) const {
		size_t hash_code = hash_function(key);
		return hash_code % tuples.size();
	}

	// the returned tuple is either empty or with the same key
	size_t indexOfKey(const K & key) const {
		size_t index = canonical_index(key);
		while (true) { // will enter a dead loop if there is not empty tuple
			if (! tuples.get(index).in_use) return index;
			if (tuples.get(index).key == key) return index;
			index = (index + 1) % tuples.size();
		}
	}

	void _throw_exception(const K & key) const {
		stringstream ss;
		ss << "不存在的键: " << key;
		throw NoSuchKeyException(ss.str().c_str());
	}

public:
	Dict() : _size(0) {
		I(i, 2)
			tuples.push(Tuple());
	}

	bool has(const K & key) const {
		size_t index = indexOfKey(key);
		return tuples.get(index).in_use;
	}

	const V & get(const K & key) const {
		size_t index = indexOfKey(key);
		if (! tuples.get(index).in_use) 
			_throw_exception(key);
		return tuples.get(index).value;
	}

	V & get (const K & key) {
		size_t index = indexOfKey(key);
		if (! tuples.get(index).in_use) 
			_throw_exception(key);
		return tuples.get(index).value;
	}

	void _double_tuples() {
		List<Tuple> non_empty_tuples;
		I(i, tuples.size())
			if (tuples.get(i).in_use)
				non_empty_tuples.push(tuples.get(i));
		clear();
		int size = tuples.size();
		I(i, size)
			tuples.push(Tuple());
		I(i, non_empty_tuples.size())
			put(non_empty_tuples.get(i).key, non_empty_tuples.get(i).value);
	}

	void put(const K & key, const V & value) {
		size_t index = indexOfKey(key);
		tuples.get(index).key = key;
		tuples.get(index).value = value;
		if (tuples.get(index).in_use) return;
		tuples.get(index).in_use = true;
		++ _size;
		if (2 * _size > tuples.size()) // make sure empty > size / 2
			_double_tuples();
	}

	static bool _between(size_t hole, size_t canonical, size_t tuple_index) {
		if (hole < tuple_index)
			return canonical > hole && canonical <= tuple_index;
		else
			return canonical > hole || canonical <= tuple_index;
	}

	void remove(const K & key) { 
		size_t index = indexOfKey(key);
		if (! tuples.get(index).in_use) 
			_throw_exception(key);
		tuples.get(index).in_use = false;
		-- _size;
		// if there is a hole between a tuple and its canonical position
		// move the tuple to the hole
		size_t hole = index;
		size_t tuple_index = hole;
		while (true) {
			tuple_index = (tuple_index + 1) % tuples.size();
			if (! tuples.get(tuple_index).in_use) return;
			size_t canonical = canonical_index(tuples.get(tuple_index).key);
			if (_between(hole, canonical, tuple_index)) continue;
			tuples.get(hole) = tuples.get(tuple_index);
			hole = tuple_index;
			tuples.get(hole).in_use = false;
		}
	}

	size_t size() const { return _size; }

	void clear() {
		I(i, tuples.size())
			tuples.get(i).in_use = false;
		_size = 0;
	}

	List<K> keys() const {
		List<K> res;
		I(i, tuples.size())
			if (tuples.get(i).in_use)
				res.push(tuples.get(i).key);
		return res;
	}

	List<V> values() const {
		List<V> res;
		I(i, tuples.size())
			if (tuples.get(i).in_use)
				res.push(tuples.get(i).value);
		return res;
	}

	List<Tuple> items() const {
		List<Tuple> res;
		I(i, tuples.size())
			if (tuples.get(i).in_use)
				res.push(tuples.get(i));
		return res;
	}

	void _inspect() const {
		I(i, tuples.size())
			if (tuples.get(i).in_use)
				cout << "#" << i << " C" << canonical_index(tuples.get(i).key) 
					<< " " << tuples.get(i).key << " " << tuples.get(i).value << endl;
	}
};

// 输入输出

template <typename K, typename V>
ostream & operator << (ostream & out, const Dict<K,V> & dict) {
	int n = dict.size();
	out << n << endl;
	List<K> keys = dict.keys();
	List<V> values = dict.values();
	I(i, n)
		out << keys.get(i) << "\t" << values.get(i) << endl;
	return out;
}

template <typename K, typename V>
istream & operator >> (istream & in, Dict<K,V> & dict) {
	dict.clear();
	int size;
	in >> size;
	I(i, size) {
		K key;
		V val;
		in >> key >> val;
		dict.put(key, val);
	}
	return in;
}

template <typename K, typename V>
Dict<K, V> load_dict(const string & path) {
	Dict<K, V> dict;
	ifstream in(path.c_str());
	if (in.fail())
		throw runtime_error("Failed to load dictionary");
	in >> dict;
	in.close();
	return dict;
}

template <typename K, typename V>
void save_dict(const Dict<K, V> & dict, const string & path) {
	ofstream out(path.c_str());
	if (out.fail())
		throw runtime_error("Failed to save dictionary");
	out << dict;
	out.close();
}

#endif