
/*
测试: g++ -g -fno-omit-frame-pointer -fsanitize=address -fPIE -std=c++11 set_test.cpp
		ASAN_OPTIONS=detect_leaks=1 ./a.out
*/

#include <string>
#include <iostream>
using namespace std;
#include "set.cpp"

int main() {
	int data1[] = {1,2,3,4,5};
	int data2[] = {4,5,6,7,8};
	Set<int> set1;
	I(i, 5) set1.add(data1[i]);
	Set<int> set2;
	I(i, 5) set2.add(data2[i]);
	cout << "set1: " << set1 << endl;
	cout << "set2: " << set2 << endl;
	cout << "set1 == set2: " << (set1 == set2) << endl;
	cout << "set1 != set2: " << (set1 != set2) << endl;
	cout << "set1 == set1: " << (set1 == set1) << endl;
	cout << "set2 != set2: " << (set2 != set2) << endl;
	cout << "set1 | set2: " << (set1 | set2) << endl;
	cout << "set1 & set2: " << (set1 & set2) << endl;
	cout << "set1 ^ set2: " << (set1 ^ set2) << endl;
	cout << "set1 - set2: " << (set1 - set2) << endl;
	cout << "set1 |= set2: " << (set1 |= set2) << endl;
	cout << "set1 -= set2: " << (set1 -= set2) << endl;
	cout << "set1 ^= set2: " << (set1 ^= set2) << endl;
	cout << "set1 &= set2: " << (set1 &= set2) << endl;
}
