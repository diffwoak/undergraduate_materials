
// 哈希集

#ifndef __SET_CPP__
#define __SET_CPP__

#include "dict.cpp"

template <typename E>
class Set // HashSet
{
	Dict<E, char> _dict;

public:
	Set() : _dict() {}

	bool has(const E & e) const {
		return _dict.has(e);
	}

	void add(const E & e) {
		_dict.put(e, 0);
	}

	void remove(const E & e) {
		_dict.remove(e);
	}

	size_t size() const { return _dict.size(); }

	void clear() {
		_dict.clear();
	}

	Set(const List<E> & es) {
		for (int i = 0; i < es.size(); ++ i)
			add(es.get(i));
	}

	operator List<E> () const {
		return _dict.keys();
	}

	bool operator >= (const Set & set) const {
		List<E> es = set;
		for (int i = 0; i < es.size(); ++ i)
			if (! has(es.get(i))) return false;
		return true;
	}

	bool operator <= (const Set & set) const {
		return set >= *this;
	}

	bool operator > (const Set & set) const {
		return *this >= set and size() > set.size;
	}

	bool operator < (const Set & set) const {
		return set > *this;
	}

	bool operator == (const Set & set) const {
		return *this <= set and *this >= set;
	}

	bool operator != (const Set & set) const {
		return ! (*this == set);
	}

	Set operator | (const Set & set) const {
		Set res(*this);
		List<E> es = set;
		for (int i = 0; i < es.size(); ++ i)
			res.add(es.get(i));
		return res;
	}

	Set operator & (const Set & set) const {
		Set res;
		List<E> es = set;
		for (int i = 0; i < es.size(); ++ i)
			if (has(es.get(i)))
				res.add(es.get(i));
		return res;
	}

	Set operator - (const Set & set) const {
		Set res;
		List<E> es = *this;
		for (int i = 0; i < size(); ++ i)
			if (! set.has(es.get(i)))
				res.add(es.get(i));
		return res;
	}

	Set operator ^ (const Set & set) const {
		return (*this | set) - (*this & set);
	}

	Set & operator |= (const Set & set) {
		*this = *this | set;
		return *this;
	}

	Set & operator &= (const Set & set) {
		*this = *this & set;
		return *this;
	}

	Set & operator -= (const Set & set) {
		*this = *this - set;
		return *this;
	}

	Set & operator ^= (const Set & set) {
		*this = *this ^ set;
		return *this;
	}
};

template <typename E>
ostream & operator << (ostream & out, const Set<E> & set) {
	List<E> es = set;
	I(i, es.size())
		out << es.get(i) << " ";
	return out;
}

#endif