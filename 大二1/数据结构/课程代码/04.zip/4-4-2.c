#include <stdio.h>

int double_eq(double * d1, double * d2) {
	return *d1 == *d2;
}
#define ELEM_EQ double_eq
#define ELEM_TYPE double

#include "seq_list.c"

typedef struct {
	int _dims[3];
	List _data;
} Tensor;

int Tensor_init(Tensor * this, int dim1, int dim2, int dim3) {
	if (! (dim1>0 && dim2>0 && dim3>0))
		return -1;
	int num = dim1*dim2*dim3;
	if (List_init(&(this->_data), num))
		return -1;
	double zero = 0;
	for (int i = 0; i < num; ++ i)
		List_insert(&(this->_data), i, &zero);
	this->_dims[0] = dim1;
	this->_dims[1] = dim2;
	this->_dims[2] = dim3;
	return 0;
}

void Tensor_finalize(Tensor * this) {
	List_finalize(&(this->_data));
}

int Tensor_dim(Tensor * this, int index) {
	if (index<0 || index>=3)
		return -1;
	return this->_dims[index];
}

int _Tensor_index(Tensor * this, int index1, int index2, int index3) {
	int dim1 = this->_dims[0];
	int dim2 = this->_dims[1];
	int dim3 = this->_dims[2];
	if (index1<0 || index1>=dim1) return -1;
	if (index2<0 || index2>=dim2) return -1;
	if (index3<0 || index3>=dim3) return -1;
	return index1*dim2*dim3 + index2*dim3 + index3;
}

ELEM_TYPE * Tensor_get(Tensor * this, int index1, int index2, int index3) {
	int index = _Tensor_index(this, index1, index2, index3);
	if (index==-1)
		return 0;
	return List_get(&(this->_data), index);
}

void print(Tensor * this, int dim) {
	for (int i = 0; i < Tensor_dim(this,1); ++ i) {
		for (int j = 0; j < Tensor_dim(this,2); ++ j)
			printf("%.1lf ", *Tensor_get(this, dim, i, j));
		printf("\n");
	}
}

// 测试: gcc -g -fno-omit-frame-pointer -fsanitize=address -fPIE 4-4-2.c
//		ASAN_OPTIONS=detect_leaks=1 ./a.out

int main() {
	Tensor t;
	Tensor_init(&t, 10, 10, 10);
	for (int i = 0; i < 1000; ++ i)
		*List_get(&(t._data), i) = i+1;
	print(&t, 9);
	Tensor_finalize(&t);
}