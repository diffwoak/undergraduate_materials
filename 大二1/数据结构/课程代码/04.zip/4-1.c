#include <string.h>
#include <stdio.h>

int brute_force_search(char S[], char T[]) {
	int s_len = strlen(S);
	int t_len = strlen(T);
	for (int i = 0; i < s_len; ++ i) {
		if (strncmp(S+i, T, t_len) == 0)
			return i;
	}
	return -1;
}

int main()
{
	char S[] = "ababcabcacbab";
	char T[] = "abcac";
	printf("%d\n", brute_force_search(S, T));
	return 0;
}
