#include <stdio.h>

int double_eq(double * d1, double * d2) {
	return *d1 == *d2;
}
#define ELEM_EQ double_eq
#define ELEM_TYPE double

#include "seq_list.c"

typedef struct {
	int _dims[2];
	List _data;
} Matrix;

int Matrix_init(Matrix * this, int dim1, int dim2) {
	if (! (dim1>0 && dim2>0))
		return -1;
	int num = dim1*dim2;
	if (List_init(&(this->_data), num))
		return -1;
	double zero = 0;
	for (int i = 0; i < num; ++ i)
		List_insert(&(this->_data), i, &zero);
	this->_dims[0] = dim1;
	this->_dims[1] = dim2;
	return 0;
}

void Matrix_finalize(Matrix * this) {
	List_finalize(&(this->_data));
}

int Matrix_dim(Matrix * this, int index) {
	if (index<0 || index>=2)
		return -1;
	return this->_dims[index];
}

int _Matrix_index(Matrix * this, int index1, int index2) {
	int dim1 = this->_dims[0];
	int dim2 = this->_dims[1];
	if (index1<0 || index1>=dim1) return -1;
	if (index2<0 || index2>=dim2) return -1;
	return index1*dim2 + index2;
}

ELEM_TYPE * Matrix_get(Matrix * this, int index1, int index2) {
	int index = _Matrix_index(this, index1, index2);
	if (index==-1)
		return 0;
	return List_get(&(this->_data), index);
}

void print(Matrix * this) {
	for (int i = 0; i < Matrix_dim(this,0); ++ i) {
		for (int j = 0; j < Matrix_dim(this,1); ++ j)
			printf("%.1lf ", *Matrix_get(this, i, j));
		printf("\n");
	}
}

// 测试: gcc -g -fno-omit-frame-pointer -fsanitize=address -fPIE 4-4-3-0.c
//		ASAN_OPTIONS=detect_leaks=1 ./a.out

int main() {
	Matrix t;
	Matrix_init(&t, 10, 10);
	for (int i = 0; i < 100; ++ i)
		*List_get(&(t._data), i) = i+1;
	print(&t);
	Matrix_finalize(&t);
}