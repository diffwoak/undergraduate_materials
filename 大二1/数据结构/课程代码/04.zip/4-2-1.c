#include <string.h>
#include <stdio.h>

char next[1000];

void update_next(char T[]) {
	int t_len = strlen(T);
	next[0] = 0;
	for (int i = 1; i < t_len; ++ i) {
		next[i] = 1;
		for (int j = i; j >= 1; -- j)
			if (strncmp(T, T+(i+1-j), j-1) == 0) {
				next[i] = j;
				break;
			}
	}
}

void print_next(char T[]) {
	update_next(T);
	int t_len = strlen(T);
	for (int i = 0; i < t_len; ++ i)
		printf("%c ", T[i]);
	printf("\n");
	for (int i = 0; i < t_len; ++ i)
		printf("%d ", next[i]);
	printf("\n");
}

int KMP_search(char S[], char T[]) {
	update_next(T);
	int s_len = strlen(S);
	int t_len = strlen(T);
	int j = 0;
	for (int i = 0; i < s_len; ++ i) {
		while (1) {
			if (S[i] == T[j]) {
				++ j;
				if (j == t_len) return i + 1 - t_len;
				break;
			}
			if (next[j] == 0) {
				j = 0;
				break;
			}
			j = next[j] - 1;
		}
	}
	return -1;
}

int main()
{
	char S[] = "acabaabaabcacaabc";
	char T[] = "abaabcac";
	// print_next(T);
	printf("%d\n", KMP_search(S, T));
	return 0;
}
