#include <string.h>
#include <stdio.h>

char next[1000];

void update_next(char T[]) { // O(m)
	int t_len = strlen(T);
	next[0] = 0;
	int i = 0;
	int j = -1;
	while (i < t_len) {
		if (j==-1 || T[i]==T[j]) { ++i; ++j; next[i]=j+1; }
		else j = next[j]-1;
	}
}

void print_next(char T[]) {
	update_next(T);
	int t_len = strlen(T);
	for (int i = 0; i < t_len; ++ i)
		printf("%c ", T[i]);
	printf("\n");
	for (int i = 0; i < t_len; ++ i)
		printf("%d ", next[i]);
	printf("\n");
}

int KMP_search(char S[], char T[]) {
	update_next(T);
	int s_len = strlen(S);
	int t_len = strlen(T);
	int i = -1;
	int j = -1;
	while (i<s_len && j<t_len) {
		if (j==-1 || S[i]==T[j]) { ++i; ++j; }
		else j = next[j]-1;
	}
	if (j==t_len) return i-t_len;
	return -1;
}

int main()
{
	char S[] = "acabaabaabcacaabc";
	char T[] = "abaabcac";
	print_next(T);
	printf("%d\n", KMP_search(S, T));
	return 0;
}
