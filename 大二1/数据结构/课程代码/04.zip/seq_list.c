
typedef struct
{
	ELEM_TYPE * elements;;
	int length;
	int capacity;
} List; // C++: vector, java: ArrayList 

#include <stdlib.h>

// 基本操作的实现
// 初始化 O(1)
int List_init(List * this, int init_size) {
	this->elements = malloc(sizeof(ELEM_TYPE)*init_size);
	if (this->elements == 0)
		return -1; // 失败
	this->length = 0;
	this->capacity = init_size;
	return 0; // 成功
}

void List_finalize(List * this) {
	free(this->elements);
}

// 取值: O(1)
ELEM_TYPE * List_get(List * this, int index) {
	if (index < 0 || index >= this->length)
		return 0;
	else
		return &this->elements[index];
}

// 查找: 查找操作是根据指定的元素值e, 
//		查找顺序表中第1个与e相等的元素。
//		若查找成功，则返回该元素在表中的位置序号;
//		若查找失败，则返回-1。
//		最块时间复杂度=平均时间复杂度=O(n)
int List_find(List * this, ELEM_TYPE * elem) {
	int i;
	for (i = 0; i < this->length; ++ i)
		if (ELEM_EQ(&this->elements[i], elem))
			return i;
	return -1; // 失败
}

// 插入: O(n)
int List_insert(List * this, int index, ELEM_TYPE * elem) {
	if (index < 0 || index > this->length)
		return -1; // 失败
	int i;
	if (this->length == this->capacity) {
		// 获得更大的存储空间
		this->capacity *= 2;
		ELEM_TYPE * new_elements = 
			malloc(sizeof(ELEM_TYPE)*this->capacity);
		for (i = 0; i < this->length; ++ i)
			new_elements[i] = this->elements[i];
		free(this->elements);
		this->elements = new_elements;
	}
	// 把带插入元素后的元素往后挪 
	for (i = this->length-1; i >= index; -- i)
		this->elements[i+1] = this->elements[i];
	this->elements[index] = *elem;
	++ this->length;
	return 0; // 成功
}

// 删除: 
int List_delete(List * this, int index) {
	if (index < 0 || index >= this->length)
		return -1; // 失败
	int i;
	for (i = index+1; i < this->length; ++ i)
		this->elements[i-1] = this->elements[i];
	-- this->length;
	return 0;
}
