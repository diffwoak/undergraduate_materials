
#define MAX_CODE_LEN 7
#include "huffman.c"

#include "assert.c"

/*
测试: gcc -g -fno-omit-frame-pointer -fsanitize=address -fPIE huffman_test.c
		ASAN_OPTIONS=detect_leaks=1 ./a.out
*/

#define VOCAB_SIZE 7
#define CODE_LEN 7

int main() {
	char W[] = "aeist \n";
	int L[] = {10,15,12,3,4,13,1};
	assert(strlen(W)==VOCAB_SIZE, "字符个数错误");
	assert(sizeof(L)/sizeof(int)==VOCAB_SIZE, "频率个数错误");

	HuffmanCoder * coder = HuffmanCoder_init(VOCAB_SIZE, CODE_LEN, W, L);
	char text[] = "et\n eieeei \na sei ie";
	char code[1000];
	HuffmanCoder_encode(coder, text, code);
	char text2[1000];
	HuffmanCoder_decode(coder, code, text2);

	printf("\nhuffman tree:\n");
	Node_print(coder->_huffman_tree);

	printf("\nhuffman codes:\n");
	for (int i = 0; i < VOCAB_SIZE; ++ i) {
		char text[10];
		_char_to_text(coder->_huffman_codes[i].w, text);
		printf("%s: %s\n", text, coder->_huffman_codes[i].code);
	}

	printf("\ntext: %s\n", text);
	printf("code: %s\n", code);
	printf("size of text: %lu, size of code: %.4lf\n", strlen(text), strlen(code)/8.);
	assert(strcmp(text, text2)==0, "解码错误");

	HuffmanCoder_finalize(coder);
}
