

#include <stdio.h>
#include <string.h>

typedef char text[100];
void text_copy(text * t1, text * t2) {
	strcpy(*t1, *t2);
}
void to_text(text * t1, char t2[]) {
	strcpy(t2, *t1);
}
void from_text(text * t1, char t2[]) {
	strcpy(*t1, t2);
}
#define NODE_ELEM_TYPE text
#define NODE_ELEM_ASSIGN text_copy
#define NODE_ELEM_TO_TEXT to_text
#define NODE_ELEM_FROM_TEXT from_text
#include "tree.c"

#include "reader.c"

char priority(char op1, char op2) {
	if (op2=='(') return '<';
	if (op2==')') return '>';
	if (op1=='(') return '<';
	if (op1=='*' || op1=='/') return '>';
	if (op2=='+' || op2=='-') return '>';
	if (op2=='*' || op2=='/') return '<';
	printf("操作符 %c 后不该出现的操作符 %c\n", op1, op2);
	assert(0, "不该出现的操作符");
	return 0;
}

void _calculate_one(List * OPTR, List * OPND) {
	assert(List_size(OPTR)>=1, "栈中没有足够的操作符号");
	assert(List_size(OPND)>=2, "栈中没有足够的操作数");
	Node * op = *List_top(OPTR);
	List_pop(OPTR);
	Node * operand2 = *List_top(OPND);
	List_pop(OPND);
	Node * operand1 = *List_top(OPND);
	List_pop(OPND);
	Node_insert(op, Node_children_size(op), operand1);
	Node_insert(op, Node_children_size(op), operand2);
	List_push(OPND, &op);
}

int is_op(char text[]) {
	if (strlen(text) != 1)
		return 0;
	if (text[0]=='+' || text[0]=='-' || text[0]=='*' || text[0]=='/')
		return 1;
	if (text[0]=='(' || text[0]==')')
		return 1;
	return 0;
}

int parse_int(char text[]) {
	int n = strlen(text);
	int val = 0;
	for (int i = 0; i < n; ++ i) {
		char msg[100] = "不是正整数: ";
		strcat(msg, text);
		assert(text[i]>='0' && text[i]<='9', msg);
		val = val * 10 + text[i]-'0';
	}
	return val;
}

Node * parse(char expression[]) { // 假设表达式没有语法错误
	Reader * reader = Reader_init(expression);
	List * OPTR = List_init();
	List * OPND = List_init();
	while (Reader_peek(reader) != 0) {
		char * next = Reader_next(reader);
		if (! is_op(next)) {
			Node * n = Node_init();
			from_text(&(n->data), next);
			List_push(OPND, &n);
		}
		else {
			int op = next[0];
			while (List_size(OPTR)>0 && priority((*List_top(OPTR))->data[0],op)=='>') {
				Node * prev_op = *List_top(OPTR);
				if (prev_op->data[0]=='(') {
					assert (op==')', "括号不匹配");
					Node_finalize(prev_op);
					List_pop(OPTR);
					break;
				}
				_calculate_one(OPTR, OPND);
			}
			if (op!=')') {
				Node * n = Node_init();
				from_text(&(n->data), next);
				List_push(OPTR, &n);
			}
		}
	}
	while (List_size(OPTR) > 0)
		_calculate_one(OPTR, OPND);
	assert(List_size(OPND)==1, "栈中还有没处理的操作数");
	Node * result = *List_top(OPND);
	List_finalize(OPND);
	List_finalize(OPTR);
	Reader_finalize(reader);
	return result;
}

int cal(Node * node) {
	if (Node_children_size(node)==0)
		return parse_int(node->data);
	assert(Node_children_size(node)==2, "应该有两个操作数");
	int operand1 = cal(Node_get(node, 0));
	int operand2 = cal(Node_get(node, 1));
	char op = node->data[0];
	char msg[100] = "不合法的操作符 ";
	sprintf(msg+strlen(msg), "%c", op);
	assert(op=='+' || op=='-' || op=='*' || op=='/', msg);
	switch (op) {
		case '+': return operand1+operand2;
		case '-': return operand1-operand2;
		case '*': return operand1*operand2;
		case '/': return operand1/operand2;
	}
	return 0;
}

void test1() {
	Node * tree = parse(
		"( a + b * ( c - d ) - e / f )");
	printf("\n语法树:\n");
	Node_print(tree);
	Node_finalize(tree);
}

void test2() {
	Node * tree = parse("30 * ( 75 - 62 )");
	printf("\n语法树:\n");
	Node_print(tree);
	printf("\n计算结果: %d\n", cal(tree));
	Node_finalize(tree);
}

// 测试: gcc -g -fno-omit-frame-pointer -fsanitize=address -fPIE cal.c
//		ASAN_OPTIONS=detect_leaks=1 ./a.out

int main() {
	test1();
	test2();
}
