
int double_eq(double * d1, double * d2) {
	return *d1 == *d2;
}

#define ELEM_TYPE double
#define ELEM_EQ double_eq

#include "list.c"
#include <stdio.h>

void print(List * list) {
	printf("[");
	for (int i = 0; i < List_size(list); ++ i) {
		if (i != 0) printf(", ");
		printf("%.2lf", *List_get(list, i));
	}
	printf("]\n");
}

// 测试: gcc -g -fno-omit-frame-pointer -fsanitize=address -fPIE list_test.c
//		ASAN_OPTIONS=detect_leaks=1 ./a.out

int main() {
	List * list = List_init();

	// test list
	printf("\nLIST\n");
	for (int i = 0; i < 10; ++ i) {
		double v = 100 + i;
		List_insert(list, List_size(list), &v);
	}
	for (int i = 0; i < 5; ++ i) {
		double v = 1000 + i;
		List_insert(list, 2, &v);
	}
	for (int i = 0; i < 3; ++ i) {
		List_delete(list, 3);
	}
	print(list);
	double v = 103;
	printf("Found %.2lf at: %d\n", v, List_find(list, &v));

	// test stack
	printf("\nSTACK\n");
	List_clear(list);
	for (int i = 0; i < 7; ++ i) {
		double v = 10 + i;
		List_push(list, &v);
	}
	print(list);
	printf("Top: %.2lf\n", *List_top(list));
	for (int i = 0; i < 2; ++ i) {
		List_pop(list);
	}
	print(list);
	printf("Top: %.2lf\n", *List_top(list));
	for (int i = 0; i < 3; ++ i) {
		double v = 100 + i;
		List_push(list, &v);
	}
	print(list);
	printf("Top: %.2lf\n", *List_top(list));
	while (List_size(list) > 0) {
		List_pop(list);
	}
	print(list);

	// test queue
	printf("\nQUEUE\n");
	for (int i = 0; i < 7; ++ i) {
		double v = 10 + i;
		List_enqueue(list, &v);
	}
	print(list);
	printf("Head: %.2lf\n", *List_head(list));
	for (int i = 0; i < 2; ++ i) {
		List_dequeue(list);
	}
	print(list);
	printf("Head: %.2lf\n", *List_head(list));
	for (int i = 0; i < 3; ++ i) {
		double v = 100 + i;
		List_enqueue(list, &v);
	}
	print(list);
	printf("Head: %.2lf\n", *List_head(list));
	while (List_size(list) > 0) {
		List_dequeue(list);
	}
	print(list);
	
	List_finalize(list);
}