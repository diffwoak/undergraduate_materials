
#ifndef __ASSERT_C__
#define __ASSERT_C__

#include <stdio.h>
#include <stdlib.h>

void assert(int predicate, char msg[]) {
	if (! predicate) {
		printf("%s\n", msg);
		exit(1);
	}
}

#endif