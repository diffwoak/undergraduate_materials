// 以下的List数据结构包含了: 顺序表, 顺序栈, 循环队列 中的功能。

typedef struct
{
	ELEM_TYPE * elements;
	int head;
	int length;
	int capacity;
} List;

#include <stdlib.h>

#define INIT_SIZE 2

List * List_init() {
	List * this = malloc(sizeof(List));
	this->elements = malloc(sizeof(ELEM_TYPE) * INIT_SIZE);
	if (this->elements == 0)
		return 0;
	this->head = 0;
	this->length = 0;
	this->capacity = INIT_SIZE;
	return this;
}

void List_finalize(List * this) {
	free(this->elements);
	free(this);
}

int List_size(List * this) {
	return this->length;
}

void List_clear(List * this) {
	this->length = 0;
}

ELEM_TYPE * List_get(List * this, int index) {
	if (index < 0 || index >= this->length)
		return 0;
	int i = this->head + index;
	if (i >= this->capacity)
		i -= this->capacity;
	return &this->elements[i];
}

int List_find(List * this, ELEM_TYPE * elem) {
	for (int i = 0; i < this->length; ++ i) {
		int j = this->head + i;
		if (j >= this->capacity)
			j -= this->capacity;
		if (ELEM_EQ(&this->elements[j], elem))
			return i;
	}
	return -1; // 失败
}

int List_insert(List * this, int index, ELEM_TYPE * elem) {
	if (index < 0 || index > this->length)
		return -1;
	if (this->length == this->capacity) {
		int capacity2 = this->capacity * 2;
		ELEM_TYPE * tmp = malloc(sizeof(ELEM_TYPE) * capacity2);
		if (tmp==0)
			return -1;
		for (int i = 0; i < this->length; ++ i) {
			int j = this->head + i;
			if (j >= this->capacity)
				j -= this->capacity;
			tmp[i] = this->elements[j];
		}
		free(this->elements);
		this->elements = tmp;
		this->capacity = capacity2;
		this->head = 0;
	}
	for (int i = this->length-1; i >= index; -- i) {
		int j = this->head + i + 1;
		if (j >= this->capacity)
			j -= this->capacity;
		int k = this->head + i;
		if (k >= this->capacity)
			k -= this->capacity;
		this->elements[j] = this->elements[k];
	}
	int i = this->head + index;
	if (i >= this->capacity)
		i -= this->capacity;
	this->elements[i] = *elem;
	++ this->length;
	return 0;
}

int List_delete(List * this, int index) {
	if (index < 0 || index >= this->length)
		return -1;
	for (int i = index - 1; i >= 0; -- i) {
		int j = this->head + i + 1;
		if (j >= this->capacity)
			j -= this->capacity;
		int k = this->head + i;
		if (k >= this->capacity)
			k -= this->capacity;
		this->elements[j] = this->elements[k];
	}
	++ this->head;
	if (this->head >= this->capacity)
		this->head -= this->capacity;
	-- this->length;
	return 0;
}

void List_copy(List * this, List * src) {
	this->length = 0; // clear
	int size = src->length;
	for (int i = 0; i < size; ++ i) {
		ELEM_TYPE * e = List_get(src, i);
		List_insert(this, i, e);
	}
}

// stack operations

ELEM_TYPE * List_top(List * this) {
	return List_get(this, this->length-1);
}

int List_push(List * this, ELEM_TYPE * elem) {
	return List_insert(this, this->length, elem);
}

int List_pop(List * this) {
	return List_delete(this, this->length-1);
}

// queue operations

ELEM_TYPE * List_head(List * this) {
	return List_get(this, 0);
}

int List_enqueue(List * this, ELEM_TYPE * elem) {
	return List_insert(this, this->length, elem);
}

int List_dequeue(List * this) {
	return List_delete(this, 0);
}
