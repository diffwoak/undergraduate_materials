
#ifndef __READER_C__
#define __READER_C__

#include <stdlib.h>
#include <string.h>

typedef struct {
	char * _text;
	char ** _symbols;
	int _symbol_count;
	int _next_symbol;
} Reader;

Reader * Reader_init(char text[]) {
	Reader * this = malloc(sizeof(Reader));
	this->_text = malloc(strlen(text)+1);
	strcpy(this->_text, text);
	this->_symbols = malloc(sizeof(char *)*strlen(text));
	this->_symbol_count = 0;
	int n = strlen(text);
	for (int i = 0; i < n; ++ i) {
		if (this->_text[i]==' ')
			this->_text[i] = 0;
		if (this->_text[i]!=0 && (i==0 || this->_text[i-1]==0)) {
			this->_symbols[this->_symbol_count] = this->_text + i;
			++ this->_symbol_count;
		}
	}
	this->_next_symbol = 0;
	return this;
}

void Reader_finalize(Reader * this) {
	free(this->_text);
	free(this->_symbols);
	free(this);
}

char * Reader_peek(Reader * this) {
	if (this->_next_symbol < this->_symbol_count)
		return this->_symbols[this->_next_symbol];
	return 0;
}

char * Reader_next(Reader * this) {
	if (this->_next_symbol < this->_symbol_count)
		return this->_symbols[this->_next_symbol ++];
	return 0;
}

#endif
