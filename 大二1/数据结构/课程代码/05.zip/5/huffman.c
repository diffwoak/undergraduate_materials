
#ifndef __HUFFMAN_C__
#define __HUFFMAN_C__

#include <string.h>
#include <stdio.h>

// build huffman tree node

typedef struct {
	char w[2];
	int l;
} _HuffmanNode;
void _huffman_node_copy(_HuffmanNode * n1, _HuffmanNode * n2) {
	*n1 = *n2;
}
void _char_to_text(char w, char text[]) {
	if (w==' ')
		strcpy(text, "sp");
	else if (w=='\n')
		strcpy(text, "nl");
	else {
		text[0] = w;
		text[1] = 0;
	}
}
void _huffman_node_to_text(_HuffmanNode * n, char text[]) {
	_char_to_text(n->w[0], text);
	sprintf(text+strlen(text), "/%d", n->l);
}
void _huffman_node_from_text(_HuffmanNode * n, char text[]) {
	strcpy(n->w, text);
}
#define NODE_ELEM_TYPE _HuffmanNode
#define NODE_ELEM_ASSIGN _huffman_node_copy
#define NODE_ELEM_TO_TEXT _huffman_node_to_text
#define NODE_ELEM_FROM_TEXT _huffman_node_from_text
#include "tree.c"

// build huffman tree

// O(n) 使用Heap可以提高到 O(logn)
int _orderly_insert(List * nodes, Node * node) {
	int n = List_size(nodes);
	for (int i = 0; i < n; ++ i) {
		Node * node2 = *List_get(nodes, i);
		if (node2->data.l > node->data.l) {
			List_insert(nodes, i, &node);
			return i;
		}
	}
	List_insert(nodes, n, &node);
	return n;
}

// O(n^2) 使用Heap可以提高到 O(nlogn)
Node * _build_huffman_tree(int n, char W[], int L[]) {
	List * nodes = List_init();
	for (int i = 0; i < n; ++ i) {
		Node * node = Node_init();
		_HuffmanNode hn;
		hn.w[0] = W[i];
		hn.w[1] = 0;
		hn.l = L[i];
		Node_set_data(node, &hn);
		_orderly_insert(nodes, node);
	}
	while (List_size(nodes) > 1) {
		Node * node1 = *List_get(nodes, 0);
		Node * node2 = *List_get(nodes, 1);
		List_delete(nodes, 0);
		List_delete(nodes, 0);
		Node * node = Node_init();
		_HuffmanNode hn;
		hn.w[0] = 0;
		hn.l = node1->data.l + node2->data.l;
		Node_set_data(node, &hn);
		Node_insert(node, 0, node1);
		Node_insert(node, 1, node2);
		_orderly_insert(nodes, node);
	}
	Node * node = *List_get(nodes, 0);
	List_finalize(nodes);
	return node;
}

// build huffman code

typedef struct {
	char w;
	char * code;
} _HuffmanCode;

// O(n), 用哈希表可以改为 O(1)
int _code_index(char c, _HuffmanCode codes[], int vocab_size) {
	int index = -1;
	for (int i = 0; i < vocab_size; ++ i)
		if (codes[i].w==c)
			index = i;
	char err_msg[] = "没有该字符  ";
	err_msg[strlen(err_msg) - 1] = c;
	assert(index!=-1, err_msg);
	return index;
}

// O(n^2), 平均 O(nlogn)
void _build_huffman_codes_helper(int depth, char prefix[], _HuffmanCode codes[], 
								Node * node, int vocab_size) {
	if (node->data.w[0]==0) { // non-terminal
		assert(Node_children_size(node)==2, "应该是二叉树");
		prefix[depth] = '0';
		_build_huffman_codes_helper(depth+1, prefix, codes, Node_get(node, 0), vocab_size);
		prefix[depth] = '1';
		_build_huffman_codes_helper(depth+1, prefix, codes, Node_get(node, 1), vocab_size);
	}
	else {
		assert(Node_children_size(node)==0, "应该是叶子");
		// O(n), 用哈希表可以改为 O(1)
		int index = _code_index(node->data.w[0], codes, vocab_size);
		prefix[depth] = 0;
		strcpy(codes[index].code, prefix); // O(n), 平均O(logn)
	}
}

void _build_huffman_codes(_HuffmanCode codes[], Node * huffman_tree, 
							int vocab_size, char W[]) {
	for (int i = 0; i < vocab_size; ++ i)
		codes[i].w = W[i];
	char prefix[MAX_CODE_LEN+1];
	// 递归次数=结点数=O(n)
	_build_huffman_codes_helper(0, prefix, codes, huffman_tree, vocab_size);
}

// encode & decode

void _huffman_encode(_HuffmanCode codes[], int vocab_size, 
					char text[], char code[]) {
	int n = strlen(text);
	int s = 0;
	for (int i = 0; i < n; ++ i) {
		char c = text[i];
		// O(n), 用哈希表可以改为 O(1)
		int index = _code_index(c, codes, vocab_size);
		strcpy(code+s, codes[index].code);
		s += strlen(codes[index].code);
	}
}

void _huffman_decode_helper(Node * node, char code[], int * s, char ** t) {
	if (node->data.w[0]==0) { // non-terminal
		assert(Node_children_size(node)==2, "应该是二叉树");
		int c = code[*s] - '0';
		++ *s;
		_huffman_decode_helper(Node_get(node,c), code, s, t);
	}
	else {
		assert(Node_children_size(node)==0, "应该是叶子");
		**t = node->data.w[0];
		++ *t;
	}
}

void _huffman_decode(Node * huffman_tree, char code[], char text[]) {
	int n = strlen(code);
	int s = 0;
	char * t = text;
	while (s < n) {
		_huffman_decode_helper(huffman_tree, code, &s, &t);
	}
	*t = 0;
}

// OOP encapsulation

typedef struct {
	int _vocab_size;
	int _code_len;
	Node * _huffman_tree;
	_HuffmanCode * _huffman_codes;
} HuffmanCoder;

HuffmanCoder * HuffmanCoder_init(int vocab_size, int code_len, char W[], int L[]) {
	HuffmanCoder * this = malloc(sizeof(HuffmanCoder));
	this->_vocab_size = vocab_size;
	this->_code_len = code_len;
	this->_huffman_tree = _build_huffman_tree(vocab_size, W, L);
	this->_huffman_codes = malloc(sizeof(_HuffmanCode) * vocab_size);
	for (int i = 0; i < vocab_size; ++ i)
		this->_huffman_codes[i].code = malloc(code_len+1);
	_build_huffman_codes(this->_huffman_codes, this->_huffman_tree, vocab_size, W);
	return this;
}

void HuffmanCoder_finalize(HuffmanCoder * this) {
	Node_finalize(this->_huffman_tree);
	for (int i = 0; i < this->_vocab_size; ++ i)
		free(this->_huffman_codes[i].code);
	free(this->_huffman_codes);
	free(this);
}

void HuffmanCoder_encode(HuffmanCoder * this, char text[], char code[]) {
	_huffman_encode(this->_huffman_codes, this->_vocab_size, text, code);
}

void HuffmanCoder_decode(HuffmanCoder * this, char code[], char text[]) {
	_huffman_decode(this->_huffman_tree, code, text);
}

#endif
