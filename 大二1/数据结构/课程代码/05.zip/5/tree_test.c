
#include <string.h>
typedef char text[100];
void text_copy(text * t1, text * t2) {
	strcpy(*t1, *t2);
}
void to_text(text * t1, char t2[]) {
	strcpy(t2, *t1);
}
void from_text(text * t1, char t2[]) {
	strcpy(*t1, t2);
}
#define NODE_ELEM_TYPE text
#define NODE_ELEM_ASSIGN text_copy
#define NODE_ELEM_TO_TEXT to_text
#define NODE_ELEM_FROM_TEXT from_text
#include "tree.c"

void test_print(char exp[]) {
	Node * root = Node_init();
	Node_load(root, exp);
	char tmp[1000] = "";
	Node_save(root, tmp);
	assert(strcmp(exp, tmp)==0, "save错误");
	printf("Size: %d\n", Node_size(root));
	printf("Depth: %d\n", Node_depth(root));
	Node_print(root);
	printf("\n");
	Node_finalize(root);
}

void travel_print_pre_order(Node * node) {
	if (node==0) {
		printf("NULL ");
		return;
	}
	printf("%s ", node->data);
	int n = Node_children_size(node);
	if (n >= 1)
		travel_print_pre_order(Node_get(node, 0));
	if (n >= 2)
		travel_print_pre_order(Node_get(node, 1));
}
void travel_print_in_order(Node * node) {
	if (node==0) {
		printf("NULL ");
		return;
	}
	int n = Node_children_size(node);
	if (n >= 1)
		travel_print_in_order(Node_get(node, 0));
	printf("%s ", node->data);
	if (n >= 2)
		travel_print_in_order(Node_get(node, 1));
}
void travel_print_post_order(Node * node) {
	if (node==0) {
		printf("NULL ");
		return;
	}
	int n = Node_children_size(node);
	if (n >= 1)
		travel_print_post_order(Node_get(node, 0));
	if (n >= 2)
		travel_print_post_order(Node_get(node, 1));
	printf("%s ", node->data);
}

void travel_non_recursive(Node * root, tree_visitor visitor) {
	List * stack1 = List_init();
	int stack2[1000] = {0};
	List_push(stack1, &root);
	stack2[0] = 0;
	while (List_size(stack1) > 0) {
		int stack_size = List_size(stack1);
		Node * node = *List_top(stack1);
		int i = -1;
		int n = -1;
		if (node!=0) {
			n = Node_children_size(node);
			i = stack2[stack_size - 1];
		}
		visitor(node, i, n);
		++ stack2[stack_size - 1];
		if (i < n) {
			Node * child = Node_get(node, i);
			List_push(stack1, &child);
			stack2[stack_size] = 0;
		}
		else {
			List_pop(stack1);
		}
	}
	List_finalize(stack1);
}

void visitor_pre_order(Node * node, int i, int n) {
	if (node==0)
		printf("NULL ");
	else if (n==0 || i==0)
		printf("%s ", node->data);
}
void visitor_in_order(Node * node, int i, int n) {
	if (node==0)
		printf("NULL ");
	else if (n==0 || i==1)
		printf("%s ", node->data);
}
void visitor_post_order(Node * node, int i, int n) {
	if (node==0)
		printf("NULL ");
	else if (n==0 || i==n)
		printf("%s ", node->data);
}

void test_travel(char exp[]) {
	Node * root = Node_init();
	Node_load(root, exp);
	Node_binarize(root);
	Node_print(root);
	printf("\n");
	
	Node * copy = Node_init();
	Node_copy(copy, root);
	char exp2[1000] = {0};
	Node_debinarize(copy);
	Node_save(copy, exp2);
	assert(strcmp(exp,exp2)==0, "debinarize错误");
	Node_finalize(copy);

	travel_print_pre_order(root);
	printf("\n");
	travel_print_in_order(root);
	printf("\n");
	travel_print_post_order(root);
	printf("\n");
	printf("\n");

	Node_travel(root, visitor_pre_order);
	printf("\n");
	Node_travel(root, visitor_in_order);
	printf("\n");
	Node_travel(root, visitor_post_order);
	printf("\n");
	printf("\n");

	travel_non_recursive(root, visitor_pre_order);
	printf("\n");
	travel_non_recursive(root, visitor_in_order);
	printf("\n");
	travel_non_recursive(root, visitor_post_order);
	printf("\n");
	printf("\n");

	Node_breadth_first_travel(root, visitor_pre_order);
	printf("\n");
	printf("\n");	

	Node_finalize(root);
}

/*
测试: gcc -g -fno-omit-frame-pointer -fsanitize=address -fPIE tree_test.c
		ASAN_OPTIONS=detect_leaks=1 ./a.out

它位于哪个省份？
IP
├─ NP
│  └─ 它
├─ VP
│  ├─ 位于
│  └─ NP
│     ├─ DP
│     │  ├─ 哪
│     │  └─ CLP
│     │     └─ 个
│     └─ NP
│        └─ 省份
└─ ？
*/
int main() {
	char exp[] = "( IP ( NP ( _ 它 ) ) ( VP ( _ 位于 ) ( NP ( DP ( _ 哪 ) ( CLP ( _ 个 ) ) ) ( NP ( _ 省份 ) ) ) ) ( _ ？ ) )";
	test_print(exp);
	// test_print("( NP ( NP ( _ one ) ) ( VP ( _ designated ) ( ADVP ( NP ( _ a ) ) ( _ especially ) ) ( PP ( _ as ) ( NP ( NP ( _ the ) ( _ first ) ) ( PP ( _ in ) ( NP ( _ order ) ( _ or ) ( _ class ) ) ) ) ) ) )");
	test_travel(exp);
}
