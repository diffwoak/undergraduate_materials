
// 该库参考了 Python 的 anytree.Node

#ifndef __TREE_C__
#define __TREE_C__

#include <stdlib.h>
#include <string.h>
#include "assert.c"

struct _Node;
typedef struct _Node * _NodeAddr;

int _Node_addr_eq(_NodeAddr * na1, _NodeAddr * na2) {
	return *na1 == *na2;
}

#define ELEM_TYPE _NodeAddr
#define ELEM_EQ _Node_addr_eq
#include "list.c"

typedef struct _Node {
	NODE_ELEM_TYPE data;
	List * _children;
	struct _Node * _parent;
}
Node;

Node * Node_init() {
	Node * this = malloc(sizeof(Node));
	this->_parent = 0;
	this->_children = List_init();
	return this;
}

NODE_ELEM_TYPE * Node_get_data(Node * this) {
	return &this->data;
}

void Node_set_data(Node * this, NODE_ELEM_TYPE * data) {
	NODE_ELEM_ASSIGN(&(this->data), data);
}

void Node_finalize(Node * this);

void Node_clear(Node * this) {
	int n = List_size(this->_children);
	for (int i = 0; i < n; ++ i) {
		Node * child = *List_get(this->_children, i);
		if (child != 0)
			Node_finalize(child);
	}
	List_clear(this->_children);
}

void Node_finalize(Node * this) {
	Node_clear(this);
	List_finalize(this->_children);
	free(this);
}

Node * Node_parent(Node * this) {
	return this->_parent;
}

int Node_children_size(Node * this) {
	return List_size(this->_children);
}

Node * Node_get(Node * this, int index) {
	return *List_get(this->_children, index);
}

int Node_index(Node * this, Node * node) {
	int n = List_size(this->_children);
	for (int i = 0; i < List_size(this->_children); ++ i) {
		Node * child = *List_get(this->_children, i);
		if (child == node)
			return i;
	}
	return -1;
}

int Node_remove(Node * this, Node * node) {
	int index = Node_index(this, node);
	if (index == -1)
		return -1;
	if (! List_delete(this->_children, index))
		return -1;
	node->_parent = 0;
	return 0;
}

int Node_insert(Node * this, int index, Node * node) {
	if (node!=0) {
		if (node->_parent!=0)
			if (Node_remove(node->_parent, node))
				return -1;
		node->_parent = this;
	}
	if (List_insert(this->_children, index, &node))
		return -1;
	return 0;
}

int Node_push(Node * this, Node * node) {
	return Node_insert(this, Node_children_size(this), node);
}

Node * Node_set(Node * this, int index, Node * node) {
	Node * replaced = *List_get(this->_children, index);
	if (replaced!=0)
		replaced->_parent = 0;
	*List_get(this->_children, index) = node;
	if (node!=0)
		node->_parent = this;
	return replaced;
}

typedef void (*tree_visitor)(Node * node, int i, int n);

void Node_travel(Node * this, tree_visitor visitor) {
	if (this==0)
		visitor(0, -1, -1);
	else {
		int n = List_size(this->_children);
		visitor(this, 0, n);
		for (int i = 0; i < n; ++ i) {
			Node * child = *List_get(this->_children, i);
			Node_travel(child, visitor);
			visitor(this, i+1, n);
		}
	}
}

void Node_breadth_first_travel(Node * root, tree_visitor visitor) {
	List * queue = List_init();
	List_enqueue(queue, &root);
	while (List_size(queue) > 0) {
		Node * node = *List_head(queue);
		List_dequeue(queue);
		if (node==0) {
			visitor(0, -1, -1);
			continue;
		}
		visitor(node, 0, 0);
		int n = List_size(node->_children);
		for (int i = 0; i < n; ++ i) {
			Node * child = *List_get(node->_children, i);
			List_enqueue(queue, &child);
		}
	}
	List_finalize(queue);
}

void Node_copy(Node * this, Node * src) {
	Node_clear(this);
	Node_set_data(this, &(src->data));
	int n = List_size(src->_children);
	for (int i = 0; i < n; ++ i) {
		Node * src_child = *List_get(src->_children, i);
		Node * child = 0;
		if (src_child!=0) {
			child = Node_init();
			Node_copy(child, src_child);
		}
		List_push(this->_children, &child);
	}
}

int Node_depth(Node * this) {
	int n = List_size(this->_children);
	int max_depth = 0;
	for (int i = 0; i < n; ++ i) {
		Node * child = *List_get(this->_children, i);
		if (child==0) continue;
		int depth = Node_depth(child);
		if (max_depth < depth)
			max_depth = depth;
	}
	return max_depth + 1;
}

int Node_size(Node * this) {
	int n = List_size(this->_children);
	int size = 1;
	for (int i = 0; i < n; ++ i) {
		Node * child = *List_get(this->_children, i);
		if (child!=0)
			size += Node_size(child);
	}
	return size;
}

// utility functions: load, save, print

#include "reader.c"

void _assert_next_eq(Reader * reader, char text[]) {
	char * next = Reader_peek(reader);
	assert(next!=0, "期望还有下一个符号");
	char msg[100] = "期望下一个符号是 ";
	strcat(msg, text);
	assert(strcmp(Reader_peek(reader),text)==0, msg);
	Reader_next(reader);
}

void _assert_next_neq(Reader * reader, char text[]) {
	char * next = Reader_peek(reader);
	assert(next!=0, "期望还有下一个符号");
	char msg[100] = "期望下一个符号不是 ";
	strcat(msg, text);
	assert(strcmp(Reader_peek(reader),text)!=0, msg);
}

void _Node_load_helper(Node * node, Reader * reader) {
	_assert_next_eq(reader, "(");
	_assert_next_neq(reader, "(");
	_assert_next_neq(reader, ")");
	NODE_ELEM_FROM_TEXT(&(node->data), Reader_next(reader));
	assert(Reader_peek(reader)!=0, "期望还有下一个符号");
	if (strcmp(Reader_peek(reader),"(")==0) {
		while (strcmp(Reader_peek(reader),"(")==0) {
			Node * child = Node_init();
			int index = Node_children_size(node);
			Node_insert(node, index, child);
			_Node_load_helper(child, reader);
			if (Node_children_size(child)==0) {
				char text[100];
				NODE_ELEM_TO_TEXT(&(child->data), text);
				if (strcmp(text,"NULL")==0) {
					Node_set(node, index, 0);
					Node_finalize(child);
				}
			}
		}
	}
	else {
		_assert_next_neq(reader, "(");
		_assert_next_neq(reader, ")");
		NODE_ELEM_FROM_TEXT(&(node->data), Reader_next(reader));
	}
	_assert_next_eq(reader, ")");
}

void Node_load(Node * this, char exp[]) {
	Reader * reader = Reader_init(exp);
	Node_clear(this);
	_Node_load_helper(this, reader);
	assert(Reader_peek(reader)==0, "还没有读完所有符号");
	Reader_finalize(reader);
}

void Node_save(Node * this, char exp[]) {
	int n = Node_children_size(this);
	if (n == 0) {
		strcat(exp, "( _ ");
		NODE_ELEM_TO_TEXT(&(this->data), exp+strlen(exp));
		strcat(exp, " )");
	}
	else {
		strcat(exp, "( ");
		NODE_ELEM_TO_TEXT(&(this->data), exp+strlen(exp));
		for (int i = 0; i < n; ++ i) {
			strcat(exp, " ");
			Node * child = Node_get(this, i);
			if (child==0)
				strcat(exp, "( _ NULL )");
			else
				Node_save(child, exp);
		}
		strcat(exp, " )");
	}
}

void _Node_print_helper(Node * this, char t1[], char t2[], char t3[]) {
	char text[100] = "NULL";
	if (this!=0)
		NODE_ELEM_TO_TEXT(&(this->data), text);
	printf("%s%s%s\n", t1, t3, text);
	if (this==0)
		return;
	int n = Node_children_size(this);
	for (int i = 0; i < n; ++ i) {
		Node * child = Node_get(this, i);
		char ct1[1000];
		strcpy(ct1, t1);
		strcat(ct1, t2);
		char * ct2 = (i<n-1?"│  ":"   ");
		char * ct3 = (i<n-1?"├─ ":"└─ ");
		_Node_print_helper(child, ct1, ct2, ct3);
	}
}

void Node_print(Node * this) {
	_Node_print_helper(this, "", "", "");
}

// binarize & debinarize

void Node_binarize(Node * node) {
	int n = Node_children_size(node);
	List * children = List_init();
	List_copy(children, node->_children);
	for (int i = 0; i < n; ++ i) {
		Node * child = *List_get(children, i);
		Node_remove(node, child);
	}
	Node_push(node, 0);
	Node_push(node, 0);
	Node * parent = node;
	for (int i = 0; i < n; ++ i) {
		Node * child = *List_get(children, i);
		Node_binarize(child);
		assert(Node_children_size(child)==2, "应该是二叉树");
		Node_set(parent, (i==0 ? 0 : 1), child);
		parent = child;
	}
	List_finalize(children);
}

List * Node_debinarize(Node * node) {
	int n = Node_children_size(node);
	assert(n==2, "必须是二叉树");
	Node * left = Node_get(node, 0);
	Node * right = Node_get(node, 1);
	Node_remove(node, left);
	Node_remove(node, right);
	List * children = 0;
	if (left != 0) {
		children = Node_debinarize(left);
		if (children==0)
			children = List_init();
		List_insert(children, 0, &left);
	}
	List * siblings = 0;
	if (right != 0) {
		siblings = Node_debinarize(right);
		if (siblings==0)
			siblings = List_init();
		List_insert(siblings, 0, &right);
	}
	if (children != 0) {
		n = List_size(children);
		for (int i = 0; i < n; ++ i) {
			Node * child = *List_get(children, i);
			Node_push(node, child);
		}
		List_finalize(children);
	}
	return siblings;
}

#endif
