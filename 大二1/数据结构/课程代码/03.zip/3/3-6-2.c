
// 测试: gcc -g -fno-omit-frame-pointer -fsanitize=address -fPIE 3-6-2.c
//		ASAN_OPTIONS=detect_leaks=1 ./a.out

#include <stdio.h>

int char_eq(char * c1, char * c2) {
	return *c1 == *c2;
}

#define ELEM_TYPE char
#define ELEM_EQ char_eq

#include "stack.c"

int check_bracket_matching(char expression[]) { // 括号匹配的检验
	Stack S;
	Stack_init(&S);
	int flag = 1;
	for (int i = 0; expression[i]!=0 && flag==1; ++ i) {
		char ch = expression[i];
		if (ch=='(' || ch=='[')
			Stack_push(&S, &ch);
		else if (ch==')' || ch==']') {
			char expected = (ch==')' ? '(' : '[');
			if (Stack_size(&S)>0 && *Stack_top(&S)==expected)
				Stack_pop(&S);
			else
				flag = 0;
		}
	}
	if (Stack_size(&S) > 0)
		flag = 0;
	Stack_finalize(&S);
	return flag;
}

int main() {
	printf("%d\n", check_bracket_matching("(()[]))"));
	printf("%d\n", check_bracket_matching("(()] "));
	printf("%d\n", check_bracket_matching("(()[])"));
	printf("%d\n", check_bracket_matching("[()] "));
}
