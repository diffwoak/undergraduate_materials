
// 测试: gcc -g -fno-omit-frame-pointer -fsanitize=address -fPIE 3-6-1.c
//		ASAN_OPTIONS=detect_leaks=1 ./a.out

#include <stdio.h>

int int_eq(int * d1, int * d2) {
	return *d1 == *d2;
}
#define ELEM_EQ int_eq
#define ELEM_TYPE int
#include "stack.c"

int main() {
	Stack S;
	Stack_init(&S);
	int N;
	scanf("%d", &N);
	while (N > 0) {
		int e = N%8;
		Stack_push(&S, &e);
		N = N/8;
	}
	while (Stack_size(&S) > 0) {
		int e = *Stack_top(&S);
		Stack_pop(&S);
		printf("%d", e);
	}
	printf("\n");
	Stack_finalize(&S);
}
