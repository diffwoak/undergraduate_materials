
#include <stdio.h>
#include <string.h>

typedef struct {
	char name[20];
} Person;

int Person_eq(Person * p1, Person * p2) {
	return strcmp(p1->name, p2->name) == 0;
}

#define ELEM_TYPE Person
#define ELEM_EQ Person_eq

#include "queue.c"

// 测试: gcc -g -fno-omit-frame-pointer -fsanitize=address -fPIE 3-6-4.c
//		ASAN_OPTIONS=detect_leaks=1 ./a.out

#include <stdio.h>

int main() {
	char * dancers[] = { "M1","M2","F1","F2","F3","F4","M3","M4","M5" };
	Queue male;
	Queue female;
	Queue_init(&male);
	Queue_init(&female);
	for (int i = 0; i < sizeof(dancers)/sizeof(char *); ++ i) {
		Person p;
		strcpy(p.name, dancers[i]);
		if (p.name[0]=='M')
			Queue_enqueue(&male, &p);
		else
			Queue_enqueue(&female, &p);
	}
	while (Queue_size(&male)>0 && Queue_size(&female)>0) {
		Person m = *Queue_head(&male);
		Person f = *Queue_head(&female);
		Queue_dequeue(&male);
		Queue_dequeue(&female);
		printf("%s <--> %s\n", m.name, f.name);
	}
	Queue_finalize(&male);
	Queue_finalize(&female);
}
