
int char_eq(char * c1, char * c2) {
	return *c1 == *c2;
}

#define ELEM_TYPE char
#define ELEM_EQ char_eq

#include "seq_list.c"

typedef struct {
	List list;
} Stack;

// 初始化
int Stack_init(Stack * this) {
	return List_init(&this->list);
}

// 释构
void Stack_finalize(Stack * this) {
	List_finalize(&this->list);
}

// 栈大小
int Stack_size(Stack * this) {
	return (this->list).length;
}

// 取栈顶元素
ELEM_TYPE * Stack_top(Stack * this) {
	return List_get(&(this->list), (this->list).length-1);
}

// 入栈
int Stack_push(Stack * this, ELEM_TYPE * elem) {
	return List_insert(&(this->list), (this->list).length, elem);
}

// 出栈
int Stack_pop(Stack * this) {
	return List_delete(&(this->list), (this->list).length-1);
}

#include <stdio.h>

// 测试: gcc -g -fno-omit-frame-pointer -fsanitize=address -fPIE 3-3-2.c
//		ASAN_OPTIONS=detect_leaks=1 ./a.out

int main() {
	Stack stack;
	Stack_init(&stack);
	for (char c = 'A'; c <= 'Z'; ++ c) {
		Stack_push(&stack, &c);
	}
	while (Stack_size(&stack) > 0) {
		char c = *Stack_top(&stack);
		Stack_pop(&stack);
		printf("%c ", c);
	}
	printf("\n");
	Stack_finalize(&stack);
}