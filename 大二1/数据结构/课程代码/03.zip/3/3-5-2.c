
int char_eq(char * c1, char * c2) {
	return *c1 == *c2;
}

#define ELEM_TYPE char
#define ELEM_EQ char_eq

typedef struct
{
	ELEM_TYPE * elements;;
	int head; // 新增
	int length;
	int capacity;
} Queue;

#include <stdlib.h>
#define INIT_SIZE 100

// 基本操作的实现
// 初始化 O(1)
int Queue_init(Queue * this) {
	this->elements = malloc(sizeof(ELEM_TYPE)*INIT_SIZE);
	if (this->elements == 0)
		return -1; // 失败
	this->head = 0;
	this->length = 0;
	this->capacity = INIT_SIZE;
	return 0; // 成功
}

void Queue_finalize(Queue * this) {
	free(this->elements);
}

int Queue_size(Queue * this) {
	return this->length;
}

void Queue_clear(Queue * this) {
	this->length = 0;
}

// 取值: O(1)
ELEM_TYPE * Queue_head(Queue * this) {
	return &this->elements[this->head];
}

// 删除: 
int Queue_dequeue(Queue * this) {
	if (this->length == 0)
		return -1; // 失败
	++ this->head;
	if (this->head == this->capacity)
		this->head = 0;
	-- this->length;
	return 0;
}

// 插入: O(n)
int Queue_enqueue(Queue * this, ELEM_TYPE * elem) {
	if (this->length == this->capacity) {
		// 获得更大的存储空间
		this->capacity *= 2;
		ELEM_TYPE * tmp = malloc(sizeof(ELEM_TYPE)*this->capacity);
		if (tmp==0) return -1; // 内存申请失败
		for (int i = this->head; i < this->head+this->length; ++ i) {
			int j = (i>=this->capacity ? i-this->capacity: i);
			tmp[i] = this->elements[j];
		}
		free(this->elements);
		this->elements = tmp;
	}
	// 队尾 
	int i = this->head + this->length;
	i = (i>=this->capacity ? i-this->capacity: i);
	this->elements[i] = *elem;
	++ this->length;
	return 0; // 成功
}

#include <stdio.h>

// 测试: gcc -g -fno-omit-frame-pointer -fsanitize=address -fPIE 3-5-2.c
//		ASAN_OPTIONS=detect_leaks=1 ./a.out

int main() {
	Queue queue;
	Queue_init(&queue);
	for (char c = 'A'; c <= 'Z'; ++ c) {
		Queue_enqueue(&queue, &c);
	}
	while (Queue_size(&queue) > 0) {
		char c = *Queue_head(&queue);
		Queue_dequeue(&queue);
		printf("%c ", c);
	}
	printf("\n");
	Queue_finalize(&queue);
}