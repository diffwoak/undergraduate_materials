
#include <stdio.h>

int int_eq(int * d1, int * d2) {
	return *d1 == *d2;
}

#define ELEM_TYPE int
#define ELEM_EQ int_eq

#include "stack.c"

void assert(int predicate, char msg[]) {
	if (! predicate) {
		printf("%s\n", msg);
		exit(1);
	}
}

char priority(char op1, char op2) {
	if (op2=='(') return '<';
	if (op2==')') return '>';
	if (op1=='(') return '<';
	if (op1=='*' || op1=='/') return '>';
	if (op2=='+' || op2=='-') return '>';
	if (op2=='*' || op2=='/') return '<';
	printf("操作符 %c 后不该出现的操作符 %c\n", op1, op2);
	assert(0, "不该出现的操作符");
	return 0;
}

void _calculate_one(Stack * OPTR, Stack * OPND) {
	assert(Stack_size(OPTR)>=1, "栈中没有足够的操作符号");
	assert(Stack_size(OPND)>=2, "栈中没有足够的操作数");
	int op = *Stack_top(OPTR);
	Stack_pop(OPTR);
	int operand2 = *Stack_top(OPND);
	Stack_pop(OPND);
	int operand1 = *Stack_top(OPND);
	Stack_pop(OPND);
	int res;
	switch (op) {
		case '+': res = operand1+operand2; break;
		case '-': res = operand1-operand2; break;
		case '*': res = operand1*operand2; break;
		case '/': res = operand1/operand2; break;
	}
	printf("- %d %c %d = %d\n", operand1, op, operand2, res);
	Stack_push(OPND, &res);
}

char calculate(char expression[]) { // 假设表达式没有语法错误
	Stack OPTR;
	Stack OPND;
	Stack_init(&OPTR);
	Stack_init(&OPND);
	for (int i = 0; expression[i]!=0; ++ i) { // 3*(7-2)
		int ch = expression[i];
		if (ch>='0' && ch<='9') {
			ch -= '0';
			Stack_push(&OPND, &ch);
		}
		else {
			while (Stack_size(&OPTR)>0 && priority(*Stack_top(&OPTR),ch)=='>') {
				int prev_op = *Stack_top(&OPTR);
				if (prev_op=='(') {
					assert (ch==')', "括号不匹配");
					Stack_pop(&OPTR);
					break;
				}
				_calculate_one(&OPTR, &OPND);
			}
			if (ch!=')')
				Stack_push(&OPTR, &ch);
		}
	}
	while (Stack_size(&OPTR) > 0)
		_calculate_one(&OPTR, &OPND);
	assert(Stack_size(&OPND)==1, "栈中还有没处理的操作数");
	char result = *Stack_top(&OPND);
	Stack_finalize(&OPND);
	Stack_finalize(&OPTR);
	return result;
}

// 测试: gcc -g -fno-omit-frame-pointer -fsanitize=address -fPIE 3-6-3.c
//		ASAN_OPTIONS=detect_leaks=1 ./a.out

int main() {
	printf("%d\n", calculate("3*(7-2)"));
}
