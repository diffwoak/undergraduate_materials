
int char_eq(char * c1, char * c2) {
	return *c1 == *c2;
}

#define ELEM_TYPE char
#define ELEM_EQ char_eq

#include "linked_list.c"

typedef struct {
	List list;
} Queue;

// 初始化
int Queue_init(Queue * this) {
	return List_init(&this->list);
}

// 释构
void Queue_finalize(Queue * this) {
	List_finalize(&this->list);
}

// 队列大小
int Queue_size(Queue * this) {
	return (this->list).length;
}

// 取队头元素
ELEM_TYPE * Queue_head(Queue * this) {
	return List_get(&(this->list), 0);
}

// 入队
int Queue_enqueue(Queue * this, ELEM_TYPE * elem) {
	return List_insert(&(this->list), (this->list).length, elem);
}

// 出队
int Queue_dequeue(Queue * this) {
	return List_delete(&(this->list), 0);
}

#include <stdio.h>

// 测试: gcc -g -fno-omit-frame-pointer -fsanitize=address -fPIE 3-5-3.c
//		ASAN_OPTIONS=detect_leaks=1 ./a.out

int main() {
	Queue queue;
	Queue_init(&queue);
	for (char c = 'A'; c <= 'Z'; ++ c) {
		Queue_enqueue(&queue, &c);
	}
	while (Queue_size(&queue) > 0) {
		char c = *Queue_head(&queue);
		Queue_dequeue(&queue);
		printf("%c ", c);
	}
	printf("\n");
	Queue_finalize(&queue);
}