
typedef struct _LLNode {
	ELEM_TYPE data;
	struct _LLNode * prev;
	struct _LLNode * next;
} _LLNode;

typedef struct
{
	_LLNode * head;
	int length;
} List; // C++: list, java: LinkedList 

#include <stdlib.h>

// 基本操作的实现
// 初始化 O(1)
int List_init(List * this) {
	this->head = 0;
	this->length = 0;
	return 0;
}

void List_clear(List * this) {
	int i;
	_LLNode * node = this->head;
	for (i = 0; i < this->length; ++ i) {
		_LLNode * tmp = node;
		node = node->next;
		free(tmp);
	}
	this->length = 0;
	this->head = 0;
}

void List_finalize(List * this) {
	List_clear(this);
}

_LLNode * List_get_node(List * this, int index) {
	if (index < 0 || index >= this->length)
		return 0; // 失败
	_LLNode * node = 0;
	int i;
	if (index < this->length / 2) {
		node = this->head;
		for (i = 0; i < index; ++ i)
			node = node->next;
	}
	else {
		node = this->head;
		for (i = 0; i < this->length-index; ++ i)
			node = node->prev;
	}
	return node;
}

// 取值: O(n)
ELEM_TYPE * List_get(List * this, int index) {
	_LLNode * node = List_get_node(this, index);
	if (node == 0) return 0;
	return &node->data;
}

// 查找: 查找操作是根据指定的元素值e, 
//		查找顺序表中第1个与e相等的元素。
//		若查找成功，则返回该元素在表中的位置序号;
//		若查找失败，则返回-1。
//		最块时间复杂度=平均时间复杂度=O(n)
int List_find(List * this, ELEM_TYPE * elem) {
	_LLNode * node = this->head;
	int i;
	for (i = 0; i < this->length; ++ i) {
		if (ELEM_EQ(&node->data, elem))
			return i;
		node = node->next;
	}
	return -1; // 失败
}

// 插入: O(n),    头尾插入: O(1)
int List_insert(List * this, int index, ELEM_TYPE * elem) {
	if (index < 0 || index > this->length)
		return -1; // 失败
	_LLNode * node = malloc(sizeof(_LLNode));
	node->data = *elem;
	if (this->length == 0) {
		node->prev = node->next = node;
		this->head = node;
	}
	else {
		int next_node_index = index == this->length ? 0 : index;
		_LLNode * next_node = List_get_node(this, next_node_index);
		_LLNode * prev_node = next_node->prev;
		node->prev = prev_node;
		node->next = next_node;
		prev_node->next = node;
		next_node->prev = node;
		if (index == 0)
			this->head = node;
	}
	++ this->length;
	return 0; // 成功
}

// 删除: O(n),    头尾删除: O(1)
int List_delete(List * this, int index) {
	if (index < 0 || index >= this->length)
		return -1; // 失败
	_LLNode * node = List_get_node(this, index);
	_LLNode * prev_node = node->prev;
	_LLNode * next_node = node->next;
	prev_node->next = next_node;
	next_node->prev = prev_node;
	free(node); // 为什么这行不能上移两行？
	if (index == 0)
		this->head = next_node;
	-- this->length;
	if (this->length == 0)
		this->head = 0;
	return 0;
}

// 拷贝
int List_copy(List * this, List * other) {
	List_clear(this);
	_LLNode * other_node = other->head;
	int i;
	for (i = 0; i < other->length; ++ i) {
		if (List_insert(this, this->length, &other_node->data) == -1)
			return -1;
		other_node = other_node->next;
	}
	return 0;
}
