
// 存储表示

typedef struct {
	int exponent; // 指数
	int coefficient; // 系数
} Term;

int Term_eq(Term * val1, Term * val2) {
	return val1->exponent == val2->exponent;
}

int Term_lt(Term * val1, Term * val2) {
	return val1->exponent < val2->exponent;
}

#define ELEM_TYPE Term
#define ELEM_EQ Term_eq
#define ELEM_LT Term_lt

typedef struct _LLNode {
	ELEM_TYPE data;
	struct _LLNode * prev;
	struct _LLNode * next;
} _LLNode;

typedef struct
{
	_LLNode * head;
	int length;
} LinkedList; // C++: list, java: LinkedList 

#include <stdlib.h>

// 基本操作的实现
// 初始化 O(1)
void LinkedList_init(LinkedList * this) {
	this->head = 0;
	this->length = 0;
}

void LinkedList_clear(LinkedList * this) {
	int i;
	_LLNode * node = this->head;
	for (i = 0; i < this->length; ++ i) {
		_LLNode * tmp = node;
		node = node->next;
		free(tmp);
	}
	this->length = 0;
	this->head = 0;
}

void LinkedList_finalize(LinkedList * this) {
	LinkedList_clear(this);
}

_LLNode * LinkedList_get_node(LinkedList * this, int index) {
	if (index < 0 || index >= this->length)
		return 0; // 失败
	_LLNode * node = 0;
	int i;
	if (index < this->length / 2) {
		node = this->head;
		for (i = 0; i < index; ++ i)
			node = node->next;
	}
	else {
		node = this->head;
		for (i = 0; i < this->length-index; ++ i)
			node = node->prev;
	}
	return node;
}

// 取值: O(n)
ELEM_TYPE * LinkedList_get(LinkedList * this, int index) {
	_LLNode * node = LinkedList_get_node(this, index);
	if (node == 0) return 0;
	return &node->data;
}

// 查找: 查找操作是根据指定的元素值e, 
//		查找顺序表中第1个与e相等的元素。
//		若查找成功，则返回该元素在表中的位置序号;
//		若查找失败，则返回-1。
//		最块时间复杂度=平均时间复杂度=O(n)
int LinkedList_find(LinkedList * this, ELEM_TYPE * elem) {
	_LLNode * node = this->head;
	int i;
	for (i = 0; i < this->length; ++ i) {
		if (ELEM_EQ(&node->data, elem))
			return i;
		node = node->next;
	}
	return -1; // 失败
}

// 插入: O(n),    头尾插入: O(1)
int LinkedList_insert(LinkedList * this, int index, ELEM_TYPE * elem) {
	if (index < 0 || index > this->length)
		return -1; // 失败
	_LLNode * node = malloc(sizeof(_LLNode));
	node->data = *elem;
	if (this->length == 0) {
		node->prev = node->next = node;
		this->head = node;
	}
	else {
		int next_node_index = index == this->length ? 0 : index;
		_LLNode * next_node = LinkedList_get_node(this, next_node_index);
		_LLNode * prev_node = next_node->prev;
		node->prev = prev_node;
		node->next = next_node;
		prev_node->next = node;
		next_node->prev = node;
		if (index == 0)
			this->head = node;
	}
	++ this->length;
	return 0; // 成功
}

// 删除: O(n),    头尾删除: O(1)
int LinkedList_delete(LinkedList * this, int index) {
	if (index < 0 || index >= this->length)
		return -1; // 失败
	_LLNode * node = LinkedList_get_node(this, index);
	_LLNode * prev_node = node->prev;
	_LLNode * next_node = node->next;
	prev_node->next = next_node;
	next_node->prev = prev_node;
	free(node); // 为什么这行不能上移两行？
	if (index == 0)
		this->head = next_node;
	-- this->length;
	if (this->length == 0)
		this->head = 0;
	return 0;
}

// 拷贝
int LinkedList_copy(LinkedList * this, LinkedList * other) {
	LinkedList_clear(this);
	_LLNode * other_node = other->head;
	int i;
	for (i = 0; i < other->length; ++ i) {
		if (LinkedList_insert(this, this->length, &other_node->data) == -1)
			return -1;
		other_node = other_node->next;
	}
	return 0;
}

// 多项式的创建
void polymonial_create(LinkedList * this, int polymonial[][2], int length) {
	LinkedList_clear(this);
	int i;
	for (i = 0; i < length; ++ i) {
		Term t;
		t.exponent = polymonial[i][0];
		t.coefficient = polymonial[i][1];
		LinkedList_insert(this, this->length, &t);
	}
}

// 多项式的相加: O(m+n)
void polymonial_add(LinkedList * this, LinkedList * p1, LinkedList * p2) {
	LinkedList_clear(this);
	while (p1->length > 0 || p2->length > 0) {
		if (p2->length == 0 || (p1->length > 0 &&
			ELEM_LT(LinkedList_get(p1, 0), LinkedList_get(p2, 0))) )
		{
			Term t = *LinkedList_get(p1, 0);
			LinkedList_delete(p1, 0);
			LinkedList_insert(this, this->length, &t);
		}
		else if (p1->length == 0 || (p2->length > 0 &&
			ELEM_LT(LinkedList_get(p2, 0), LinkedList_get(p1, 0))) )
		{
			Term t = *LinkedList_get(p2, 0);
			LinkedList_delete(p2, 0);
			LinkedList_insert(this, this->length, &t);
		}
		else {
			Term t1 = *LinkedList_get(p1, 0);
			LinkedList_delete(p1, 0);
			Term t2 = *LinkedList_get(p2, 0);
			LinkedList_delete(p2, 0);
			t1.coefficient += t2.coefficient;
			if (t1.coefficient != 0)
				LinkedList_insert(this, this->length, &t1);
		}
	}
}

// 多项式的相乘: O(mn)
void polymonial_mul(LinkedList * this, LinkedList * p1, LinkedList * p2) {
	LinkedList_clear(this);
	int i;
	for (i = 0; i < p2->length; ++ i) { // O(n)
		Term * t2 = LinkedList_get(p2, i);
		LinkedList p1_copy;
		LinkedList_init(&p1_copy);
		LinkedList_copy(&p1_copy, p1); // O(m)
		int j;
		for (j = 0; j < p1_copy.length; ++ j) { // O(m)
			Term * t1 = LinkedList_get(&p1_copy, j);
			t1->exponent += t2->exponent;
			t1->coefficient *= t2->coefficient;
		}
		LinkedList tmp;
		LinkedList_init(&tmp);
		polymonial_add(&tmp, this, &p1_copy); // O(m) ?
		LinkedList_copy(this, &tmp); // O(m)
		LinkedList_finalize(&p1_copy); // O(m)
		LinkedList_finalize(&tmp); // O(m)
	}
}

#include <stdio.h>

void polymonial_print(LinkedList * this) {
	int i;
	for (i = 0; i < this->length; ++ i) {
		Term * t = LinkedList_get(this, i);
		printf("%d*x^%d", t->coefficient, t->exponent);
		printf(i == this->length - 1 ? "\n" : " + ");		
	}
}

int main() {
	int A[][2] = {{0,7},{1,3},{8,9},{17,5}};
	int B[][2] = {{1,8},{7,22},{8,-9}};

	LinkedList p1;
	LinkedList_init(&p1);
	LinkedList p2;
	LinkedList_init(&p2);
	LinkedList p3;
	LinkedList_init(&p3);

	// test polymonial_add
	polymonial_create(&p1, A, 4);
	polymonial_create(&p2, B, 3);
	polymonial_add(&p3, &p1, &p2);
	polymonial_print(&p3);

	// test polymonial_mul
	polymonial_create(&p1, A, 4);
	polymonial_create(&p2, B, 3);
	polymonial_mul(&p3, &p1, &p2);
	polymonial_print(&p3);

	LinkedList_finalize(&p1);
	LinkedList_finalize(&p2);
	LinkedList_finalize(&p3);
}
