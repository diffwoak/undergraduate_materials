/*
ADT List {
	数据对象: D={a_i | a_i in ElemSet,i=1,2,...，n,n≥0}
	数据关系: R=(<a七 1,ai>I a仁 1,aiED,i=2,...,n}
	基本操作:
		List_init(L)
			操作结果:构造一个空的线性表L。
		List_finalize(L)
			初始条件:线性表L已存在。 
			操作结果:销毁线性表L。
		List_clear(L)
			初始条件:线性表L已存在。 
			操作结果:将L重置为空表。
		List_isempty(L)
			初始条件:线性表L已存在。
			操作结果:若L为空表，则返回true, 否则返回false。
		List_length(L)
			初始条件:线性表L已存在。
			操作结果:返回L中数据元素个数。
		List_get(L,i) -> e
			操作结果:用e返回L中第1个数据元素的值。
		List_find(L,e) -> i
			初始条件:线性表L已存在。
			操作结果:返回L中第1个值与e相同的元素在L中的位置i。
					若这样的数据元素不存在，则返回值为-1。
		List_prev_elem(L, cur_elem) -> prev_elem
			初始条件:线性表L已存在。
			操作结果:若cur_elem是L的数据元素，且不是第一个，
					则用prev_elem返回其前驱，
					否则操作失败，prev_elem无定义。
		List_next_elem(L,cur_elem) -> next_elem
			初始条件:线性表L已存在。
			操作结果:若cur_elem是L的数据元素，且不是最后一个，
					则用next_elem返回其后继，
					否则操作失败，next_elem无定义。
		List_insert(L,i,e)
			操作结果:在L中第1个位置之前插入新的数据元素e, 
					L的长度加1。
		List_delete(L,i)
			操作结果:删除L的第1个数据元素，L的长度减1。
		List_travel(L,visitor)
			初始条件:线性表L已存在。
			操作结果:对线性表L进行遍历，
					在遍历过程中对L的每个结点访问一次
}
*/

// 存储表示

typedef struct
{
	char isbn[20];	// 图书 ISBN
	char title[20];	// 图书名字
	float price;	// 图书价格
} Book;

#include <string.h>

int Book_eq(Book * book1, Book * book2) {
	return strcmp(book1->isbn, book2->isbn) == 0;
}

#define ELEM_TYPE Book
#define ELEM_EQ Book_eq

typedef struct _LLNode {
	ELEM_TYPE data;
	struct _LLNode * prev;
	struct _LLNode * next;
} _LLNode;

typedef struct
{
	_LLNode * head;
	int length;
} LinkedList; // C++: list, java: LinkedList 

#include <stdlib.h>

// 基本操作的实现
// 初始化 O(1)
void LinkedList_init(LinkedList * this) {
	this->head = 0;
	this->length = 0;
}

void LinkedList_clear(LinkedList * this) {
	int i;
	_LLNode * node = this->head;
	for (i = 0; i < this->length; ++ i) {
		_LLNode * tmp = node;
		node = node->next;
		free(tmp);
	}
	this->length = 0;
	this->head = 0;
}

void LinkedList_finalize(LinkedList * this) {
	LinkedList_clear(this);
}

_LLNode * LinkedList_get_node(LinkedList * this, int index) {
	if (index < 0 || index >= this->length)
		return 0; // 失败
	_LLNode * node = 0;
	int i;
	if (index < this->length / 2) {
		node = this->head;
		for (i = 0; i < index; ++ i)
			node = node->next;
	}
	else {
		node = this->head;
		for (i = 0; i < this->length-index; ++ i)
			node = node->prev;
	}
	return node;
}

// 取值: O(n)
ELEM_TYPE * LinkedList_get(LinkedList * this, int index) {
	_LLNode * node = LinkedList_get_node(this, index);
	if (node == 0) return 0;
	return &node->data;
}

// 查找: 查找操作是根据指定的元素值e, 
//		查找顺序表中第1个与e相等的元素。
//		若查找成功，则返回该元素在表中的位置序号;
//		若查找失败，则返回-1。
//		最块时间复杂度=平均时间复杂度=O(n)
int LinkedList_find(LinkedList * this, ELEM_TYPE * elem) {
	_LLNode * node = this->head;
	int i;
	for (i = 0; i < this->length; ++ i) {
		if (ELEM_EQ(&node->data, elem))
			return i;
		node = node->next;
	}
	return -1; // 失败
}

// 插入: O(n),    头尾插入: O(1)
int LinkedList_insert(LinkedList * this, int index, ELEM_TYPE * elem) {
	if (index < 0 || index > this->length)
		return -1; // 失败
	_LLNode * node = malloc(sizeof(_LLNode));
	node->data = *elem;
	if (this->length == 0) {
		node->prev = node->next = node;
		this->head = node;
	}
	else {
		int next_node_index = index == this->length ? 0 : index;
		_LLNode * next_node = LinkedList_get_node(this, next_node_index);
		_LLNode * prev_node = next_node->prev;
		node->prev = prev_node;
		node->next = next_node;
		prev_node->next = node;
		next_node->prev = node;
		if (index == 0)
			this->head = node;
	}
	++ this->length;
	return 0; // 成功
}

// 删除: O(n),    头尾删除: O(1)
int LinkedList_delete(LinkedList * this, int index) {
	if (index < 0 || index >= this->length)
		return -1; // 失败
	_LLNode * node = LinkedList_get_node(this, index);
	_LLNode * prev_node = node->prev;
	_LLNode * next_node = node->next;
	prev_node->next = next_node;
	next_node->prev = prev_node;
	free(node); // 为什么这行不能上移两行？
	if (index == 0)
		this->head = next_node;
	-- this->length;
	if (this->length == 0)
		this->head = 0;
	return 0;
}

// 拷贝
int LinkedList_copy(LinkedList * this, LinkedList * other) {
	LinkedList_clear(this);
	_LLNode * other_node = other->head;
	int i;
	for (i = 0; i < other->length; ++ i) {
		if (LinkedList_insert(this, this->length, &other_node->data) == -1)
			return -1;
		other_node = other_node->next;
	}
	return 0;
}

// 测试: gcc -g -fno-omit-frame-pointer -fsanitize=address -fPIE 2-5-4.c
//		ASAN_OPTIONS=detect_leaks=1 ./a.out < 2-5-4.c

/*
isbn titile	price
12345678	programming_in_C	10
87654321	data_structure	20
*/

#include <stdio.h>

int main() {
	LinkedList L;
	LinkedList_init(&L);
	int i;
	char buf[200];
	for (i = 0; i < 199; ++ i) // 滤掉前面的行
		gets(buf);

	for (i = 0; i < 2; ++ i) {
		Book book;
		scanf("%s\t%s\t%f", book.isbn, 
				book.title, &book.price);
		printf("%s\t%s\t%f\n", book.isbn,
				book.title, book.price);
		LinkedList_insert(&L, L.length, &book);
	}
	Book cbook;
	strcpy(cbook.isbn, "87654321");
	strcpy(cbook.title, "Hello, C");
	cbook.price = 100;
	LinkedList L2;
	LinkedList_init(&L2);
	LinkedList_copy(&L2, &L);
	printf("%d\n", LinkedList_find(&L2, &cbook));
	LinkedList_finalize(&L);
	LinkedList_finalize(&L2);
}

