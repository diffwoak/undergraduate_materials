/*
ADT List {
	数据对象: D={a_i | a_i in ElemSet,i=1,2,...，n,n≥0}
	数据关系: R=(<a七 1,ai>I a仁 1,aiED,i=2,...,n}
	基本操作:
		List_init(L)
			操作结果:构造一个空的线性表L。
		List_finalize(L)
			初始条件:线性表L已存在。 
			操作结果:销毁线性表L。
		List_clear(L)
			初始条件:线性表L已存在。 
			操作结果:将L重置为空表。
		List_isempty(L)
			初始条件:线性表L已存在。
			操作结果:若L为空表，则返回true, 否则返回false。
		List_length(L)
			初始条件:线性表L已存在。
			操作结果:返回L中数据元素个数。
		List_get(L,i) -> e
			操作结果:用e返回L中第1个数据元素的值。
		List_find(L,e) -> i
			初始条件:线性表L已存在。
			操作结果:返回L中第1个值与e相同的元素在L中的位置i。
					若这样的数据元素不存在，则返回值为-1。
		List_prev_elem(L, cur_elem) -> prev_elem
			初始条件:线性表L已存在。
			操作结果:若cur_elem是L的数据元素，且不是第一个，
					则用prev_elem返回其前驱，
					否则操作失败，prev_elem无定义。
		List_next_elem(L,cur_elem) -> next_elem
			初始条件:线性表L已存在。
			操作结果:若cur_elem是L的数据元素，且不是最后一个，
					则用next_elem返回其后继，
					否则操作失败，next_elem无定义。
		List_insert(L,i,e)
			操作结果:在L中第1个位置之前插入新的数据元素e, 
					L的长度加1。
		List_delete(L,i)
			操作结果:删除L的第1个数据元素，L的长度减1。
		List_travel(L,visitor)
			初始条件:线性表L已存在。
			操作结果:对线性表L进行遍历，
					在遍历过程中对L的每个结点访问一次
}
*/

// 存储表示

typedef struct
{
	char isbn[20];	// 图书 ISBN
	char title[20];	// 图书名字
	float price;	// 图书价格
} Book;

#include <string.h>

int Book_eq(Book * book1, Book * book2) {
	return strcmp(book1->isbn, book2->isbn) == 0;
}

#define ELEM_TYPE Book
#define ELEM_EQ Book_eq

typedef struct
{
	ELEM_TYPE * elements;;
	int length;
	int capacity;
} SeqList; // C++: vector, java: ArrayList 

#include <stdlib.h>
#define INIT_SIZE 100

// 基本操作的实现
// 初始化 O(1)
int List_init(SeqList * this) {
	this->elements = malloc(sizeof(ELEM_TYPE)*INIT_SIZE);
	if (this->elements == 0)
		return -1; // 失败
	this->length = 0;
	this->capacity = INIT_SIZE;
	return 0; // 成功
}

void List_finalize(SeqList * this) {
	free(this->elements);
}

// 取值: O(1)
ELEM_TYPE * List_get(SeqList * this, int index) {
	if (index < 0 || index >= this->length)
		return 0;
	else
		return &this->elements[index];
}

// 查找: 查找操作是根据指定的元素值e, 
//		查找顺序表中第1个与e相等的元素。
//		若查找成功，则返回该元素在表中的位置序号;
//		若查找失败，则返回-1。
//		最块时间复杂度=平均时间复杂度=O(n)
int List_find(SeqList * this, ELEM_TYPE * elem) {
	int i;
	for (i = 0; i < this->length; ++ i)
		if (ELEM_EQ(&this->elements[i], elem))
			return i;
	return -1; // 失败
}

// 插入: O(n)
int List_insert(SeqList * this, int index, ELEM_TYPE * elem) {
	if (index < 0 || index > this->length)
		return -1; // 失败
	int i;
	if (index == this->capacity) {
		// 获得更大的存储空间
		this->capacity *= 2;
		ELEM_TYPE * new_elements = 
			malloc(sizeof(ELEM_TYPE)*this->capacity);
		for (i = 0; i < this->length; ++ i)
			new_elements[i] = this->elements[i];
		free(this->elements);
		this->elements = new_elements;
	}
	// 把带插入元素后的元素往后挪 
	for (i = this->length-1; i >= index; -- i)
		this->elements[i+1] = this->elements[i];
	this->elements[index] = *elem;
	++ this->length;
	return 0; // 成功
}

// 删除: 
int List_delete(SeqList * this, int index) {
	if (index < 0 || index >= this->length)
		return -1; // 失败
	int i;
	for (i = index+1; i < this->length; ++ i)
		this->elements[i-1] = this->elements[i];
	-- this->length;
	return 0;
}

// 测试: gcc 2-4.c ; ./a.out < 2-4.c

/*
isbn titile	price
12345678	programming_in_C	10
87654321	data_structure	20
*/

#include <stdio.h>

int main() {
	SeqList L;
	List_init(&L);
	int i;
	char buf[200];
	for (i = 0; i < 149; ++ i) // 滤掉前面149行
		gets(buf);

	for (i = 0; i < 2; ++ i) {
		Book book;
		scanf("%s\t%s\t%f", book.isbn, 
				book.title, &book.price);
		printf("%s\t%s\t%f\n", book.isbn,
				book.title, book.price);
		List_insert(&L, L.length, &book);
	}
	Book cbook;
	strcpy(cbook.isbn, "12345678");
	strcpy(cbook.title, "Hello, C");
	cbook.price = 100;
	printf("%d\n", List_find(&L, &cbook));
	List_finalize(&L);
}

