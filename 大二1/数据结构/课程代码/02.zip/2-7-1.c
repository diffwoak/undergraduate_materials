
// 存储表示

int int_eq(int * val1, int * val2) {
	return *val1 == *val2;
}

#define ELEM_TYPE int
#define ELEM_EQ int_eq

typedef struct
{
	ELEM_TYPE * elements;;
	int length;
	int capacity;
} SeqList; // C++: vector, java: ArrayList 

#include <stdlib.h>
#define INIT_SIZE 1

// 基本操作的实现
// 初始化 O(1)
int List_init(SeqList * this) {
	this->elements = malloc(sizeof(ELEM_TYPE)*INIT_SIZE);
	if (this->elements == 0)
		return -1; // 失败
	this->length = 0;
	this->capacity = INIT_SIZE;
	return 0; // 成功
}

void List_finalize(SeqList * this) {
	free(this->elements);
}

// 取值: O(1)
ELEM_TYPE * List_get(SeqList * this, int index) {
	if (index < 0 || index >= this->length)
		return 0;
	else
		return &this->elements[index];
}

// 查找: 查找操作是根据指定的元素值e, 
//		查找顺序表中第1个与e相等的元素。
//		若查找成功，则返回该元素在表中的位置序号;
//		若查找失败，则返回-1。
//		最块时间复杂度=平均时间复杂度=O(n)
int List_find(SeqList * this, ELEM_TYPE * elem) {
	int i;
	for (i = 0; i < this->length; ++ i)
		if (ELEM_EQ(&this->elements[i], elem))
			return i;
	return -1; // 失败
}

// 插入: O(n)
int List_insert(SeqList * this, int index, ELEM_TYPE * elem) {
	if (index < 0 || index > this->length)
		return -1; // 失败
	int i;
	if (index == this->capacity) {
		// 获得更大的存储空间
		this->capacity *= 2;
		ELEM_TYPE * new_elements = 
			malloc(sizeof(ELEM_TYPE)*this->capacity);
		for (i = 0; i < this->length; ++ i)
			new_elements[i] = this->elements[i];
		free(this->elements);
		this->elements = new_elements;
	}
	// 把带插入元素后的元素往后挪 
	for (i = this->length-1; i >= index; -- i)
		this->elements[i+1] = this->elements[i];
	this->elements[index] = *elem;
	++ this->length;
	return 0; // 成功
}

// 删除: 
int List_delete(SeqList * this, int index) {
	if (index < 0 || index >= this->length)
		return -1; // 失败
	int i;
	for (i = index+1; i < this->length; ++ i)
		this->elements[i-1] = this->elements[i];
	-- this->length;
	return 0;
}

// 线性表的合并

void List_merge(SeqList * this, SeqList * other) {
	int i;
	for (i = 0; i < other->length; ++ i) {
		int * e = List_get(other, i);
		if (List_find(this, e) == -1)
			List_insert(this, this->length, e);
	}
}

#include <stdio.h>

int main() {
	int A[] = {7,5,3,11};
	int B[] = {2,6,3};
	SeqList LA;
	List_init(&LA);
	int i;
	for (i = 0; i < 4; ++ i)
		List_insert(&LA, LA.length, &A[i]);
	SeqList LB;
	List_init(&LB);
	for (i = 0; i < 3; ++ i)
		List_insert(&LB, LB.length, &B[i]);

	List_merge(&LA, &LB);
	for (i = 0; i < LA.length; ++ i)
		printf("%d ", *List_get(&LA, i));
	printf("\n");

	List_finalize(&LA);
	List_finalize(&LB);
}

