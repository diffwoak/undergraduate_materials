
// 存储表示

int int_eq(int * val1, int * val2) {
	return *val1 == *val2;
}

int int_lt(int * val1, int * val2) {
	return *val1 < *val2;
}

#define ELEM_TYPE int
#define ELEM_EQ int_eq
#define ELEM_LT int_lt

typedef struct
{
	ELEM_TYPE * elements;;
	int length;
	int capacity;
} SeqList; // C++: vector, java: ArrayList 

#include <stdlib.h>
#define INIT_SIZE 1

// 基本操作的实现
// 初始化 O(1)
int List_init(SeqList * this) {
	this->elements = malloc(sizeof(ELEM_TYPE)*INIT_SIZE);
	if (this->elements == 0)
		return -1; // 失败
	this->length = 0;
	this->capacity = INIT_SIZE;
	return 0; // 成功
}

void List_clear(SeqList * this) {
	this->length = 0;
}

void List_finalize(SeqList * this) {
	free(this->elements);
}

// 取值: O(1)
ELEM_TYPE * List_get(SeqList * this, int index) {
	if (index < 0 || index >= this->length)
		return 0;
	else
		return &this->elements[index];
}

// 查找: 查找操作是根据指定的元素值e, 
//		查找顺序表中第1个与e相等的元素。
//		若查找成功，则返回该元素在表中的位置序号;
//		若查找失败，则返回-1。
//		最块时间复杂度=平均时间复杂度=O(n)
int List_find(SeqList * this, ELEM_TYPE * elem) {
	int i;
	for (i = 0; i < this->length; ++ i)
		if (ELEM_EQ(&this->elements[i], elem))
			return i;
	return -1; // 失败
}

// 插入: O(n)
int List_insert(SeqList * this, int index, ELEM_TYPE * elem) {
	if (index < 0 || index > this->length)
		return -1; // 失败
	int i;
	if (index == this->capacity) {
		// 获得更大的存储空间
		this->capacity *= 2;
		ELEM_TYPE * new_elements = 
			malloc(sizeof(ELEM_TYPE)*this->capacity);
		for (i = 0; i < this->length; ++ i)
			new_elements[i] = this->elements[i];
		free(this->elements);
		this->elements = new_elements;
	}
	// 把带插入元素后的元素往后挪 
	for (i = this->length-1; i >= index; -- i)
		this->elements[i+1] = this->elements[i];
	this->elements[index] = *elem;
	++ this->length;
	return 0; // 成功
}

// 删除: 
int List_delete(SeqList * this, int index) {
	if (index < 0 || index >= this->length)
		return -1; // 失败
	int i;
	for (i = index+1; i < this->length; ++ i)
		this->elements[i-1] = this->elements[i];
	-- this->length;
	return 0;
}

// 顺序线性表的合并
void List_merge_sorted(SeqList * this, SeqList * list1, SeqList * list2) {
	List_clear(this);
	int index1 = 0;
	int index2 = 0;
	while (index1 < list1->length || index2 < list2->length) {
		if (index2 == list2->length || (index1 < list1->length &&
			ELEM_LT(List_get(list1, index1), List_get(list2, index2))) )
		{
			List_insert(this, this->length, List_get(list1, index1));
			++ index1;
		}
		else {
			List_insert(this, this->length, List_get(list2, index2));
			++ index2;			
		}
	}
}

#include <stdio.h>

int main() {
	int A[] = {3,5,8,11};
	int B[] = {2,6,8,9,11,15,20};
	SeqList LA;
	List_init(&LA);
	int i;
	for (i = 0; i < 4; ++ i)
		List_insert(&LA, LA.length, &A[i]);
	SeqList LB;
	List_init(&LB);
	for (i = 0; i < 7; ++ i)
		List_insert(&LB, LB.length, &B[i]);
	SeqList LC;
	List_init(&LC);

	List_merge_sorted(&LC, &LA, &LB);
	for (i = 0; i < LC.length; ++ i)
		printf("%d ", *List_get(&LC, i));
	printf("\n");

	List_finalize(&LA);
	List_finalize(&LB);
	List_finalize(&LC);
}

