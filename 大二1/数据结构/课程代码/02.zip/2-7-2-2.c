
// 存储表示

int int_eq(int * val1, int * val2) {
	return *val1 == *val2;
}

int int_lt(int * val1, int * val2) {
	return *val1 < *val2;
}

#define ELEM_TYPE int
#define ELEM_EQ int_eq
#define ELEM_LT int_lt

typedef struct _LLNode {
	ELEM_TYPE data;
	struct _LLNode * prev;
	struct _LLNode * next;
} _LLNode;

typedef struct
{
	_LLNode * head;
	int length;
} LinkedList; // C++: list, java: LinkedList 

#include <stdlib.h>

// 基本操作的实现
// 初始化 O(1)
void LinkedList_init(LinkedList * this) {
	this->head = 0;
	this->length = 0;
}

void LinkedList_clear(LinkedList * this) {
	int i;
	_LLNode * node = this->head;
	for (i = 0; i < this->length; ++ i) {
		_LLNode * tmp = node;
		node = node->next;
		free(tmp);
	}
	this->length = 0;
	this->head = 0;
}

void LinkedList_finalize(LinkedList * this) {
	LinkedList_clear(this);
}

_LLNode * LinkedList_get_node(LinkedList * this, int index) {
	if (index < 0 || index >= this->length)
		return 0; // 失败
	_LLNode * node = 0;
	int i;
	if (index < this->length / 2) {
		node = this->head;
		for (i = 0; i < index; ++ i)
			node = node->next;
	}
	else {
		node = this->head;
		for (i = 0; i < this->length-index; ++ i)
			node = node->prev;
	}
	return node;
}

// 取值: O(n)
ELEM_TYPE * LinkedList_get(LinkedList * this, int index) {
	_LLNode * node = LinkedList_get_node(this, index);
	if (node == 0) return 0;
	return &node->data;
}

// 查找: 查找操作是根据指定的元素值e, 
//		查找顺序表中第1个与e相等的元素。
//		若查找成功，则返回该元素在表中的位置序号;
//		若查找失败，则返回-1。
//		最块时间复杂度=平均时间复杂度=O(n)
int LinkedList_find(LinkedList * this, ELEM_TYPE * elem) {
	_LLNode * node = this->head;
	int i;
	for (i = 0; i < this->length; ++ i) {
		if (ELEM_EQ(&node->data, elem))
			return i;
		node = node->next;
	}
	return -1; // 失败
}

// 插入: O(n),    头尾插入: O(1)
int LinkedList_insert(LinkedList * this, int index, ELEM_TYPE * elem) {
	if (index < 0 || index > this->length)
		return -1; // 失败
	_LLNode * node = malloc(sizeof(_LLNode));
	node->data = *elem;
	if (this->length == 0) {
		node->prev = node->next = node;
		this->head = node;
	}
	else {
		int next_node_index = index == this->length ? 0 : index;
		_LLNode * next_node = LinkedList_get_node(this, next_node_index);
		_LLNode * prev_node = next_node->prev;
		node->prev = prev_node;
		node->next = next_node;
		prev_node->next = node;
		next_node->prev = node;
		if (index == 0)
			this->head = node;
	}
	++ this->length;
	return 0; // 成功
}

// 删除: O(n),    头尾删除: O(1)
int LinkedList_delete(LinkedList * this, int index) {
	if (index < 0 || index >= this->length)
		return -1; // 失败
	_LLNode * node = LinkedList_get_node(this, index);
	_LLNode * prev_node = node->prev;
	_LLNode * next_node = node->next;
	prev_node->next = next_node;
	next_node->prev = prev_node;
	free(node); // 为什么这行不能上移两行？
	if (index == 0)
		this->head = next_node;
	-- this->length;
	if (this->length == 0)
		this->head = 0;
	return 0;
}

// 拷贝
int LinkedList_copy(LinkedList * this, LinkedList * other) {
	LinkedList_clear(this);
	_LLNode * other_node = other->head;
	int i;
	for (i = 0; i < other->length; ++ i) {
		if (LinkedList_insert(this, this->length, &other_node->data) == -1)
			return -1;
		other_node = other_node->next;
	}
	return 0;
}

// 线性表的合并
void LinkedList_merge_sorted(LinkedList * this, 
							LinkedList * list1_, LinkedList * list2_) {
	LinkedList_clear(this);
	LinkedList list1;
	LinkedList_init(&list1);
	LinkedList_copy(&list1, list1_); // O(m)
	LinkedList list2;
	LinkedList_init(&list2);
	LinkedList_copy(&list2, list2_); // O(n)
	while (list1.length > 0 || list2.length > 0) { // O(m+n)
		if (list2.length == 0 || (list1.length > 0 &&
			ELEM_LT(LinkedList_get(&list1, 0), LinkedList_get(&list2, 0))) )
		{
			int val = *LinkedList_get(&list1, 0);
			LinkedList_delete(&list1, 0);
			LinkedList_insert(this, this->length, &val);
		}
		else {
			int val = *LinkedList_get(&list2, 0);
			LinkedList_delete(&list2, 0);
			LinkedList_insert(this, this->length, &val);
		}
	}
	LinkedList_finalize(&list1);
	LinkedList_finalize(&list2);
}

void LinkedList_merge_sorted2(LinkedList * this, 
							LinkedList * list1, LinkedList * list2) {
	LinkedList_clear(this);
	while (list1->length > 0 || list2->length > 0) { // O(m+n)
		if (list2->length == 0 || (list1->length > 0 &&
			ELEM_LT(LinkedList_get(list1, 0), LinkedList_get(list2, 0))) )
		{
			int val = *LinkedList_get(list1, 0);
			LinkedList_delete(list1, 0);
			LinkedList_insert(this, this->length, &val);
		}
		else {
			int val = *LinkedList_get(list2, 0);
			LinkedList_delete(list2, 0);
			LinkedList_insert(this, this->length, &val);
		}
	}
}

void LinkedList_init_with_values(LinkedList * this, int values[], int length) {
	LinkedList_init(this);
	int i;
	for (i = 0; i < length; ++ i)
		LinkedList_insert(this, this->length, &values[i]);
}


#include <stdio.h>

void LinkedList_print(LinkedList * this) {
	int i;
	for (i = 0; i < this->length; ++ i)
		printf("%d ", *LinkedList_get(this, i));
	printf("\n");	
}

int main() {
	int A[] = {3,5,8,11};
	int B[] = {2,6,8,9,11,15,20};
	LinkedList LA;
	LinkedList_init_with_values(&LA, A, 4);
	LinkedList LB;
	LinkedList_init_with_values(&LB, B, 7);
	LinkedList LC;
	LinkedList_init(&LC);

	LinkedList_merge_sorted(&LC, &LA, &LB);
	LinkedList_print(&LC);

	LinkedList_finalize(&LA);
	LinkedList_finalize(&LB);
	LinkedList_finalize(&LC);
}
