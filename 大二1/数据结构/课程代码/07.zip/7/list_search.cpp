
#include "lib/list.cpp"
#include <iostream>
using namespace std;

// 测试: g++ -g -fno-omit-frame-pointer -fsanitize=address -fPIE -std=c++11 list_search.cpp
//		ASAN_OPTIONS=detect_leaks=1 ./a.out

template <typename E>
int binary_search(const List<E> & list, const E & key) {
	int start = 0;
	int end = list.size();
	while (start < end) {
		int mid = (start+end-1) / 2;
		// 查看运行过程中3个值的变化
		// cout << start << " " << mid << " " << end << endl; 
		if (key == list.get(mid))
			return mid;
		if (key < list.get(mid))
			end = mid;
		else
			start = mid + 1;
	}
	return -1;
}

int main() {
	double data[] = {5,16,20,27,30,36,44,55,60,67,71};

	List<double> list;
	for (int i = 0; i < sizeof(data) / sizeof(double); ++ i)
		list.push(data[i]);
	cout << binary_search(list, 27.) << endl;
	cout << binary_search(list, 65.) << endl;

}