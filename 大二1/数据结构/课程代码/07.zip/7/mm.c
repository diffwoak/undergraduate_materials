
#include <stdlib.h>

struct _M
{
	int rows;
	int cols;
	double * data;
};
typedef struct _M M;

M newM(int rows, int cols) {
	M m;
	m.rows = rows;
	m.cols = cols;
	m.data = malloc(sizeof(double)*rows*cols);
	return m;
}
void freeM(M m) {
	free(m.data);
}
#define getM(m,i,j) m.data[i*m.cols+j]

void mm1(M m1, M m2, M m3) {
	for (int i = 0; i < m1.rows; ++ i) {
		for (int j = 0; j < m2.cols; ++ j) {
			double res = 0;
			for (int k = 0; k < m1.cols; ++ k)
				res += getM(m1,i,k) * getM(m2,k,j);
			getM(m3,i,j) = res;
		}
	}
}

void transpose(M m1, M m2) {
	for (int i = 0; i < m1.rows; ++ i) {
		for (int j = 0; j < m1.cols; ++ j) {
			getM(m2,j,i) = getM(m1,i,j);
		}
	}
}

void mm2(M m1, M m2, M m3) {
	M m2_ = newM(m2.cols, m2.rows);
	transpose(m2,m2_);
	for (int i = 0; i < m1.rows; ++ i) {
		for (int j = 0; j < m2_.rows; ++ j) {
			double res = 0;
			for (int k = 0; k < m1.cols; ++ k)
				res += getM(m1,i,k) * getM(m2_,j,k);
			getM(m3,i,j) = res;
		}
	}
	freeM(m2_);
}

int main() {
	int size = 4000;
	M m1 = newM(size,size);
	M m2 = newM(size,size);
	M m3 = newM(size,size);
	mm1(m1, m2, m3); // 429.80s
	mm2(m1, m2, m3); // 155.53s
	freeM(m1);
	freeM(m2);
	freeM(m3);
	return 0;
}