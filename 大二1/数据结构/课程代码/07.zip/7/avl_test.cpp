
#include "avl_tree.cpp"

// 测试: g++ -g -fno-omit-frame-pointer -fsanitize=address -fPIE -std=c++11 avl_test.cpp
//		ASAN_OPTIONS=detect_leaks=1 ./a.out

#include <fstream>
using namespace std;

void avl_test(AVLTree<int> & avl, const char file[], int to_add) {
	cout << file << " +" << to_add << endl;
	ifstream fin(file);
	avl.read(fin);
	fin.close();
	avl.print();
	avl.add(to_add);
	avl.print();
}

int main() {
	AVLTree<int> avl;
	avl_test(avl, "avl_test/7_14_a.txt", 16);
	// 31:2
	// └─ 25:1
	// 25:2
	// ├─ 16:1
	// └─ 31:1
	avl_test(avl, "avl_test/7_14_b.txt", 9);
	// 31:3
	// ├─ 25:2
	// │  ├─ 16:1
	// │  └─ 28:1
	// └─ 47:1
	// 25:3
	// ├─ 16:2
	// │  └─ 9:1
	// └─ 31:2
	//    ├─ 28:1
	//    └─ 47:1
	avl_test(avl, "avl_test/7_14_b.txt", 26);
	// 31:3
	// ├─ 25:2
	// │  ├─ 16:1
	// │  └─ 28:1
	// └─ 47:1
	// 28:3
	// ├─ 25:2
	// │  ├─ 16:1
	// │  └─ 26:1
	// └─ 31:2
	//    └─ 47:1
	avl_test(avl, "avl_test/7_14_b.txt", 30);
	// 31:3
	// ├─ 25:2
	// │  ├─ 16:1
	// │  └─ 28:1
	// └─ 47:1
	// 28:3
	// ├─ 25:2
	// │  └─ 16:1
	// └─ 31:2
	//    ├─ 30:1
	//    └─ 47:1
	avl_test(avl, "avl_test/7_16_a.txt", 69);
	// 31:2
	// └─ 47:1
	// 47:2
	// ├─ 31:1
	// └─ 69:1
	avl_test(avl, "avl_test/7_16_a.txt", 40);
	// 31:2
	// └─ 47:1
	// 40:2
	// ├─ 31:1
	// └─ 47:1
	avl_test(avl, "avl_test/7_16_b.txt", 76);
	// 31:3
	// ├─ 25:1
	// └─ 47:2
	//    ├─ 40:1
	//    └─ 69:1
	// 47:3
	// ├─ 31:2
	// │  ├─ 25:1
	// │  └─ 40:1
	// └─ 69:2
	//    └─ 76:1
	avl_test(avl, "avl_test/7_16_b.txt", 36);
	// 31:3
	// ├─ 25:1
	// └─ 47:2
	//    ├─ 40:1
	//    └─ 69:1
	// 40:3
	// ├─ 31:2
	// │  ├─ 25:1
	// │  └─ 36:1
	// └─ 47:2
	//    └─ 69:1	
	avl_test(avl, "avl_test/7_16_b.txt", 43);
	// 31:3
	// ├─ 25:1
	// └─ 47:2
	//    ├─ 40:1
	//    └─ 69:1
	// 40:3
	// ├─ 31:2
	// │  └─ 25:1
	// └─ 47:2
	//    ├─ 43:1
	//    └─ 69:1
	return 0;
}