
#include <iostream>
#include <fstream>
#include <stdexcept>
using namespace std;
#include<time.h>
#include<stdlib.h>

#include "btree.cpp"

/*
测试: g++ -g -fno-omit-frame-pointer -fsanitize=address -fPIE -std=c++11 btree_test.cpp
		ASAN_OPTIONS=detect_leaks=1 ./a.out
*/

template <typename K, int KS>
void load(BTree<K, KS> & t, const char file[]) {
	cout << file << endl;
	ifstream f(file);
	Node<K> n;
	n.read(f);
	f.close();
	t.from_tree(n);
}

void test2() {
	typedef int K;
	typedef BTree<K,2> T;
	typedef typename T::BTNode N;
	MemoryBTStorage<N> storage;
	T t(storage); // 结点大小: 64
	load(t, "btree_test/7_25_2.txt");
	t.to_tree().print();
	// 0
	// ├─ 37
	// │  ├─ 12
	// │  │  ├─ 3
	// │  │  └─ 12
	// │  └─ 37
	// │     └─ 37
	// └─ 70
	//    ├─ 50
	//    │  └─ 50
	//    └─ 70
	//       ├─ 61
	//       └─ 70

	cout << "+ 30" << endl;
	t.put(30,-1);
	t.to_tree().print();
	// 0
	// ├─ 37
	// │  ├─ 12
	// │  │  ├─ 3
	// │  │  └─ 12
	// │  └─ 37
	// │     ├─ 30
	// │     └─ 37
	// └─ 70
	//    ├─ 50
	//    │  └─ 50
	//    └─ 70
	//       ├─ 61
	//       └─ 70

	cout << "+ 26" << endl;
	t.put(26,-1);
	t.to_tree().print();
	// 0
	// ├─ 12
	// │  └─ 12
	// │     └─ 12
	// │        ├─ 3
	// │        └─ 12
	// └─ 70
	//    ├─ 37
	//    │  ├─ 26
	//    │  │  └─ 26
	//    │  └─ 37
	//    │     ├─ 30
	//    │     └─ 37
	//    └─ 70
	//       ├─ 50
	//       │  └─ 50
	//       └─ 70
	//          ├─ 61
	//          └─ 70

	cout << "- 12" << endl;
	t.remove(12);
	t.to_tree().print();
	// 0
	// ├─ 3
	// │  └─ 3
	// │     └─ 3
	// │        └─ 3
	// └─ 70
	//    ├─ 37
	//    │  ├─ 26
	//    │  │  └─ 26
	//    │  └─ 37
	//    │     ├─ 30
	//    │     └─ 37
	//    └─ 70
	//       ├─ 50
	//       │  └─ 50
	//       └─ 70
	//          ├─ 61
	//          └─ 70

	cout << "- 3" << endl;
	t.remove(3);
	t.to_tree().print();
	// - 3
	// 0
	// ├─ 37
	// │  └─ 37
	// │     ├─ 26
	// │     │  └─ 26
	// │     └─ 37
	// │        ├─ 30
	// │        └─ 37
	// └─ 70
	//    └─ 70
	//       ├─ 50
	//       │  └─ 50
	//       └─ 70
	//          ├─ 61
	//          └─ 70	
}

void test3() {
	typedef int K;
	typedef BTree<K,3> T;
	typedef typename T::BTNode N;
	MemoryBTStorage<N> storage;
	T t(storage); // 结点大小: 72
	load(t, "btree_test/7_25_3.txt");
	t.to_tree().print();
	// 0
	// ├─ 37
	// │  ├─ 12
	// │  │  ├─ 3
	// │  │  └─ 12
	// │  └─ 37
	// │     └─ 37
	// └─ 100
	//    ├─ 50
	//    │  └─ 50
	//    ├─ 70
	//    │  ├─ 61
	//    │  └─ 70
	//    └─ 100
	//       └─ 100

	cout << "+ 30" << endl;
	t.put(30,-1);
	t.to_tree().print();
	// 0
	// ├─ 37
	// │  ├─ 12
	// │  │  ├─ 3
	// │  │  └─ 12
	// │  └─ 37
	// │     ├─ 30
	// │     └─ 37
	// └─ 100
	//    ├─ 50
	//    │  └─ 50
	//    ├─ 70
	//    │  ├─ 61
	//    │  └─ 70
	//    └─ 100
	//       └─ 100

	cout << "+ 26" << endl;
	t.put(26,-1);
	t.to_tree().print();
	// 0
	// ├─ 37
	// │  ├─ 12
	// │  │  ├─ 3
	// │  │  └─ 12
	// │  └─ 37
	// │     ├─ 26
	// │     ├─ 30
	// │     └─ 37
	// └─ 100
	//    ├─ 50
	//    │  └─ 50
	//    ├─ 70
	//    │  ├─ 61
	//    │  └─ 70
	//    └─ 100
	//       └─ 100

	cout << "+ 20" << endl;
	t.put(20,-1);
	t.to_tree().print();
	// + 20
	// 0
	// ├─ 37
	// │  ├─ 12
	// │  │  ├─ 3
	// │  │  └─ 12
	// │  ├─ 26
	// │  │  ├─ 20
	// │  │  └─ 26
	// │  └─ 37
	// │     ├─ 30
	// │     └─ 37
	// └─ 100
	//    ├─ 50
	//    │  └─ 50
	//    ├─ 70
	//    │  ├─ 61
	//    │  └─ 70
	//    └─ 100
	//       └─ 100	

	cout << "- 20" << endl;
	t.remove(20);
	t.to_tree().print();
	// 0
	// ├─ 37
	// │  ├─ 12
	// │  │  ├─ 3
	// │  │  └─ 12
	// │  ├─ 26
	// │  │  └─ 26
	// │  └─ 37
	// │     ├─ 30
	// │     └─ 37
	// └─ 100
	//    ├─ 50
	//    │  └─ 50
	//    ├─ 70
	//    │  ├─ 61
	//    │  └─ 70
	//    └─ 100
	//       └─ 100

	cout << "- 26" << endl;
	t.remove(26);
	t.to_tree().print();
	// 0
	// ├─ 37
	// │  ├─ 12
	// │  │  ├─ 3
	// │  │  └─ 12
	// │  ├─ 30
	// │  │  └─ 30
	// │  └─ 37
	// │     └─ 37
	// └─ 100
	//    ├─ 50
	//    │  └─ 50
	//    ├─ 70
	//    │  ├─ 61
	//    │  └─ 70
	//    └─ 100
	//       └─ 100
}

void test4() {
	typedef int K;
	typedef BTree<K,4> T;
	typedef typename T::BTNode N;
	// FileBTStorage<N> storage("btree_test/4.bin");
	MemoryBTStorage<N> storage;
	T t(storage); // 结点大小: 88
	load(t, "btree_test/7_25_4.txt");
	t.to_tree().print();
	// 0
	// ├─ 37
	// │  ├─ 12
	// │  │  ├─ 3
	// │  │  └─ 12
	// │  └─ 37
	// │     ├─ 30
	// │     └─ 37
	// └─ 100
	//    ├─ 50
	//    │  ├─ 40
	//    │  └─ 50
	//    ├─ 70
	//    │  ├─ 61
	//    │  └─ 70
	//    └─ 100
	//       ├─ 90
	//       └─ 100

	cout << "+ 30" << endl;
	t.put(30,-1);
	t.to_tree().print();

	cout << "- 40" << endl;
	t.remove(40);
	t.to_tree().print();
	// 0
	// ├─ 37
	// │  ├─ 12
	// │  │  ├─ 3
	// │  │  └─ 12
	// │  └─ 37
	// │     ├─ 30
	// │     └─ 37
	// └─ 100
	//    ├─ 70
	//    │  ├─ 50
	//    │  ├─ 61
	//    │  └─ 70
	//    └─ 100
	//       ├─ 90
	//       └─ 100

	cout << "- 37" << endl;
	t.remove(37);
	t.to_tree().print();
	// 0
	// ├─ 30
	// │  ├─ 3
	// │  ├─ 12
	// │  └─ 30
	// ├─ 70
	// │  ├─ 50
	// │  ├─ 61
	// │  └─ 70
	// └─ 100
	//    ├─ 90
	//    └─ 100
}

static long _size = 0;
template <typename K>
void _size_visitor(const K & key, long value) {
	++ _size;
}

template <typename K, int NK>
long tree_size(BTree<K,NK> & t) {
	_size = 0;
	t.traverse(_size_visitor);
	return _size;
}

template <typename K, int NK>
void random_test(BTree<K,NK> & t, int inserts, int deletes) {
	static int _init = 0;
	if (_init==0) {
		srand((int)time(0));
		_init = 1;
	}
	for (int i = 0; i < inserts; ++ i) {
		int key = rand();
		t.put(key, key);
	}
	for (int i = 0; i < deletes; ++ i) {
		int key = rand();
		List<K> keys = t.keys_between(key, RAND_MAX);
		if (keys.size()==0) continue;
		key = keys.get(0);
		t.remove(key);
	}
}

void test338() {
	typedef int K;
	typedef BTree<K,338> T; // 修改每个结点键值对的个数，338个对应4088字节，内存对齐后刚好4098
	typedef typename T::BTNode N;
	// 下面两行选择存储方式，FileBTStorage可以保留上次运行的状态
	// FileBTStorage<N> storage("btree-338.bin"); // 想清空B树，可以认为删除这个文件
	MemoryBTStorage<N> storage;
	T t(storage);
	cout << "结点大小: " << sizeof(N) << endl;
	int size = 1000000; // 修改实验每次增删的键值对，用FileBTStorage时会慢100倍
	int n = 0;
	for (int m = 0; m < 10; ++ m) {
		random_test(t, size, n);
		n = tree_size(t);
		cout << "树中键值对数目: " << n << endl;
		cout << "存储结点数目: " << storage.num_nodes() << endl;
	}
}

int main() {
	// test2();
	// test3();
	// test4();
	test338();
}