
#include "lib/list.cpp"
#include "lib/tree.cpp"
#include "lib/dict.cpp"
#include "lib/set.cpp"

// 存储器接口
template <typename N>
class BTStorage
{
public:
	virtual int num_nodes() = 0;
	virtual void get(long node_id, N & node) = 0;
	virtual void set(long node_id, const N & node) = 0;

	void inspect() {
		int n = num_nodes();
		cout << "num_nodes: " << n << endl;
		N node;
		for (int i = 0; i < n; ++ i) {
			get(i, node);
			cout << node.info() << endl;
		}
	}
};

// B+树
template <typename K, int NUM_KEYS>
class BTree
{
public:

	// B+树结点
	struct BTNode {
		long node_id; // 结点自己的id，用于存储时使用
		long parent_id;
		long next_id; // 叶子结点存储下一叶子结点，根结点存储空白结点的链表
		int node_type = 0; // 1: 内部结点，0: 叶子结点，-1: 已回收的结点
		int num_keys;
		K keys[NUM_KEYS];
		long child_ids[NUM_KEYS];

		void init(long id) {
			node_id = id;
			node_type = 0;
			parent_id = -1; // root's parent_id is -1
			next_id = -1; // non-terminal's next_id == -1
			num_keys = 0;
		}

		BTNode() {
			init(-1);
		}

		string info() {
			BTNode & node = *this;
			stringstream ss;
			char nt = 'X';
			if (node.node_type==0) nt='L';
			if (node.node_type==1) nt='N';
			ss << "#" << node.node_id << " " << nt << "{";
			for (int i = 0; i < node.num_keys; ++ i)
				ss << (i==0? "" : ",") << node.keys[i] << ":" << node.child_ids[i];
			ss << "}";
			if (node.node_type==1)
				ss << " <=" << node.parent_id;
			if (node.node_type==0)
				ss << " <=" << node.parent_id << " ->" << node.next_id;
			if (node.node_type != 0 and node.node_type != 1 or node.node_id==0)
				ss << " ~~>" << node.next_id;
			return ss.str();
		}
	};

private:
	BTStorage<BTNode> & _storage;
	BTNode _root;
	Dict<long, BTNode *> _cache;
	Set<long> _updated;

	BTNode & _allocate_node() {
		if (_root.next_id != -1) {
			BTNode & node = _get(_root.next_id);
			_root.next_id = node.next_id;
			node.init(node.node_id);
			return node;
		}
		else {
			BTNode & node = *new BTNode();
			node.init(_storage.num_nodes());
			_storage.set(node.node_id, node);
			_cache.put(node.node_id, &node);
			return node;
		}
	}

	void _free_node(BTNode & node) {
		node.node_type = -1;
		node.next_id = _root.next_id;
		_root.next_id = node.node_id;
		_updated.add(node.node_id);
	}

	BTNode & _get(long node_id) {
		if (node_id == 0)
			return _root;
		if (! _cache.has(node_id)) {
			BTNode & node = *new BTNode();
			_storage.get(node_id, node);
			_cache.put(node_id, &node);
		}
		return *_cache.get(node_id);
	}

	void _save_cached() {
		List<long> keys = _cache.keys();
		for (int i = 0; i < keys.size(); ++ i) {
			long node_id = keys.get(i);
			BTNode & node = *_cache.get(node_id);
			if (_updated.has(node_id))
				_storage.set(node_id, node);
			delete &node;
		}
		_updated.clear();
		_cache.clear();
	}

	static int _find_index(const K & key, BTNode & node) {
		int begin = 0;
		int end = node.num_keys;
		while (begin < end) {
			int mid = (begin+end-1)/2;
			if (key == node.keys[mid]) {
				begin = mid;
				break;
			}
			else if (key < node.keys[mid])
				end = mid;
			else
				begin = mid + 1;
		}
		if (node.node_type==1 and begin==node.num_keys)
			-- begin; // 对于内部结点，遇到超过树中最大值的新键，添加入最后的孩子
		return begin;
	}

	// 找到key所在的叶子结点(赋给node)，返回key在叶子结点的位置
	BTNode & _find(const K & key, BTNode & node, int & index) {
		index = _find_index(key, node);
		if (node.node_type == 1) { // 内部结点
			BTNode & next = _get(node.child_ids[index]);
			return _find(key, next, index);
		}
		return node;
	}

public:
	BTree(BTStorage<BTNode> & storage) : _storage(storage) {
		if (_storage.num_nodes() == 0) {
			_root.node_type = 0;
			_root.node_id = 0;
			_storage.set(0, _root);
		}
		else
			_storage.get(0, _root);
	}

	~BTree() {
		_storage.set(0, _root);
	}

	void clear() {
		while (_root.num_keys > 0) {
			remove(_root.keys[_root.num_keys-1]);
			to_tree().print();
		}
		_save_cached();
	}

	long get(const K & key) {
		int index;
		BTNode & node = _find(key, _root, index);
		if (index >= node.num_keys)
			index = -1;
		else if (key != node.keys[index])
			index = -1;
		else
			index = node.child_ids[index];
		_save_cached();
		return index;
	}

	List<K> keys_between(const K & begin, const K & end, int max_size=1) {
		List<K> keys;
		int index;
		BTNode * node = &_find(begin, _root, index);
		while (index < node->num_keys) {
			K key = node->child_ids[index];
			if (key>end or keys.size()>=max_size) break;
			keys.push(key);
			++ index;
			if (index == node->num_keys and node->next_id != -1)
				node = &_get(node->next_id);
		}
		_save_cached();
		return keys;
	}

	bool put(const K & key, long value) {
		int index;
		bool added = false;
		BTNode & node = _find(key, _root, index);
		if (index<node.num_keys and key==node.keys[index]) {
			if (node.child_ids[index] != value) {
				// 修改 value
				node.child_ids[index] = value;
				_updated.add(node.node_id);
				added = true;
			}
		}
		else {
			// 插入 (key,value)
			_insert(node, index, key, value);
			added = true;
		}
		_save_cached();
		return added;
	}

	long remove(const K & key) {
		int index;
		BTNode & node = _find(key, _root, index);
		if (index>=node.num_keys or key!=node.keys[index]) {
			_save_cached();
			return -1;
		}
		_remove(node, index);
		long value = node.child_ids[index];
		_save_cached();
		return value;
	}

	// 调试使用：把BTNode变为tree.cpp/Node, 以供流输出
	Node<K> to_tree() {
		Node<K> root;
		root.data() = K();
		_to_tree(root, _root);
		_save_cached();
		return root;
	}

	// 调试使用：把tree.cpp/Node变为BTNode, 以供流输入
	void from_tree(Node<K> & root) {
		long prev_leaf = -1;
		clear();
		_from_tree(root, _root, prev_leaf);
		_save_cached();
	}

	typedef void (*_visitor)(const K & key, long value);

	void traverse(_visitor _visitor, BTNode * node=0) {
		if (node==0)
			node = &_root;
		if (node->node_type == 0)
			for (int i = 0; i < node->num_keys; ++ i)
				_visitor(node->keys[i], node->child_ids[i]);
		else
			for (int i = 0; i < node->num_keys; ++ i) {
				BTNode child;
				_storage.get(node->child_ids[i], child);
				traverse(_visitor, &child);
			}
	}

private:
	void _to_tree(Node<K> & node, BTNode & node2) {
		for (int i = 0; i < node2.num_keys; ++ i) {
			Node<K> & child = *new Node<K>();
			child.data() = node2.keys[i];
			node.push(&child);
			if (node2.node_type==1) {
				BTNode & child2 = _get(node2.child_ids[i]);
				_to_tree(child, child2);
			}
		}
		// node.data() = node2.keys[node2.num_keys-1];
	}

	void _from_tree(Node<K> & node, BTNode & node2, long & prev_leaf) {
		bool is_leaf = node.tree_depth() <= 2;
		for (int i = 0; i < node.size(); ++ i) {
			Node<K> & child = *node.get(i);
			_insert_key_value(node2, i, child.data(), -1);
		}
		if (is_leaf) {
			if (prev_leaf!=-1) {
				BTNode & prev = _get(prev_leaf);
				prev.next_id = node2.node_id;
				_updated.add(prev_leaf);
			}
			prev_leaf = node2.node_id;
		}
		else {
			for (int i = 0; i < node.size(); ++ i) {
				Node<K> & child = *node.get(i);
				BTNode & child2 = _allocate_node();
				node2.child_ids[i] = child2.node_id;
				child2.parent_id = node2.node_id;
				_from_tree(child, child2, prev_leaf);
			}
			node2.node_type = 1;
		}
		_updated.add(node2.node_id);
	}

	static void _insert_key_value(BTNode & node, int index, const K & key, long value) {
		for (int i = node.num_keys-1; i >= index; -- i) {
			node.keys[i+1] = node.keys[i];
			node.child_ids[i+1] = node.child_ids[i];
		}
		node.keys[index] = key;
		node.child_ids[index] = value;
		++ node.num_keys;	
	}

	void _insert(BTNode & node, int index, const K & key, long value) {
		if (node.num_keys < NUM_KEYS) {
			_insert_key_value(node, index, key, value);
			_updated.add(node.node_id);
			if (index==node.num_keys-1)
				_update_parent_max(node); // 更改了最大值
		}
		else { // 分裂结点
			BTNode & new_sibling = _allocate_node();
			new_sibling.parent_id = node.parent_id;
			if (&node != &_root) {
				new_sibling.next_id = node.next_id;
				node.next_id = new_sibling.node_id;
			}
			new_sibling.node_type = node.node_type;	
			node.num_keys = (NUM_KEYS+1)/2;
			new_sibling.num_keys = NUM_KEYS+1-(NUM_KEYS+1)/2;
			BTNode * to_insert = 0;
			if (index < node.num_keys)
				to_insert = &node;
			else {
				to_insert = &new_sibling;
				index -= node.num_keys;
			}
			-- to_insert->num_keys;
			for (int i = node.num_keys; i < NUM_KEYS; ++ i) {
				new_sibling.keys[i-node.num_keys] = node.keys[i];
				new_sibling.child_ids[i-node.num_keys] = node.child_ids[i];
				_update_child_parent_id(new_sibling, node.child_ids[i]);
			}
			_insert_key_value(*to_insert, index, key, value);
			_update_child_parent_id(*to_insert, value);
			_update_parent_insert(node.parent_id, node, new_sibling); // 更改了node的最大值, 插入了new_sibling
		}
	}

	void _update_parent_max(BTNode & node) {
		long parent_id = node.parent_id;
		if (parent_id==-1) return;
		K key = node.keys[node.num_keys-1];
		BTNode & parent = _get(parent_id);
		int index = _find_index(key, parent);
		if (parent.child_ids[index] != node.node_id) {
			// node可能从兄弟借了一个结点，使得key变化
			if (index>0 and parent.child_ids[index-1] == node.node_id)
				-- index;
			else if (index+1<parent.num_keys and parent.child_ids[index+1] == node.node_id)
				++ index;
		}
		if (parent.keys[index] != key) {
			parent.keys[index] = key;
			_updated.add(parent_id);
			if (index==parent.num_keys-1)
				_update_parent_max(parent);
		}
	}

	void _update_parent_insert(long parent_id, BTNode & node, BTNode & inserted_node) {
		if (parent_id == -1) { // 分裂根
			BTNode & node2 = _allocate_node();
			long node2_id = node2.node_id;
			node2 = _root;
			node2.node_id = node2_id;
			node2.parent_id = _root.node_id;
			if (node2.node_type == 0) {
				node2.next_id = inserted_node.node_id;
			}
			_update_children_parent_ids(node2);
			inserted_node.parent_id = _root.node_id;
			_root.num_keys = 0;
			_insert_key_value(_root, 0, node2.keys[node2.num_keys-1], node2.node_id);
			_insert_key_value(_root, 1, inserted_node.keys[inserted_node.num_keys-1], 
										inserted_node.node_id);
			_root.node_type = 1;
			_updated.add(node2.node_id);
			_updated.add(inserted_node.node_id);
			_updated.add(_root.node_id);
		}
		else {
			K key = inserted_node.keys[inserted_node.num_keys-1];
			BTNode & parent = _get(parent_id);
			int index = _find_index(key, parent);
			parent.keys[index] = node.keys[node.num_keys-1];
			_updated.add(parent.node_id);
			inserted_node.parent_id = parent.node_id;
			_updated.add(node.node_id);
			_updated.add(inserted_node.node_id);
			key = inserted_node.keys[inserted_node.num_keys-1];
			_insert(parent, index+1, key, inserted_node.node_id);
		}
	}

	void _remove_key_value(BTNode & node, int index) {
		for (int i = index; i < node.num_keys-1; ++ i) {
			node.keys[i] = node.keys[i+1];
			node.child_ids[i] = node.child_ids[i+1];
		}
		-- node.num_keys;		
	}

	void _update_child_parent_id(BTNode & node, long child_id) {
		if (node.node_type != 1) return;
		BTNode & child = _get(child_id);
		if (child.parent_id != node.node_id) {
			child.parent_id = node.node_id;
			_updated.add(child_id);
		}
	}

	void _update_children_parent_ids(BTNode & node) {
		for (int i = 0; i < node.num_keys; ++ i)
			_update_child_parent_id(node, node.child_ids[i]);
	}

	void _remove(BTNode & node, int index) {
		// 在叶子上删除 index 位置的 key value
		K max_key = node.keys[node.num_keys-1];
		_remove_key_value(node, index);
		// 如果孩子树 >= m/2, 结束
		if (node.num_keys >= NUM_KEYS/2) {
			_updated.add(node.node_id);
			if (max_key!=node.keys[node.num_keys-1])
				_update_parent_max(node); // 更改了最大值
			return;
		}
		// 如果是根
		if (node.parent_id==-1) {
			// 如果不是叶子且只有一个孩子，那么用孩子代替根
			if (node.node_type!=0 and node.num_keys<2) {
				BTNode & child = _get(node.child_ids[0]); // 读入孩子
				// 把孩子赋给根
				long root_next_id = _root.next_id; // 在赋值前，先把空结点链表保存起来
				_root = child;
				_root.next_id = root_next_id; // 恢复根的属性
				_root.parent_id = -1; // 恢复根的属性
				_root.node_id = 0; // 恢复根的属性
				_free_node(child); // 释放结点
				_update_children_parent_ids(_root);
				if (_root.num_keys == 0)
					_root.node_type = 0;
			}
			return;
		}
		// node需要重兄弟获取键或和兄弟合并
		BTNode & parent = _get(node.parent_id);
		index = _find_index(max_key, parent); // node在双亲中的位置
		if (parent.num_keys == 1) { // node没有兄弟
			_free_node(node);
			_remove(parent, 0);
		}
		else if (index==parent.num_keys-1) { // node没有右兄弟
			BTNode & left_sibling = _get(parent.child_ids[index-1]);
			if (left_sibling.num_keys > NUM_KEYS/2) { // 可以从左兄弟获取键
				K key = left_sibling.keys[left_sibling.num_keys-1];
				long value = left_sibling.child_ids[left_sibling.num_keys-1];
				_insert(node, 0, key, value);
				_update_child_parent_id(node, value);
				-- left_sibling.num_keys;
				parent.keys[index-1] = left_sibling.keys[left_sibling.num_keys-1];
				parent.keys[index] = node.keys[node.num_keys-1];
				if (index==parent.num_keys-1)
					_update_parent_max(parent);
				_updated.add(node.node_id);
				_updated.add(left_sibling.node_id);
				_updated.add(parent.node_id);
			}
			else
				_combine_siblings(parent, index-1, left_sibling, node);
		}
		else {
			BTNode & right_sibling = _get(parent.child_ids[index+1]);
			if (right_sibling.num_keys > NUM_KEYS/2) { // 可以从右兄弟获取键
				K key = right_sibling.keys[0];
				long value = right_sibling.child_ids[0];
				_remove_key_value(right_sibling, 0);
				_insert(node, node.num_keys, key, value);
				_update_child_parent_id(node, value);
				parent.keys[index] = node.keys[node.num_keys-1];
				parent.keys[index+1] = right_sibling.keys[right_sibling.num_keys-1];
				if (index+1==parent.num_keys-1)
					_update_parent_max(parent);
				_updated.add(node.node_id);
				_updated.add(right_sibling.node_id);
				_updated.add(parent.node_id);
			}
			else
				_combine_siblings(parent, index, node, right_sibling);
		}
	}

	void _combine_siblings(BTNode & parent, int left_index, BTNode & left, BTNode & right) {
		for (int i = 0; i < right.num_keys; ++ i) {
			left.keys[left.num_keys+i] = right.keys[i];
			left.child_ids[left.num_keys+i] = right.child_ids[i];
			_update_child_parent_id(left, right.child_ids[i]);
		}
		left.num_keys += right.num_keys;
		left.next_id = right.next_id;
		parent.keys[left_index] = left.keys[left.num_keys-1];
		_free_node(right);
		_updated.add(left.node_id);
		_remove(parent, left_index+1);
	}

};

// 存储器实现：存储在文件中
template <typename N>
class FileBTStorage : public BTStorage<N>
{
	fstream f;
public:
	FileBTStorage(const char path[]) {
		f.open(path, ios::app|ios::binary);
		f.close();
		f.open(path, ios::in|ios::out|ios::binary);
		if (! f)
			throw runtime_error("打不开文件");
	}
	~FileBTStorage() {
		f.close();
	}
	int num_nodes() {
		f.seekg(0, ios::end);
		int file_size = f.tellg();
		return file_size / sizeof(N);
	}
	void get(long node_id, N & node) {
		if (node_id >= num_nodes())
			throw runtime_error("不能读取记录");
		f.seekg(node_id * sizeof(N));
		f.read((char *)&node, sizeof(N));
	}
	void set(long node_id, const N & node) {
		if (node_id > num_nodes())
			throw runtime_error("不能写入记录");
		f.seekg(0, ios::end);
		f.seekg(node_id * sizeof(N));
		f.write((char *)&node, sizeof(N));
	}
};

// 内存实现：存储在内存中
template <typename N>
class MemoryBTStorage : public BTStorage<N>
{
	List<N> nodes;
public:
	int num_nodes() {
		return nodes.size();
	}
	void get(long node_id, N & node) {
		node = nodes.get(node_id);
	}
	void set(long node_id, const N & node) {
		if (node_id > nodes.size())
			throw runtime_error("不能写入记录");
		if (node_id == nodes.size())
			nodes.push(node);
		else
			nodes.get(node_id) = node;
	}
};
