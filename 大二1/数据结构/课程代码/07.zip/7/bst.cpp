
#ifndef __BST_CPP__
#define __BST_CPP__

#include "lib/tree.cpp"

class NotFoundException {};

template <typename E>
class BinarySearchTree
{
	Node<E> * _root;
	
	// 找到具有数据的结点，如果结点不存在则返回可插入结点的父亲。
	static Node<E> * _find_helper(Node<E> * node, const E & e) {
		if (node == 0) return 0;
		const E & ne = node->data();
		// cout << "---> " << ne << endl; // 查看搜索经过的结点
		if (ne == e) return node;
		if (e < ne) {
			if (node->size() == 0) return node;
			Node<E> * left_child = node->get(0);
			if (left_child == 0) return node;
			return _find_helper(left_child, e);
		}
		if (node->size() < 2) return node;
		Node<E> * right_child = node->get(1);
		if (right_child == 0) return node;
		return _find_helper(right_child, e);
	}

	Node<E> * _find(const E & e) {
		return _find_helper(_root, e);
	}

	static void _add_null(Node<E> * node) { // if left-child is greater, add a null left-child
		if (node->size() == 0) return;
		Node<E> * left_child = node->get(0);
		if (left_child->data() > node->data())
			node->insert(0, 0);
		I(i, node->size())
			if (node->get(i) != 0)
				_add_null(node->get(i));
	}

	static void _remove_null(Node<E> * node) { // if left-child is null, remove it
		if (node->size() == 0) return;
		if (node->get(0) == 0)
			node->remove(node->get(0));
		I(i, node->size())
			_remove_null(node->get(i));
	}

public:
	BinarySearchTree() : _root(0) {};

	~BinarySearchTree() {
		if (_root != 0)
			delete _root;
	};

	void clear() {
		if (_root != 0) {
			delete _root;
			_root = 0;
		}
	}

	void print(ostream & out=cout) const {
		if (_root==0) return;
		Node<E> copy(*_root);
		_remove_null(&copy);
		copy.print(out);
	}

	void read(istream & in=cin) {
		_root = new Node<E>();
		if (_root->read(in))
			_add_null(_root);
		else {
			clear();
		}
	}

	bool has(const E & e) {
		Node<E> * node = _find(e);
		return node!=0 && node->data()==e;
	}

	E & find(const E & e) {
		Node<E> * node = _find(e);
		if (node==0 || node->data()!=e)
			throw NotFoundException();
		return node->data();
	}

	void add(const E & e) {
		if (_root == 0) {
			_root = new Node<E>(e);
			return;
		}
		Node<E> * node = _find(e);
		if (node->data() == e) {
			node->data() = e;
			return;
		}
		if (e < node->data()) {
			Node<E> * left_child = new Node<E>(e);
			if (node->size() > 0)
				node->set(0, left_child);
			else
				node->push(left_child);
		}
		else {
			Node<E> * right_child = new Node<E>(e);
			if (node->size() == 0)
				node->push(0);
			if (node->size() >= 2)
				node->set(1, right_child);
			else
				node->push(right_child);
		}
	}

	bool remove(const E & e) {
		Node<E> * node = _remove(_root, e);
		if (node==0)
			return false; // 找不到
		delete node;
		return true;
	}

private:

	Node<E> * _replace(Node<E> * node1, Node<E> * node2) {
		Node<E> * parent = node1->parent();
		int index = parent==0 ? -1 : parent->index(node1);
		if (index==-1)
			_root = node2;
		else {
			parent->set(index, node2);
			if (index==1 && node2==0) {
				parent->remove(0);
				if (parent->get(0)==0)
					parent->remove(0);
			}
		}
		return node1;
	}

	Node<E> * _remove(Node<E> * tree, const E & e) {
		Node<E> * node = _find_helper(tree, e);
		if (node==0 || node->data()!=e) return 0; // 找不到
		Node<E> * left_child = node->size()>0 ? node->get(0) : 0;
		Node<E> * right_child = node->size()>1 ? node->get(1) : 0;
		if (left_child==0 && right_child==0) // 待删除的结点是叶子
			return _replace(node, 0);
		if (left_child==0 || right_child==0) // 待删除的结点仅有一个儿子
			return _replace(node, left_child!=0 ? left_child : right_child);
		Node<E> * replacing = _find_helper(left_child, node->data()); // 在左子树中找到替换结点
		_remove(left_child, replacing->data()); // 在左子树中删除替换结点
		swap(node->data(), replacing->data()); // 交换待删除结点和替换结点的数据
		return replacing;
	}

};

#endif
