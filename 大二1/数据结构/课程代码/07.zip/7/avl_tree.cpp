
#ifndef __AVL_CPP__
#define __AVL_CPP__

#include "lib/tree.cpp"

class NotFoundException {};

template <typename E>
class _D {
public:
	int depth;
	E data;
};

template <typename E>
class AVLTree
{
	Node<_D<E> > * _root;
	
	// 找到具有数据的结点，如果结点不存在则返回可插入结点的父亲。
	static Node<_D<E> > * _find_helper(Node<_D<E> > * node, const E & e) {
		if (node == 0) return 0;
		const _D<E> & d = node->data();
		// cout << "---> " << d.data << endl; // 查看搜索经过的结点
		if (d.data == e) return node;
		if (e < d.data) {
			if (node->size() == 0) return node;
			Node<_D<E> > * left_child = node->get(0);
			if (left_child == 0) return node;
			return _find_helper(left_child, e);
		}
		if (node->size() < 2) return node;
		Node<_D<E> > * right_child = node->get(1);
		if (right_child == 0) return node;
		return _find_helper(right_child, e);
	}

	Node<_D<E> > * _find(const E & e) {
		return _find_helper(_root, e);
	}

	static void _add_depth_n_null(Node<_D<E> > * node) { // if left-child is greater, add a null left-child
		if (node->size() == 0) {
			node->data().depth = 1;
			return;
		}
		Node<_D<E> > * left_child = node->get(0);
		if (left_child->data().data > node->data().data)
			node->insert(0, 0);
		int max_depth = 0;
		I(i, node->size())
			if (node->get(i) != 0) {
				_add_depth_n_null(node->get(i));
				int depth = node->get(i)->data().depth;
				if (max_depth < depth)
					max_depth = depth;
			}
		node->data().depth = max_depth+1;
	}

	static void _remove_null(Node<_D<E> > * node) { // if left-child is null, remove it
		if (node->size() == 0) return;
		if (node->get(0) == 0)
			node->remove(node->get(0));
		I(i, node->size())
			_remove_null(node->get(i));
	}

public:
	AVLTree() : _root(0) {};

	~AVLTree() {
		if (_root != 0)
			delete _root;
	};

	void clear() {
		if (_root != 0) {
			delete _root;
			_root = 0;
		}
	}

	void print(ostream & out=cout) const {
		if (_root==0) return;
		Node<_D<E> > copy(*_root);
		_remove_null(&copy);
		copy.print(out);
	}

	void read(istream & in=cin) {
		_root = new Node<_D<E> >();
		if (_root->read(in))
			_add_depth_n_null(_root);
		else {
			clear();
		}
	}

	bool has(const E & e) {
		Node<_D<E> > * node = _find(e);
		return node!=0 and node->data().data==e;
	}

	E & find(const E & e) {
		Node<E> * node = _find(e);
		if (node==0 or node->data().data!=e)
			throw NotFoundException();
		return node->data().data;
	}

	void add(const E & e) {
		if (_root == 0) {
			_D<E> d;
			d.depth = 1;
			d.data = e;
			_root = new Node<_D<E> >(d);
			return;
		}
		Node<_D<E> > * node = _find(e);
		if (node->data().data == e) {
			node->data().data = e;
			return;
		}
		_D<E> d;
		d.depth = 1;
		d.data = e;
		Node<_D<E> > * child = new Node<_D<E> >(d);
		if (e < node->data().data) {
			if (node->size() > 0)
				node->set(0, child);
			else
				node->push(child);
		}
		else {
			if (node->size() == 0)
				node->push(0);
			if (node->size() >= 2)
				node->set(1, child);
			else
				node->push(child);
		}
		_update_depth(node); // 平衡二叉树调整算法
	}

	bool remove(const E & e) {
		Node<_D<E> > * node = _remove(_root, e);
		if (node==0)
			return false; // 找不到
		delete node;
		return true;
	}

private:
	Node<_D<E> > * _remove(Node<_D<E> > * tree, const E & e) {
		Node<_D<E> > * node = _find_helper(tree, e);
		if (node==0 or node->data().data!=e) return 0; // 找不到
		Node<_D<E> > * left_child = _left_child(node);
		Node<_D<E> > * right_child = _right_child(node);
		if (left_child==0 and right_child==0) // 待删除的结点是叶子
			return _replace(node, 0);
		if (left_child==0 or right_child==0) // 待删除的结点仅有一个儿子
			return _replace(node, left_child!=0 ? left_child : right_child);
		// 在深度大的子树上删除结点
		Node<_D<E> > * child = (left_child->data().depth>right_child->data().depth? 
								left_child : right_child); 
		// 在左子树中找到替换结点
		Node<_D<E> > * replacing = _find_helper(child, node->data().data);
		_remove(child, replacing->data().data); // 在左子树中删除替换结点
		swap(node->data().data, replacing->data().data); // 交换待删除结点和替换结点的数据
		return replacing;
	}

	Node<_D<E> > * _replace(Node<_D<E> > * node1, Node<_D<E> > * node2) {
		Node<_D<E> > * parent = node1->parent();
		int index = parent==0 ? -1 : parent->index(node1);
		if (index==-1)
			_root = node2;
		else {
			parent->set(index, node2);
			if (index==1 and node2==0) {
				parent->remove(0);
				if (parent->get(0)==0)
					parent->remove(0);
			}
			_update_depth(parent);
		}
		return node1;
	}

	// 平衡二叉树调整算法
	static void _update_depth(Node<_D<E> > * node) {
		int left_depth = _depth(_left_child(node));
		int right_depth = _depth(_right_child(node));
		if (left_depth>right_depth+1) {
			_rotate_left(_left_child(node));
			_rotate_right(node);
			-- left_depth;
			++ right_depth;
		}
		else if (right_depth>left_depth+1) {
			_rotate_right(_right_child(node));
			_rotate_left(node);
			++ left_depth;
			-- right_depth;
		}
		int depth = 1 + (left_depth>right_depth ? left_depth : right_depth);
		if (node->data().depth != depth) {
			node->data().depth = depth;
			if (node->parent() != 0)
				_update_depth(node->parent());
		}
	}

	static Node<_D<E> > *  _left_child(Node<_D<E> > * node) {
		return node->size()>0 ? node->get(0) : 0;
	}
	static Node<_D<E> > *  _right_child(Node<_D<E> > * node) {
		return node->size()>1 ? node->get(1) : 0;
	}
	static int _depth(Node<_D<E> > * node) {
		return node==0 ? 0 : node->data().depth;
	}

	// clean tailing null child and update depth
	static void _update_node(Node<_D<E> > * node) {
		if (node->size()==2 and node->get(1)==0)
			node->remove(0);
		if (node->size()==1 and node->get(0)==0)
			node->remove(0);
		int ld = _depth(_left_child(node));
		int rd = _depth(_right_child(node));
		node->data().depth = 1 + (ld>rd ? ld : rd);
	}

	static void _set_child(Node<_D<E> > * node, int index, Node<_D<E> > * child) {
		if (child!=0 and child->parent()!=0) {
			Node<_D<E> > * parent = child->parent();
			int ci = parent->index(child);
			parent->set(ci, 0);
			_update_node(parent);
		}
		while (node->size() < 2)
			node->push(0);
		node->set(index, child);
		_update_node(node);
	}

	static void _rotate_left(Node<_D<E> > * node) {
		int left_depth = _depth(_left_child(node));
		int right_depth = _depth(_right_child(node));
		if (left_depth >= right_depth) return;
		Node<_D<E> > * left = _left_child(node);
		Node<_D<E> > * right = _right_child(node);
		Node<_D<E> > * rl = _left_child(right);
		Node<_D<E> > * rr = _right_child(right);
		_set_child(right, 0, left);
		_set_child(right, 1, rl);
		_set_child(node, 0, right);
		_set_child(node, 1, rr);
		swap(node->data().data, right->data().data);
	}
	static void _rotate_right(Node<_D<E> > * node) {
		int left_depth = _depth(_left_child(node));
		int right_depth = _depth(_right_child(node));
		if (left_depth <= right_depth) return;
		Node<_D<E> > * left = _left_child(node);
		Node<_D<E> > * right = _right_child(node);
		Node<_D<E> > * ll = _left_child(left);
		Node<_D<E> > * lr = _right_child(left);
		_set_child(left, 0, lr);
		_set_child(left, 1, right);
		_set_child(node, 0, ll);
		_set_child(node, 1, left);
		swap(node->data().data, left->data().data);
	}

};

template <typename E>
ostream & operator << (ostream & out, const _D<E> & d) {
	out << d.data << ":" << d.depth;
	return out;
}

template <typename E>
istream & operator >> (istream & in, _D<E> & d) {
	in >> d.data;
	return in;
}

#endif
