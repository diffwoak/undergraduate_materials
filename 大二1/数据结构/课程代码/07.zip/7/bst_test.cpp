
#include "bst.cpp"

// 测试: g++ -g -fno-omit-frame-pointer -fsanitize=address -fPIE -std=c++11 bst_test.cpp
//		ASAN_OPTIONS=detect_leaks=1 ./a.out

#include <fstream>
using namespace std;

void load(BinarySearchTree<int> & bst, const char file[]) {
	cout << file << endl;
	ifstream f(file);
	bst.read(f);
	f.close();
	bst.print();
}

int main() {
	BinarySearchTree<int> bst;
	load(bst, "bst_test/7_7.txt");
	// 45
	// ├─ 12
	// │  ├─ 3
	// │  └─ 37
	// │     └─ 24
	// └─ 53
	//    └─ 100
	//       └─ 61
	//          └─ 90
	//             └─ 78
	cout << bst.has(37) << endl; // 1
	cout << bst.has(65) << endl; // 0

	bst.add(55);
	bst.print();
	// 45
	// ├─ 12
	// │  ├─ 3
	// │  └─ 37
	// │     └─ 24
	// └─ 53
	//    └─ 100
	//       └─ 61
	//          ├─ 55
	//          └─ 90
	//             └─ 78

	bst.clear();
	int data[] = {45,24,53,45,12,24,90};
	I(i,7) {
		bst.add(data[i]);
	}
	bst.print();
	// 45
	// ├─ 24
	// │  └─ 12
	// └─ 53
	//    └─ 90

	load(bst, "bst_test/7_10_a.txt");
	bst.remove(45);
	bst.print();
	// 53
	// ├─ 17
	// │  ├─ 9
	// │  └─ 45
	// │     └─ 23
	// └─ 78
	//    ├─ 65
	//    └─ 87
	// 53
	// ├─ 17
	// │  ├─ 9
	// │  └─ 23
	// └─ 78
	//    ├─ 65
	//    └─ 87

	load(bst, "bst_test/7_10_b.txt");
	bst.remove(78);
	bst.print();
	// 53
	// ├─ 17
	// │  ├─ 9
	// │  └─ 23
	// └─ 78
	//    └─ 94
	//       └─ 88
	// 53
	// ├─ 17
	// │  ├─ 9
	// │  └─ 23
	// └─ 94
	//    └─ 88

	load(bst, "bst_test/7_10_c.txt");
	bst.remove(78);
	bst.print();
	// 53
	// ├─ 17
	// │  ├─ 9
	// │  └─ 45
	// │     └─ 23
	// └─ 78
	//    ├─ 70
	//    │  ├─ 60
	//    │  └─ 75
	//    └─ 94
	//       └─ 88
	// 53
	// ├─ 17
	// │  ├─ 9
	// │  └─ 45
	// │     └─ 23
	// └─ 75
	//    ├─ 70
	//    │  └─ 60
	//    └─ 94
	//       └─ 88

}