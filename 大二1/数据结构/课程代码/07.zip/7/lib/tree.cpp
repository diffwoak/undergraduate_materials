
// 该库参考了 Python 的 anytree.Node

#ifndef __TREE_CPP__
#define __TREE_CPP__

#include "list.cpp"

template <typename E>
class Node {
	E _data;
	List<Node *> _children;
	Node * _parent;

	void _copy(const Node & src) {
		_data = src._data;
		I(i, src._children.size()) {
			Node * src_child = src._children.get(i);
			Node * child = 0;
			if (src_child != 0) {
				child = new Node();
				child->_copy(*src_child);
			}
			push(child);
		}
	}

	void _swap(Node && src) {
		swap(_data, src._data);
		swap(_children, src._children);
	}

public:
	Node() : _parent(0) {}

	Node(const E & data) : _parent(0), _data(data) {}

	Node(const Node & src) : _parent(0) {
		_copy(src);
	}

	Node(Node && src) : _parent(0) {
		_swap(move(src));
	}

	Node & operator = (const Node & src) {
		clear();
		_copy(src);
		return *this;
	}

	Node & operator = (Node && src) {
		clear();
		_swap(move(src));
		return *this;
	}

	void clear() {
		while (_children.size() > 0) {
			Node * child = _children.top(); // 孩子的指针
			if (child != 0)
				delete child;
			_children.pop();
		}
	}

	~Node() {
		clear();
	}

	E & data() {
		return _data;
	}

	Node * parent() {
		return _parent;
	}

	int size() const {
		return _children.size();
	}

	Node * get(int index) {
		return _children.get(index);
	}

	int index(const Node * node) const {
		I(i, _children.size())
			if (_children.get(i) == node)
				return i;
		return -1;
	}

	int remove(Node * node) {
		int idx = index(node);
		if (idx == -1)
			return -1;
		_children.remove(idx);
		if (node != 0)
			node->_parent = 0;
		return idx;
	}

	void insert(int index, Node * node) {
		if (node != 0) {
			if (node->_parent != 0)
				node->_parent->remove(node);
			node->_parent = this;
		}
		_children.insert(index, node);
	}

	void push(Node * node) {
		insert(_children.size(), node);
	}

	Node * set(int index, Node * node) {
		if (node != 0)
			if (node->_parent != 0)
				node->_parent->remove(node);
		Node * replaced = _children.get(index);
		if (replaced != 0)
			replaced->_parent = 0;
		_children.get(index) = node;
		if (node != 0)
			node->_parent = this;
		return replaced;
	}

	int tree_depth() const {
		int max_depth = 0;
		I(i, _children.size()) {
			const Node * child = _children.get(i);
			if (child == 0) continue;
			int depth = child->tree_depth();
			if (max_depth < depth)
				max_depth = depth;
		}
		return max_depth + 1;
	}

	int tree_size() const {
		int size = 1;
		I(i, _children.size()) {
			const Node * child = _children.get(i);
			if (child != 0)
				size += child->tree_size();
		}
		return size;
	}

	void print(ostream & out=cout) const {
		_print_helper1(out, "", 0);
	}

	bool read(istream & in=cin) {
		clear();
		List<Node<E> *> stack;
		List<int> indent;
		string line;
		bool not_null = false;
		while (true) {
			getline(in, line);
			if (! in) break;
			int prefix_size = _trim(line);
			if (line.size() == 0) continue;
			stringstream ss(line);
			E data;
			ss >> data;
			if (prefix_size==0) {
				*this = Node<E>(data);
				stack.push(this);
				indent.push(prefix_size);
				not_null = true;
			}
			else {
				Node<E> * node = new Node<E>(data);
				while (indent.top() >= prefix_size) {
					stack.pop();
					indent.pop();
				}
				stack.top()->push(node);
				stack.push(node);
				indent.push(prefix_size);
			}
		}
		return not_null;
	}

private:

	static void _print_helper2(ostream & out, const Node * node, string prefix, int parent_type) {
		if (parent_type == 1)
			prefix += "├─ ";
		if (parent_type == 2)
			prefix += "└─ ";
		if (node == 0)
			out << prefix << "NULL" << endl;
		else
			out << prefix << node->_data << endl;
	}

	void _print_helper1(ostream & out, string prefix, int parent_type) const {
		_print_helper2(out, this, prefix, parent_type);
		if (parent_type == 1)
			prefix += "│  ";
		if (parent_type == 2)
			prefix += "   ";
		int n = _children.size();
		I(i, n) {
			const Node * child = _children.get(i);
			int node_type = i < n-1 ? 1 : 2;
			if (child == 0)
				_print_helper2(out, child, prefix, node_type);
			else
				child->_print_helper1(out, prefix, node_type);
		}
	}

	static int _trim(string & line) {
		while (line.size()>0) {
			char c = line[line.size()-1];
			if (c=='\n' || c=='\r' || c=='\t' || c==' ')
				line = line.substr(0, line.size()-1);
			else
				break;
		}
		int prefix_size = 0;
		while (line.size()>0) {
			char c = line[0];
			if (c=='\n' || c=='\r' || c=='\t' || c==' ') {
				line = line.substr(1, line.size());
				++ prefix_size;
				continue;
			}
			if (line.find("├")==0) {
				int size = string("├").size();
				prefix_size += size;
				line = line.substr(size, line.size());
				continue;
			}		
			if (line.find("─")==0) {
				int size = string("─").size();
				prefix_size += size;
				line = line.substr(size, line.size());
				continue;
			}		
			if (line.find("└")==0) {
				int size = string("└").size();
				prefix_size += size;
				line = line.substr(size, line.size());
				continue;
			}		
			if (line.find("│")==0) {
				int size = string("│").size();
				prefix_size += size;
				line = line.substr(size, line.size());
				continue;
			}
			break;
		}
		return prefix_size;
	}

};

#endif
