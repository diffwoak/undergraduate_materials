
/*
测试: g++ -g -fno-omit-frame-pointer -fsanitize=address -fPIE -std=c++11 dict_test.cpp
		ASAN_OPTIONS=detect_leaks=1 ./a.out
*/

#include<time.h>
#include<stdlib.h>
#include "list.cpp"
#include "dict.cpp"

template <typename K, typename V>
void random_test(Dict<K,V> & t, int inserts, int deletes) {
	static int _init = 0;
	if (_init==0) {
		srand((int)time(0));
		_init = 1;
	}
	for (int i = 0; i < inserts; ++ i) {
		int key = rand();
		t.put(key, V());
	}
	List<K> keys = t.keys();
	int n = keys.size();
	for (int i = 0; i < deletes; ++ i) {
		int idx = rand() % n;
		K key = keys.get(idx);
		if (t.has(key))
			t.remove(key);
	}
}

int main() {
	Dict<int,long> t;
	int size = 1000000;
	int n = 0;
	for (int m = 0; m < 10; ++ m) {
		random_test(t, size, n);
		n = t.size();
		cout << "树中键值对数目: " << n << endl;
	}

}
