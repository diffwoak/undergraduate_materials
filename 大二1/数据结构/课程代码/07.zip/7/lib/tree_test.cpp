
/*
// 测试: g++ -g -fno-omit-frame-pointer -fsanitize=address -fPIE -std=c++11 lib/tree_test.cpp
		ASAN_OPTIONS=detect_leaks=1 ./a.out < lib/tree_test.txt

它位于哪个省份？
IP
├─ NP
│  └─ 它
├─ VP
│  ├─ 位于
│  └─ NP
│     ├─ DP
│     │  ├─ 哪
│     │  └─ CLP
│     │     └─ 个
│     └─ NP
│        └─ 省份
└─ ？
*/

#include "tree.cpp"

int main() {
	Node<string> root;
	root.read();
	root.print();
}
