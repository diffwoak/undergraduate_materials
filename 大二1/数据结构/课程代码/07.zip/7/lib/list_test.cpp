
#include "list.cpp"
#include <iostream>
using namespace std;

// 测试: g++ -g -fno-omit-frame-pointer -fsanitize=address -fPIE -std=c++11 lib/list_test.cpp
//		ASAN_OPTIONS=detect_leaks=1 ./a.out

int main() {
	List<double> list;

	// test list
	cout << "\nLIST\n";
	for (int i = 0; i < 10; ++ i) {
		double v = 100 + i;
		list.insert(list.size(), v);
	}
	for (int i = 0; i < 5; ++ i) {
		double v = 1000 + i;
		list.insert(2, v);
	}
	for (int i = 0; i < 3; ++ i) {
		list.remove(3);
	}
	cout << list << endl;
	double v = 103;
	cout << "Found "<< v <<" at: "<< list.find(v) <<"\n";

	// test stack
	cout << "\nSTACK\n";
	list.clear();
	for (int i = 0; i < 7; ++ i) {
		double v = 10 + i;
		list.push(v);
	}
	cout << list << endl;
	cout << "Top: " << list.top() <<"\n";
	for (int i = 0; i < 2; ++ i) {
		list.pop();
	}
	cout << list << endl;
	cout << "Top: " << list.top() <<"\n";
	for (int i = 0; i < 3; ++ i) {
		double v = 100 + i;
		list.push(v);
	}
	cout << list << endl;
	cout << "Top: "<< list.top() <<"\n";
	while (list.size() > 0) {
		list.pop();
	}
	cout << list << endl;

	// test queue
	cout << "\nQUEUE\n";
	for (int i = 0; i < 7; ++ i) {
		double v = 10 + i;
		list.enqueue(v);
	}
	cout << list << endl;
	cout << "Head: "<< list.head() <<"\n";
	for (int i = 0; i < 2; ++ i) {
		list.dequeue();
	}
	cout << list << endl;
	cout << "Head: "<< list.head() <<"\n";
	for (int i = 0; i < 3; ++ i) {
		double v = 100 + i;
		list.enqueue(v);
	}
	cout << list << endl;
	cout << "Head: "<< list.head() <<"\n";
	while (list.size() > 0) {
		list.dequeue();
	}
	cout << list << endl;
}