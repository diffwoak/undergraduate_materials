pmatrix.c ——并行矩阵乘法
	—main 主函数
	—matrix_multiple 并行矩阵乘法函数


编译运行
gcc -g -Wall -fopenmp -o opm opmatrix.c
./opm 4
