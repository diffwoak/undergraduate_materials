### 数据集名称

GroceryStore 

### 数据集描述

This data set contains transaction records of a grocery store in a month. Each line is a transaction, where the purchased items line in {}, separated by “,” (the space is replaced by “/”).

### 数据集信息

| Transactions | items |
| ------------ | ----- |
| 9,835        | 169   |

### 数据集规模

可用CPU跑
