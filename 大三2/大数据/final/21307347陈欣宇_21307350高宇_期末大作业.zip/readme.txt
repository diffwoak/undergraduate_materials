代码文件说明：
compress_v3.py	最终的apriori算法代码
utils.py		函数工具
draw_time.py	耗时过程可视化绘制

函数说明详见代码