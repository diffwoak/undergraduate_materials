### 数据集名称

wiki-Vote [https://snap.stanford.edu/data/wiki-Vote.html]

### 数据集描述

Wikipedia who-votes-on-whom network

### 数据集信息

| Nodes | Edges   | Type     |
| ----- | ------- | -------- |
| 7,115 | 103,689 | Directed |

### 数据集规模

可用CPU跑
