<script>
import ProductList from '@/components/ProductList.vue'; // 根据实际路径导入组件
import ProductForm from '@/components/ProductForm.vue';  // 路径根据实际情况调整
export default {
  components: {
    ProductList,
    ProductForm,
  },
};

</script>

<template>
  <div class="about">
    <ProductList />
    <ProductForm />
<!--    <h1>This is an about page</h1>-->
  </div>
</template>

<style>
@media (min-width: 1024px) {
  .about {
    min-height: 100vh;
    display: flex;
    align-items: center;
  }
}
</style>
