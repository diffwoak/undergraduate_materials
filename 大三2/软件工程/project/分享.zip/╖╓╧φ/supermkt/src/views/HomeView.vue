<script setup>

</script>


<template>
  <el-card  class="pic" style="display: flex; width: 100%; justify-content: center">
    <img :src="imgUrl" alt="图片" width="580" height="580">
  </el-card>
</template>
  
  <script>
  import img from '../pic/超市管理系统欢迎界面.jpg'
  
  export default {
    data() {
      return {
        imgUrl: img
      }
    }
  }
  </script>

<style>
.pic {
  position: relative;
  //width: 10%; /* 调整为适合你的尺寸，这里使用相对于父容器的百分比 */
  //min-width: 300px; /* 设置最大宽度，确保框不会过大 */
  //margin: 0 auto; /* 居中显示框 */
  //padding: 20px;
  background-color: rgba(255, 255, 255, 0.3);
  border-radius: 10px;
}

</style>

