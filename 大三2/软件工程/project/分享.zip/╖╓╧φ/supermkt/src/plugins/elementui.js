import {
    ElButton,
    ElInput,
} from "element-plus"

export default (app) => {
    app.use(ElButton);
    app.use(ElInput);
}