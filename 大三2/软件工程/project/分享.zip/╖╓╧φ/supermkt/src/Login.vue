<!--<script setup>-->

<!--</script>-->

<template>
  <div class="login-page">
    <div class="login-form">
      <h2><el-text class="mx-1" size="large" ></el-text></h2>

      <!-- 输入表单 -->
      <el-form @submit.prevent="handleLogin" method="post">
        <el-label for="username">用户名(用户名为a):</el-label>
        <input type="text" id="username" v-model="username" required><br/>

        <el-label for="password">密码(密码为1):</el-label>
        <input type="password" id="password" v-model="password" required><br/>

        <el-button color="#626aef" :dark="isDark" type="primary" @click="handleLogin" >登录</el-button>
      </el-form>

      <!-- 错误提示信息 -->
      <p v-if="errorMessage !== ''" style="color: red;">{{ errorMessage }}</p>
    </div>
  </div>
</template>

<script>
// const router = useRouter();
// import router from "@/router";
export default {
  data() {
    return {
      username: '', // 存储用户名
      password: '', // 存储密码
      errorMessage: '', // 存储错误消息
      isLoggedIn: false
    }
  },
  setup(){
    // const router = useRouter();
    // router.push({
    //   path: "/Products"
    // });
  },

  methods: {
    handleLogin() {
      // const router = useRouter();
      if (this.username === 'a' && this.password === '1') {
        // 验证成功后进行相应操作（如路由导航到主页）
        this.isLoggedIn = true
        this.$router.push({name:'home'});
        // router.push({ name: 'home' });
        // this.router.push({path: "/"});

        // router.push({path: "/Products"});
        console.log('Login successful!');

        // 清空输入字段
        //this.clearInputs();
      } else {
        // 验证失败时显示错误消息
        this.errorMessage = "用户名或密码不正确";
      }
    },

    clearInputs() {
      this.username = '';
      this.password = '';
      this.errorMessage = '';
    }
  }
}
</script>

<style scoped>
/* CSS样式 */
/*
.login-page {
  width: 300px;

  margin: auto;
  padding: 20px;
  border: 1px solid #ccc;
  background-color: #f9f9f9;
}
*/
body {
  margin: 0;
  padding: 0;
}

.login-age {
  display: flex;
  justify-content: center;
  align-items: center;
  //margin-left: 250px;
  height: 100vh;
  width: 100vh;
}



.login-page {
  background-image: url(' /src/pic/R.jpeg'); /* 替换为你的背景图片路径 */
  background-size: cover; /* 保持背景图片的宽高比并覆盖整个容器 */
  background-position: center; /* 居中显示背景图片 */
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  height: 100vh; /* 设置容器的高度为视口的高度 */
  width: 100vw;

}
.login-form {
  position: relative;
  width: 600px; /* 调整为适合你的尺寸 */
  padding: 200px; /* 调整为适合你的尺寸 */
}
.login-form {
  position: relative;
  width: 10%; /* 调整为适合你的尺寸，这里使用相对于父容器的百分比 */
  min-width: 300px; /* 设置最大宽度，确保框不会过大 */
  margin: 0 auto; /* 居中显示框 */
  padding: 20px;
  background-color: rgba(255, 255, 255, 0.3);
  border-radius: 10px;
}


h2 {
  text-align: center;
}

label {
  display: block;
  font-weight: bold;
}

input[type=text], input[type=password] {
  width: 100%;
  padding: 5px;
  box-sizing: border-box;
}

button {
  width: 100%;
  padding: 8px;
  cursor: pointer;
}

.text {
  font-size: 14px;
}

.item {
  margin-bottom: 18px;
}
</style>

