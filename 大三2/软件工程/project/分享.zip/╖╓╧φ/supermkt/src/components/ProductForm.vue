<!-- ProductForm.vue -->
<template>
  <div>
    <h1>Add Product</h1>
    <form @submit.prevent="submitForm">
      <label for="productName">Product Name:</label>
      <input type="text" v-model="productName" required>

      <label for="productPrice">Product Price:</label>
      <input type="number" v-model="productPrice" required>

      <button type="submit">Add Product</button>
    </form>
  </div>
</template>

<script>
import axios from 'axios';

export default {
  data() {
    return {
      productName: '',
      productPrice: 0,
    };
  },
  // 请确保在组件中引入axios库
  // import axios from 'axios';

// 在 submitForm 方法中发送 POST 请求
  methods: {
    submitForm() {
      // 构建要发送的数据对象
      const postData = {
        name: this.productName,
        price: this.productPrice,
      };

      // 发送 POST 请求
      axios.post('http://127.0.0.1:8000/your_app_name/api/product-info/add', postData)
          .then(response => {
            // 处理请求成功的情况，可以根据需要更新页面或执行其他操作
            console.log('Product added successfully:', response.data);

            // 提交成功后可以清空表单或显示成功信息
            this.productName = '';
            this.productPrice = 0;
          })
          .catch(error => {
            // 处理请求失败的情况，可以根据需要显示错误信息或执行其他操作
            console.error('Error adding product:', error);
          });
    },
  },

};
</script>

<style>
/* 样式可以根据需要进行调整 */
form {
  max-width: 300px;
  margin: auto;
}
</style>