#include <iostream>
#include "rtweekend.h"
#include "hittable_list.h"
#include "sphere.h"
#include "camera.h"
#include "material.h"
#include "bvh.h"
#include "omp.h"
#include "image_texture.h"
#include "model.h"
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"
using namespace std;


hittable_list earth() {
    int nx, ny, nn;
    unsigned char* texture_data = stbi_load("earth.jpg", &nx, &ny, &nn, 0);

    auto earth_surface =
        make_shared<lambertian>(make_shared<image_texture>(texture_data, nx, ny));
    auto globe = make_shared<sphere>(vec3(0, 0, 0), 2, earth_surface);

    return hittable_list(globe);
}
hittable_list random_scene() {
    hittable_list world;

    auto checker = make_shared<checker_texture>(
        make_shared<constant_texture>(vec3(0.2, 0.3, 0.1)),
        make_shared<constant_texture>(vec3(0.9, 0.9, 0.9))
    );

    world.add(make_shared<sphere>(vec3(0, -1000, 0), 1000, make_shared<lambertian>(checker)));
     auto light = make_shared<diffuse_light>(make_shared<constant_texture>(vec3(5, 5, 5)));
    int i = 1;
    for (int a = -10; a < 10; a++) {
        for (int b = -10; b < 10; b++) {
            auto choose_mat = random_double();
            vec3 center(a + 0.9 * random_double(), 0.2, b + 0.9 * random_double());
            if ((center - vec3(4, .2, 0)).length() > 0.9) {
                if (choose_mat < 0.8) {
                    // diffuse
                    auto albedo = vec3::random() * vec3::random();
                    world.add(make_shared<sphere>(
                        center, 0.2,
                        make_shared<lambertian>(make_shared<constant_texture>(albedo))));
                }
                else if (choose_mat < 0.95) {
                    // metal
                    auto albedo = vec3::random(.5, 1);
                    auto fuzz = random_double(0, .5);
                    world.add(
                    //    make_shared<sphere>(center, 0.2, make_shared<metal>(albedo, fuzz))
                        make_shared<sphere>(center, 0.2, light)
                    );
                }
                else {
                    // glass
                    world.add(make_shared<sphere>(center, 0.2, make_shared<dielectric>(1.5)));
                }
            }
        }
    }

    world.add(make_shared<sphere>(vec3(0, 1, 0), 1.0, make_shared<dielectric>(1.5)));
    world.add(make_shared<sphere>(
        vec3(-4, 1, 0), 1.0, make_shared<lambertian>(make_shared<constant_texture>(vec3(0.4, 0.2, 0.1)))));
    world.add(make_shared<sphere>(
        vec3(4, 1, 0), 1.0, make_shared<metal>(vec3(0.7, 0.6, 0.5), 0.0)));

    //return world;
    return static_cast<hittable_list>(make_shared<bvh_node>(world, 0, 1));
}
hittable_list cornell_box() {
    hittable_list objects;

    auto red = make_shared<lambertian>(make_shared<constant_texture>(vec3(0.65, 0.05, 0.05)));
    auto white = make_shared<lambertian>(make_shared<constant_texture>(vec3(0.73, 0.73, 0.73)));
    auto green = make_shared<lambertian>(make_shared<constant_texture>(vec3(0.12, 0.45, 0.15)));
    auto light = make_shared<diffuse_light>(make_shared<constant_texture>(vec3(5, 5, 5)));
    auto light_re = make_shared<diffuse_light>(make_shared<constant_texture>(vec3(1, 1, 1)));

    vertex _v1(-5.0, 0.0, -5.0), _v2(5.0, 0.0, -5.0), _v3(5.0, 0.0, 21.0), _v4(-5.0, 0.0, 21.0),
        _v5(-5.0, 5.0, -5.0), _v6(5.0, 5.0, -5.0), _v7(5.0, 5.0, 21.0),_v8(-5.0, 5.0, 21.0);
    vertex l1(-3.0, 5.0-0.001, -3.0), l2(3.0, 5.0-0.001, -3.0), l3(3.0, 5.0-0.001, 2.0), l4(-3.0, 5.0-0.001, 2.0);

    objects.add(make_shared<triangle>(_v1, _v2, _v3, white));
    objects.add(make_shared<triangle>(_v4, _v1, _v3, white));
    objects.add(make_shared<triangle>(_v1, _v2, _v5, white));
    objects.add(make_shared<triangle>(_v5, _v6, _v2, white));
    objects.add(make_shared<triangle>(_v5, _v6, _v7, white));
    objects.add(make_shared<triangle>(_v5, _v7, _v8, white));
    objects.add(make_shared<triangle>(_v1, _v5, _v4, green));
    objects.add(make_shared<triangle>(_v4, _v5, _v8, green));
    objects.add(make_shared<triangle>(_v2, _v3, _v6, red));
    objects.add(make_shared<triangle>(_v6, _v7, _v3, red));
    objects.add(make_shared<triangle>(l1, l2, l3, light));
    objects.add(make_shared<triangle>(l4, l1, l3, light));
    objects.add(make_shared<triangle>(_v3, _v4, _v7, white));
    objects.add(make_shared<triangle>(_v4, _v7, _v8, white));
    //return objects;
    return static_cast<hittable_list>(make_shared<bvh_node>(objects, 0, 1));
}
hittable_list model_tree() {
    hittable_list objects;
    auto air = make_shared<diffuse_light>(make_shared<image_texture>("obj/n1.jpg"));
    objects.add(make_shared<sphere>(vec3(0, -20, 0), 160, air));//球形天空
    auto light = make_shared<dielectric>(6);// make_shared<diffuse_light>(make_shared<constant_texture>(vec3(1, 1, 1)));
    objects.add(make_shared<sphere>(vec3(0, -600, 0), 600, light));
   
    model(
        "obj/tree/Lowpoly_tree_sample.obj",
        std::unordered_map<std::string, std::shared_ptr<material>>{
            {"default", make_shared<lambertian>(vec3(0.5, 0.5, 0.5))},
            { "Bark", make_shared<lambertian>(vec3(0.207595, 0.138513, 0.055181)) },
            { "Tree", make_shared<lambertian>(vec3(0.256861, 0.440506, 0.110769)) },
    },
        glm::rotate(
            glm::translate(
                glm::scale(glm::dmat4(1.0), glm::dvec3(0.8f, 0.8f, 0.8f)),//缩放
                glm::dvec3(0.0f, 0.0f, 0.0f)),//平移
            glm::radians(double(0.0)), glm::dvec3(0.0f, 1.0f, 0.0f)))//旋转
        .add_to_scene(objects);
    for (int a = -4; a < 4; a++) {
        for (int b = -4; b < 4; b++) {
            auto choose_mat = random_double();
            vec3 center(a*8 + random_double(), 20 * random_double() -10, b*8 + random_double());
            if ((center - vec3(0, 0, 0)).length() > 10 && center.y()> 0) {
                if (choose_mat < 0.3) {
                    auto albedo = vec3::random(.4, .8);
                    auto fuzz = random_double(0, .5);
                    //auto albedo = vec3::random() * vec3::random();
                    objects.add(make_shared<sphere>(
                        center, 1,
                        make_shared<metal>(albedo, fuzz)));
                }
                else if (choose_mat < 0.8) {
                    auto albedo = vec3::random(.3, 0.8);
                    auto light = make_shared<diffuse_light>(make_shared<constant_texture>(albedo));
                    objects.add(
                        make_shared<sphere>(center, 1, light)
                    );
                }
                else {
                    objects.add(make_shared<sphere>(center, 1.5, make_shared<dielectric>(1.5)));
                }
            }
        }
    }
    return static_cast<hittable_list>(make_shared<bvh_node>(objects, 0, 1));
}
hittable_list model_scene() {
    hittable_list world;
    auto checker = make_shared<checker_texture>(
        make_shared<constant_texture>(vec3(0.2, 0.3, 0.1)),
        make_shared<constant_texture>(vec3(0.9, 0.9, 0.9))
        );
    world.add(make_shared<sphere>(vec3(0, -1000, 0), 1000, make_shared<lambertian>(checker)));
    /*
     auto deco1 = make_shared<lambertian>(make_shared<image_texture>("obj/NYscene/textures/deco1.png"));
    auto deco2 = make_shared<lambertian>(make_shared<image_texture>("obj/NYscene/textures/deco2.png"));
    auto deco3 = make_shared<lambertian>(make_shared<image_texture>("obj/NYscene/textures/deco3.png"));
    model("obj/NYscene/NYscene.obj",
        std::unordered_map<std::string, std::shared_ptr<material>>{{"default", make_shared<lambertian>(vec3(1, 1, 1))}, 
        { "deco1",  deco1 }, { "deco2",  deco1 }, { "deco_3",  deco3 }, 
        {"Flame",make_shared<diffuse_light>(make_shared<constant_texture>(vec3(0.8,0.8,0.8)))},
        {"pine1",make_shared<lambertian>(vec3(0.8,0.8,0.8))}, 
        {"pine2",make_shared<lambertian>(vec3(0.8,0.8,0.8)) }, 
        { "Metal",make_shared<metal>(vec3(0.451228, 0.191162, 0.017452), 0.907253) },
        {"lenta",make_shared<diffuse_light>(make_shared<constant_texture>(vec3(0.800000,0.002733,0.000000))) },
        {"candle",make_shared<diffuse_light>(make_shared<constant_texture>(vec3(0.800000,0.561790,0.225507))) },
        {"black",make_shared<diffuse_light>(make_shared<constant_texture>(vec3(0,0,0)))},
        {"candle.003",make_shared<diffuse_light>(make_shared<constant_texture>(vec3(0.800000,0.663598,0.340189))) },
        {"candle.002",make_shared<diffuse_light>(make_shared<constant_texture>(vec3(0.800000,0.663598,0.340189))) },
        {"Материал.004",make_shared<diffuse_light>(make_shared<constant_texture>(vec3(0.004350,0.005500,0.014670))) }
    },
        glm::rotate(
            glm::translate(
                glm::scale(glm::dmat4(1.0), glm::dvec3(1.0f, 1.0f, 1.0f)),//缩放
                glm::dvec3(0.0f, 1.0f, 0.0f)),//平移
            glm::radians(double(90.0)), glm::dvec3(0.0f, 1.0f, 0.0f))//旋转
    ).add_to_scene(world);
    */
   
    /*雪人
    model(
        "obj/snowman.obj",
        std::unordered_map<std::string, std::shared_ptr<material>>{
            {"default", make_shared<lambertian>(vec3(1, 1, 1))},
            { "aiStandardSurface11SG", make_shared<lambertian>(vec3(133, 0, 0) / 255) },	 //帽子
            { "aiStandardSurface18SG", make_shared<lambertian>(vec3(203, 62, 0) / 255) }, //尖鼻子
            { "aiStandardSurface15SG", make_shared<lambertian>(vec3(145, 0, 0) / 255) },	 //围巾
            { "aiStandardSurface17SG", make_shared<lambertian>(vec3(0, 0, 0) / 255) },	 //眼睛
            { "aiStandardSurface16SG", make_shared<lambertian>(vec3(24, 0, 0) / 255) },	 //纽扣
            { "aiStandardSurface19SG", make_shared<lambertian>(vec3(85, 38, 18) / 255) }	 //手
    },
            glm::rotate(
                glm::translate(
                    glm::scale(glm::dmat4(1.0),glm::dvec3(0.5f, 0.5f, 0.5f)),//缩放
                    glm::dvec3(0.0f, 0.0f, 0.0f)),//平移
                glm::radians(double(180.0)), glm::dvec3(0.0f, 1.0f, 0.0f)))//旋转
        .add_to_scene(world);*/

    /* 剑
    auto sting = make_shared<lambertian>(make_shared<image_texture>("obj/Textures/Sting_Base_Color.png"));
    model("obj/Sting-Sword-lowpoly.obj",
        std::unordered_map<std::string, std::shared_ptr<material>>{{"default", make_shared<lambertian>(vec3(1, 1, 1))},{ "Sting",  sting },},
            glm::rotate(
                glm::translate(
                    glm::scale(glm::dmat4(1.0),glm::dvec3(0.17f, 0.17f, 0.17f)),//缩放
                    glm::dvec3(0.0f, 1.0f, 0.0f)),//平移
                glm::radians(double(90.0)), glm::dvec3(0.0f, 1.0f, 0.0f)))//旋转
        .add_to_scene(world);*/
    /*房子
    model(
                "obj/old_house.obj",
                std::unordered_map<std::string, std::shared_ptr<material>>{
                    {"default", make_shared<lambertian>(vec3(0.5, 0.5, 0.5))},
                    { "Standard_1", make_shared<lambertian>(make_shared<image_texture>("obj/Textures/house_body.jpg")) },
                    { "Standard_2", make_shared<lambertian>(make_shared<image_texture>("obj/Textures/plants2.jpg")) },
                    { "Standard_3", make_shared<lambertian>(make_shared<image_texture>("obj/Textures/plants1.jpg")) },
            },
               glm::scale(glm::dmat4(1.0), glm::dvec3(0.01, 0.01, 0.01)))
                .add_to_scene(world);*/
    model(
        "obj/tree/Lowpoly_tree_sample.obj",
        std::unordered_map<std::string, std::shared_ptr<material>>{
            {"default", make_shared<lambertian>(vec3(1, 1, 1))},
            { "Bark", make_shared<lambertian>(vec3(0.207595, 0.138513, 0.055181)) },
            { "Tree", make_shared<lambertian>(vec3(0.256861, 0.440506, 0.110769)) },     
    },
        glm::rotate(
            glm::translate(
                glm::scale(glm::dmat4(1.0), glm::dvec3(0.1f, 0.1f, 0.1f)),//缩放
                glm::dvec3(0.0f, 0.0f, 0.0f)),//平移
            glm::radians(double(0.0)), glm::dvec3(0.0f, 1.0f, 0.0f)))//旋转
        .add_to_scene(world);
  

    //auto test_tex = make_shared<lambertian>(make_shared<image_texture>("obj/room/TEXTURES/Floor/Wood051_2K_Color.jpg"));
    //vertex v1 = vertex(1, 0, 0, vec3(0, 0, 1), 1, 1), v2 = vertex(-1, 0, 0, vec3(0, 0, 1), 0, 1),v3 = vertex(1, 1, 0, vec3(0, 0, 1), 1, 0), v4 = vertex(-1, 1, 0, vec3(0, 0, 1), 0, 0);
    //use vec3 lookfrom(0,0.5,3);vec3 lookat(0,0.5,0);
    //world.add(make_shared<triangle>(v1, v2, v3, test_tex));world.add(make_shared<triangle>(v4, v2, v3, test_tex));

    return static_cast<hittable_list>(make_shared<bvh_node>(world, 0, 1));
}

vec3 ray_color(const ray& r, const hittable& world, int depth) {
    hit_record rec;
    // If we've exceeded the ray bounce limit, no more light is gathered.
    if (depth <= 0)
        return vec3(0.05, 0.05, 0.05);

    if (world.hit(r, 0.001, infinity, rec)) {
        ray scattered;
        vec3 attenuation;
        vec3 emitted = rec.mat_ptr->emitted(rec.u, rec.v, rec.p);
        if (rec.mat_ptr->scatter(r, rec, attenuation, scattered))
            return attenuation * ray_color(scattered, world, depth - 1);
        return emitted;
    }
    //return vec3(0.4, 0.4, 0.4);   //background: black
    vec3 unit_direction = unit_vector(r.direction());
    auto t = 0.5 * (unit_direction.y() + 1.0);
    return (1.0 - t) * vec3(1.0, 1.0, 1.0) + t * vec3(0.5, 0.7, 1.0);
}

int main() {
    const int image_width = 1024;
    const int image_height = 512;
    const int samples_per_pixel = 300;
    const int max_depth = 20;

    ofstream ofs;
    ofs.open("image.ppm");
    vec3* data = new vec3[image_height * image_width];

    //auto world = random_scene();
    //auto world = earth();
    //auto world = cornell_box();
    auto world = model_tree();
    //auto world = model_scene();
    //经典视角
    //vec3 lookfrom(13, 2,5);vec3 lookat(0, 0, 0);
    //盒子视角
    //vec3 lookfrom(0, 2.5, 20);vec3 lookat(0, 2.5, 0);
    // 模型视角
    // vec3 lookfrom(7,2.5,8);vec3 lookat(0,0.5,0);
    //贴图视角
    //vec3 lookfrom(0,0.5,3);vec3 lookat(0,0.5,0);
    //树视角
    vec3 lookfrom(80, 20, 80); vec3 lookat(0, 5, 0);

    vec3 vup(0, 1, 0);
    auto dist_to_focus = 10.0;
    auto aperture = 0;
    const auto aspect_ratio = double(image_width) / image_height;

    camera cam(lookfrom, lookat, vup, 20, aspect_ratio, aperture, dist_to_focus, 0.0, 1.1);

    ofs << "P3\n" << image_width << ' ' << image_height << "\n255\n";

    omp_set_num_threads(8);
    #pragma omp parallel for schedule(dynamic)
    for (int j = image_height - 1; j >= 0; --j) {
        printf("Thread %d is computing height %d\n", omp_get_thread_num(), j);
        for (int i = 0; i < image_width; ++i) {
            vec3 color(0, 0, 0);
            for (int s = 0; s < samples_per_pixel; ++s) {
                auto u = (i + random_double()) / image_width;
                auto v = (j + random_double()) / image_height;
                ray r = cam.get_ray(u, v);
                color += ray_color(r, world, max_depth);
            }
            data[j * image_width + i] = color;
        }
    }

    for (int j = image_height - 1; j >= 0; --j) {
        std::cerr << "\rwrite line :  " << j << ' ' << std::flush;
        for (int i = 0; i < image_width; ++i) {
            data[j * image_width + i].write_color(ofs, samples_per_pixel);
        }
    }
    delete[] data;
    std::cerr << "\nDone.\n";
}