//sphere.h
#ifndef TRIANGLE_H
#define TRIANGLE_H

#include "hittable.h"
#include "vec3.h"
#include"ray.h"

class vertex : public vec3
{
public:
    vertex(){}
    //vertex(double e0, double e1, double e2) : vec3(e0, e1, e2){}
    vertex(double e0, double e1, double e2,vec3 nor=vec3(0,0,0), double _u = 0, double _v = 0) : vec3(e0, e1, e2), normal(nor), u(_u), v(_v) {}
public:
    vec3 normal = vec3(0,0,0);
    double u = 0;
    double v = 0;
};
class triangle : public hittable {
public:
    triangle() {}
    triangle(vertex _v1, vertex _v2, vertex _v3, shared_ptr<material> m) : v1(_v1), v2(_v2), v3(_v3), mat_ptr(m) 
    {
        tri_normal = (v1.normal + v2.normal + v3.normal) / 3;
        e1 = v2 - v1;
        e2 = v3 - v1;
    };

    virtual bool hit(const ray& r, double tmin, double tmax, hit_record& rec) const;
    virtual bool bounding_box(double t0, double t1, aabb& output_box) const;

public:
    vertex v1; vertex v2; vertex v3;
    vec3 tri_normal;
    vec3 e1, e2;
    shared_ptr<material> mat_ptr;
};


bool triangle::hit(const ray& r, double t_min, double t_max, hit_record& rec) const{
    //法向量随便设一边就行，对于漫反射两边都可以，镜面反射和折射可能有点问题
    //以及 对于物体本身的颜色如何设置（漫反射），和光照模型不太一样，给定顶点法向量
    vec3 T = r.origin() - v1;
    vec3 M = cross(r.direction(), e2);
    auto det = dot(M,e1);
    if (fabs(det) < 1e-5)
        return false;
    vec3 K = cross(T, e1);
    auto invDet = 1.0 / det;
    double t = dot(K, e2) * invDet;
    if (t >= t_max || t <= t_min)
        return false;
    auto u = dot(M, T) * invDet;
    auto v = dot(r.direction(), K) * invDet;
    if (v < 0 || u + v > 1 || u < 0)
        return false;
    rec.t = t;
    rec.p = r.at(rec.t);
    rec.mat_ptr = mat_ptr;
    double w = 1 - u - v;
    rec.u = w * v1.u + u * v2.u + v * v3.u;
    rec.v = w * v1.v + u * v2.v + v * v3.v;
    vec3 nor = w * v1.normal + u * v2.normal + v * v3.normal;
    if (nor.length_squared() == 0) {
        nor = -cross(e1, e2);
    }
    rec.set_face_normal(r, nor);// 插值
    return true;
}

bool triangle::bounding_box(double t0, double t1, aabb& output_box) const {
    double x, y, z;
    x = (v1.x() <= v2.x() && v1.x() <= v3.x()) ? v1.x() : (v2.x() <= v3.x() ? v2.x() : v3.x());
    y = (v1.y() <= v2.y() && v1.y() <= v3.y()) ? v1.y() : (v2.y() <= v3.y() ? v2.y() : v3.y());
    z = (v1.z() <= v2.z() && v1.z() <= v3.z()) ? v1.z() : (v2.z() <= v3.z() ? v2.z() : v3.z());
    vec3 bottom(x - 0.0001, y - 0.0001, z - 0.0001);
    x = (v1.x() >= v2.x() && v1.x() >= v3.x()) ? v1.x() : (v2.x() >= v3.x() ? v2.x() : v3.x());
    y = (v1.y() >= v2.y() && v1.y() >= v3.y()) ? v1.y() : (v2.y() >= v3.y() ? v2.y() : v3.y());
    z = (v1.z() >= v2.z() && v1.z() >= v3.z()) ? v1.z() : (v2.z() >= v3.z() ? v2.z() : v3.z());
    vec3 top(x + 0.0001, y + 0.0001, z + 0.0001);

    output_box = aabb(bottom, top);
    return true;
}

#endif