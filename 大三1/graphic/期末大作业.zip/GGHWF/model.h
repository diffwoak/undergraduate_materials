#pragma once

#ifndef MODEL_H
#define MODEL_H
#include <assimp/Importer.hpp>
#include <assimp/scene.h>
#include <assimp/postprocess.h> 
#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <string>
#include <memory>
#include <unordered_map>
#include "material.h"
#include "hittable_list.h"
#include "texture.h"

vec3 transformer(double x, double y, double z, glm::dmat4x4 transform) {
    glm::vec4 o(x, y, z, 1);
    glm::vec4 r = transform * o;
    return vec3(r.x / r.w, r.y / r.w, r.z / r.w);
}


class model : public hittable_list
{
public:
    explicit model(const char* path);
    model(const char* path, glm::dmat4x4 t);
    model(const char* path, std::shared_ptr<material> mat);
    model(const char* path, std::shared_ptr<material> mat, glm::dmat4x4 t);
    model(const char* path,std::unordered_map<std::string, std::shared_ptr<material>> mats,glm::dmat4x4 t);
    void add_to_scene(hittable_list& scene) const;

private:
    std::unordered_map<std::string, std::shared_ptr<material>> mats;
    glm::dmat4x4 transform;

    void load_model(std::string path);
    void process_node(aiNode* node, const aiScene* scene);
    hittable_list process_mesh(aiMesh* mesh, const aiScene* scene);
};

model::model(const char* path)
    : model(path, glm::dmat4x4(1.0)){}

model::model(const char* path, glm::dmat4x4 t)
    : model(path, { {"default", make_shared<lambertian>(vec3(0.5, 0.5, 0.5))} }, t){}

model::model(const char* path, shared_ptr<material> mat)
    : model(path, mat, glm::dmat4x4(1.0)){}

model::model(const char* path, shared_ptr<material> mat, glm::dmat4x4 t)
    : model(path, { {"default", mat} }, t){}

model::model(const char* path, std::unordered_map<std::string, shared_ptr<material>> _mats, glm::dmat4x4 t)
{
    mats = _mats;
    transform = t;
    load_model(path);
}

void model::load_model(std::string path)
{
    Assimp::Importer importer;
    const aiScene* scene = importer.ReadFile(path, aiProcess_Triangulate | aiProcess_FixInfacingNormals | aiProcess_GenSmoothNormals);
    if (!scene || scene->mFlags & AI_SCENE_FLAGS_INCOMPLETE || !scene->mRootNode)
    {
        std::cout << "ERROR::ASSIMP::" << importer.GetErrorString() << std::endl;
        return;
    }
    process_node(scene->mRootNode, scene);
}

void model::process_node(aiNode* node, const aiScene* scene)
{
    for (unsigned int i = 0; i < node->mNumMeshes; i++)
    {
        aiMesh* mesh = scene->mMeshes[node->mMeshes[i]];
        add(make_shared<::hittable_list>(process_mesh(mesh, scene)));
    }
    for (unsigned int i = 0; i < node->mNumChildren; i++)
    {
        process_node(node->mChildren[i], scene);
    }
}

hittable_list model::process_mesh(aiMesh* ai_mesh, const aiScene* scene)
{
    vector<vertex> vertices;
    hittable_list result;
    assert(ai_mesh->mNumVertices > 2);
    for (unsigned int i = 0; i < ai_mesh->mNumVertices; i++)
    {
        vertex v;
        vec3 pos = transformer(ai_mesh->mVertices[i].x, ai_mesh->mVertices[i].y, ai_mesh->mVertices[i].z, transform);
        v[0] = pos.x();
        v[1] = pos.y();
        v[2] = pos.z();
        pair<double, double> texcoord = make_pair(0.0, 0.0);
        if (ai_mesh->mTextureCoords[0] != nullptr) //是否贴图
        {
            v.u = ai_mesh->mTextureCoords[0][i].x;
            v.v = ai_mesh->mTextureCoords[0][i].y;
        }
        // 漫反射材料贴图，导入的法向量不是很必要，可以根据三角形默认求整个面的法向量
        v.normal = -vec3(ai_mesh->mNormals[i].x,ai_mesh->mNormals[i].y,ai_mesh->mNormals[i].z);
        // v.normal = transformer(ai_mesh->mNormals[i].x,ai_mesh->mNormals[i].y,ai_mesh->mNormals[i].z,transform);
        vertices.push_back(v);
    }

    for (unsigned int i = 0; i < ai_mesh->mNumFaces; i++)
    {
        aiFace face = ai_mesh->mFaces[i];
        //assert(face.mNumIndices == 3);
        if (face.mNumIndices != 3) { printf("face-mNumIndices:%d\n\n", face.mNumIndices); continue; }
        auto mat = mats["default"];
        if (scene->HasMaterials() && scene->mMaterials[ai_mesh->mMaterialIndex] != nullptr)
        {
            auto name = scene->mMaterials[ai_mesh->mMaterialIndex]->GetName();
            if (mats.count(name.C_Str()) > 0)
            {
                mat = mats[name.C_Str()];
            }
        }
        const auto& v0 = vertices[face.mIndices[0]];
        const auto& v1 = vertices[face.mIndices[1]];
        const auto& v2 = vertices[face.mIndices[2]];
        result.add(make_shared<triangle>(v0, v1, v2, mat));
    }
    return result;
}

void model::add_to_scene(hittable_list& scene) const
{
    for (const auto& object : objects)
    {
        scene.add(object);
    }
}
#endif
