import sqlite3
from xmlrpc.server import SimpleXMLRPCServer
#import base64
from config import data_info

def init_cache_table():
    cursor.execute('DROP TABLE IF EXISTS CACHES;')
    connection.commit()
    cursor.execute(
        'CREATE TABLE CACHES (user_id integer,path integer,cache_hash text);'
    )
def init_server_table():
    cursor.execute('DROP TABLE IF EXISTS SERVERS;')
    connection.commit()
    cursor.execute(
        'CREATE TABLE SERVERS (server_id integer,address text);'
    )
def init_file_table():
    cursor.execute('DROP TABLE IF EXISTS FILES;')
    connection.commit()
    cursor.execute('CREATE TABLE FILES (server_id integer,path integer,name text,is_backup integer,file_hash text,lastmodified integer);')


def init_db():
    init_cache_table()
    init_server_table()
    init_file_table()
    connection.commit()

def get_next_server():                      # 轮流取下一个address
    global server_counter
    addresses = get_server_addresses()
    server_num = len(addresses)
    server_counter = (server_counter + 1) % server_num
    return addresses[server_counter]
def insert_server(server_id, address):      # 插入server
    try:
        cursor.execute('INSERT INTO SERVERS (server_id, address) VALUES (?, ?);', (server_id, address))
        connection.commit()
        return True
    except sqlite3.Error:
        return False
def insert_files(file_list):                # 批量插入file
    try:
        cursor.executemany('''INSERT INTO FILES (server_id, path, name, is_backup, file_hash, lastmodified) 
                              VALUES (?, ?, ?, ?, ?, ?)''', file_list)
        connection.commit()
        return True
    except sqlite3.Error:
        return False
def insert_cache(user_id,rel_path,hash):    # 插入cache
    try:
        cursor.execute('INSERT INTO CACHES (user_id, path, cache_hash) VALUES (?, ?, ?);', (user_id,rel_path,hash))
        connection.commit()
        return True
    except sqlite3.Error:
        return False
def delete_server(server_id):               # 删除server及有关file
    cursor.execute('DELETE FROM SERVERS WHERE server_id = ?;', (server_id, ))
    cursor.execute('DELETE FROM FILES WHERE server_id = ?;', (server_id, ))
    connection.commit()
def delete_file(rel_path):                  # 删除file及有关备份file
    try:
        cursor.execute('DELETE FROM FILES WHERE path = ?;', (rel_path,))
        connection.commit()
        return True
    except sqlite3.Error:
        return False
def remove_one_file(rel_path):              # 删除原file
    try:
        cursor.execute('DELETE FROM FILES WHERE path = ? and is_backup = 0;', (rel_path,))
        connection.commit()
        return True
    except sqlite3.Error:
        return False
def delete_backup_file(server_id,rel_path): # 删除备份file
    try:
        cursor.execute('DELETE FROM FILES WHERE server_id = ? and path = ?;', (server_id,rel_path))
        connection.commit()
        return True
    except sqlite3.Error:
        return False
def delete_cache(user_id,rel_path):         # 删除cache
    try:
        cursor.execute('DELETE FROM CACHES WHERE user_id = ? and path = ?;', (user_id,rel_path,))
        connection.commit()
        return True
    except sqlite3.Error:
        return False
def get_server_addresses():                 # 查找所有server的url
    try:
        cursor.execute('SELECT address FROM SERVERS;')
        results = cursor.fetchall()
        return [address for (address, ) in results]
    except sqlite3.Error:
        return []
def get_file_servers(rel_path):             # 查找file原文件所在server的url
    try:
        cursor.execute('''SELECT address FROM FILES JOIN SERVERS USING (server_id) 
                            WHERE is_backup = 0 AND path = ?''',(rel_path,))
        results = cursor.fetchall()
        if results:return results[0]
        else: return []
    except sqlite3.Error:
        return []
def get_file_backup_servers(rel_path):      # 查找file备份所在server的url
    try:
        cursor.execute('''SELECT address FROM FILES JOIN SERVERS USING (server_id) 
                            WHERE is_backup = 1 AND path = ?''',(rel_path,))
        results = cursor.fetchall()
        return [address for (address, ) in results]
    except sqlite3.Error:
        return []
def get_file_backup_name(rel_path):         # 查找file备份的name
    try:
        cursor.execute('''SELECT name FROM FILES
                            WHERE is_backup = 1 AND path = ?''',(rel_path,))
        result = cursor.fetchall()
        if result:return result[0]
        else: return []
    except sqlite3.Error:
        return []
def get_file_infos(rel_path_list):          # 查找file列表对应的name、lastmodified列表
    try:
        results = []
        for rel_path in rel_path_list:
            cursor.execute('''SELECT name, lastmodified FROM FILES 
                                WHERE is_backup = 0 AND path LIKE ?;''', (rel_path+ '%',))
            results += cursor.fetchall()
        return results
    except sqlite3.Error:
        return []
def get_file_hash(rel_path):                # 查找file原文件的hash
    try:
        cursor.execute('''SELECT file_hash FROM FILES
                            WHERE path = ? and is_backup = 0;''', (rel_path,))
        results = cursor.fetchall()
        if results:return results[0]
        else: return []
    except sqlite3.Error:
        return []
def get_cache_hash(user_id,rel_path):       # 查找cache的hash
    try:
        cursor.execute('''SELECT cache_hash FROM CACHES
                            WHERE user_id = ? and path = ?;''', (user_id,rel_path,))
        results = cursor.fetchall()
        if results:return results[0]
        else: return []
    except sqlite3.Error:
        return []

def aquire_shared(rel_path):
    global shared_lock,exclusive_lock
    if rel_path not in exclusive_lock:
        shared_lock.append(rel_path)
        return True
def release_shared(rel_path):
    global shared_lock
    shared_lock.remove(rel_path)
def aquire_exclusive(rel_path):
    global shared_lock,exclusive_lock
    if rel_path not in shared_lock:
        if rel_path not in exclusive_lock:
            exclusive_lock.append(rel_path)
        return True
def release_exclusive(rel_path):
    global exclusive_lock
    exclusive_lock.remove(rel_path)


if __name__ == '__main__':
    server_counter = 0
    connection = sqlite3.connect('info.db')
    cursor = connection.cursor()
    init_db() #创建SERVERS/FILES/CACHES表
    shared_lock = []
    exclusive_lock = []
    with SimpleXMLRPCServer(data_info, allow_none=True) as server:
        server.register_function(insert_server)
        server.register_function(insert_files)
        server.register_function(delete_server)
        server.register_function(get_server_addresses)
        server.register_function(get_next_server)
        server.register_function(get_file_servers)
        server.register_function(get_file_backup_servers)
        server.register_function(get_file_backup_name)
        server.register_function(delete_file)
        server.register_function(get_file_infos)
        server.register_function(get_file_hash)
        server.register_function(get_cache_hash)
        server.register_function(delete_backup_file)
        server.register_function(remove_one_file)
        server.register_function(insert_cache)
        server.register_function(delete_cache)

        server.register_function(aquire_shared)
        server.register_function(release_shared)
        server.register_function(aquire_exclusive)
        server.register_function(release_exclusive)

        try:
            server.serve_forever()
        except KeyboardInterrupt:
            connection.close()
