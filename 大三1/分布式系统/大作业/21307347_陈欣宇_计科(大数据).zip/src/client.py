from xmlrpc.client import ServerProxy, Binary
import base64
import bcrypt
from pathlib import Path
import shutil
from config import data_url
import argparse
import datetime
import os
import msvcrt
from cryptography.fernet import Fernet
from cryptography.hazmat.backends import default_backend
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC

def list_file(rel_dir):
    addresses = proxy.get_server_addresses()
    dir_paths = set()
    file_paths = set()
    print('=' * 75)
    print('{0:35s} {1:7s} {2}'.format('File Name', 'Type', 'Last Update'))
    print('-' * 75)
    for address in addresses:
        with ServerProxy(address, allow_none=True) as server_pxy:
            for is_dir, file_rel_path in server_pxy.get_files(rel_dir):#不返回备份文件路径
                if is_dir: dir_paths.add(file_rel_path)
                else: file_paths.add(file_rel_path)
    for dir_path in dir_paths:
        print('{0:35s} DIR'.format(Path(dir_path).name + '/'))
    for file_name, mod in proxy.get_file_infos(list(file_paths)):
        print('{0:35s} {1:7s} {2}'.format(file_name, Path(file_name).suffix[1:].upper(),datetime.datetime.fromtimestamp(mod)))
    print('=' * 75)
def make_dir(rel_dir):
    addresses = proxy.get_server_addresses()
    for address in addresses:
        with ServerProxy(address, allow_none=True) as server_pxy:
            path_exists,path_valid,_ = server_pxy.path_check(rel_dir)
            if path_valid and path_exists:
                print("Dir already existing !\n")
                return False
    address = proxy.get_next_server()
    with ServerProxy(address, allow_none=True) as server_pxy:
        return server_pxy.make_dir(rel_dir)
def del_file(rel_path):
    address = proxy.get_file_servers(rel_path)
    if address:
        with ServerProxy(address[0], allow_none=True) as server_pxy:
            if not server_pxy.del_file(rel_path):
                return False
            proxy.delete_cache(args.user_id,rel_path)
    else: 
        print('File not exists')
        return False
    return True
def del_dir(rel_dir):
    addresses = proxy.get_server_addresses()
    for address in addresses:
        with ServerProxy(address, allow_none=True) as server_pxy:
            dir_files = server_pxy.get_files(rel_dir)
            if dir_files:# 目录不为空
                print("Dir Not Empty")
                return False
            server_pxy.del_dir(rel_dir)
    return True
def change_dir(rel_dir):
    addresses = proxy.get_server_addresses()
    for address in addresses:
        with ServerProxy(address, allow_none=True) as server_pxy:
            path_exists,path_valid,new_rel_dir = server_pxy.path_check(rel_dir)
        if path_valid and path_exists:
            return True, new_rel_dir
    print("Dir Path not valid or exists\n")
    return False,''
def read_file(rel_path,use_cache = True):
    file_hash = proxy.get_file_hash(rel_path)
    if not file_hash:
        print('File not existing.')
        return False,''
    if use_cache:
        cache_hash = proxy.get_cache_hash(args.user_id,rel_path)
        if cache_hash:
            if file_hash[0] == cache_hash[0]:
                path = cache_dir / str(Path(rel_path).name)
                with open(path,'r') as file:
                    content = file.read()
                    print('Read file in cache:')
                    print(content)
                return True,''
            proxy.delete_cache(args.user_id,rel_path)
    address = proxy.get_file_servers(rel_path)
    if not lock(rel_path):return False, 'lock'
    with ServerProxy(address[0], allow_none=True) as server_pxy:
        path = server_pxy.read_path(rel_path,file_hash[0])
        if path == '': 
            unlock(rel_path)
            return False,''
        with open(path,'r') as file:
            content = file.read()
            print('Read file:')
            print(content)
        cache_path = cache_dir / str(Path(path).name)
        shutil.copy2(path, cache_path)
        cache_hash = server_pxy.hash_file(str(cache_path))
    proxy.insert_cache(args.user_id,rel_path,cache_hash)
    unlock(rel_path)
    return True,path
def write_file(rel_path):
    done, path = read_file(rel_path,False)
    if path == 'lock': return False
    cache_path = cache_dir / str(Path(rel_path).name)
    if done:
        if not lock(rel_path,False): return False
        with open(path,'w') as file:
            print('Enter the content:')
            content = input()
            file.write(content)
        shutil.copy2(path, cache_path)
        address = proxy.get_file_servers(rel_path)[0]
        with ServerProxy(address, allow_none=True) as server_pxy:
            server_pxy.update_file(rel_path)
            server_pxy.update_backup(rel_path)
            cache_hash = server_pxy.hash_file(str(cache_path))
        proxy.delete_cache(args.user_id,rel_path)
        proxy.insert_cache(args.user_id,rel_path,cache_hash)
        unlock(rel_path,False)
        return True
    reply = input('Create new one? Enter Y for yes: ')
    reply = reply.upper()
    if reply == 'Y': # 写新文件不需要锁
        print('Enter the content:')
        content = input()
        address = proxy.get_next_server()
        with ServerProxy(address, allow_none=True) as server_pxy:
            path = server_pxy.write_new_file(content,rel_path)
            server_pxy.update_file(rel_path)    # 数据库初始化文件
            server_pxy.update_backup(rel_path)  # 更新备份
            shutil.copy2(path, cache_path)      # 缓存
            cache_hash = server_pxy.hash_file(str(cache_path))
        proxy.insert_cache(args.user_id,rel_path,cache_hash)
        return True
    return False
def lock(rel_path,shared = True):
    if shared:
        if proxy.aquire_shared(rel_path):
            return True
    else:
        if proxy.aquire_exclusive(rel_path):
            return True
    print('Lock conflict: The file is currently locked by another user.')
    return False
def unlock(rel_path,shared = True):
    if shared:
        proxy.release_shared(rel_path)
    else:
        proxy.release_exclusive(rel_path)
    return True

def main():
    global cd
    print('--<help> for commands')
    while True:
        print('Current directory:', str(args.user_id)+os.sep +cd)
        command = str(input('$ ')).split(' ')
        if command[0] == 'help':
            print('- list')
            print('- makedir <dir>')
            print('- deletedir <dir>')
            print('- delete <file>')
            print('- changedir <dir-path>')
            print('- write <file>')
            print('- read  <file>')
            print('- exit')
        elif command[0] == 'list':
            list_file(cd)
        elif command[0] == 'makedir' and len(command) == 2:     # 创建目录
            rel_dir = str(Path(cd) / command[1].strip())
            if make_dir(rel_dir): print('Successfully created "{}".'.format(rel_dir))
        elif command[0] == 'deletedir' and len(command) == 2:   # 删除目录
            rel_dir = str(Path(cd) / command[1].strip())
            if del_dir(rel_dir): print('Successfully delete "{}".'.format(rel_dir))
        elif command[0] == 'delete' and len(command) == 2:      # 删除文件
            rel_path = str(Path(cd) / command[1].strip())
            if del_file(rel_path): print('File deleted successfully.')
        elif command[0] == 'changedir':                         # 改变当前目录
            if len(command) == 2:
                rel_dir = str(Path('') / command[1].strip())
                can, new_rel_dir = change_dir(rel_dir)
                if can: 
                    cd = new_rel_dir
                    print('Change dir successfully.')
            elif len(command) == 1:
                cd = ''
                print('Change dir successfully.')
        elif command[0] == 'read' and len(command) ==2:         # 读文件
            rel_path = str(Path(cd) / command[1].strip())
            read_file(rel_path)
        elif command[0] == 'write' and len(command)==2:         # 写文件
            rel_path = str(Path(cd) / command[1].strip())
            if write_file(rel_path): print('Write file successfully.')
        elif command[0] == 'exit':
            break
        else:
            print('Invalid Command.')


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('user_id', help='Userid of the user.', type=str)
    args = parser.parse_args()

    proxy = ServerProxy(data_url, allow_none=True)
    cd = ''

    root = Path.cwd() / 'distributed_server_files'
    cache_dir = root / ('cache_'+str(args.user_id))
    if cache_dir.exists(): shutil.rmtree(cache_dir)# 用户重新登录清空缓存
    cache_dir.mkdir(parents=True) 
    main()
