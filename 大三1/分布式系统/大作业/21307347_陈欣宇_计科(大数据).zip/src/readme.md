
# 运行代码

- 启动 database

    ```shell
    python database.py
    ```

- 启动 server 并指定服务器ID以及Port

    ```shell
    python server.py <server_id> <port>
    ```

    例如：

    ```shell
    python server.py 1 1000
    ```

- 启动 client 并指定用户ID

    ```shell
    python client.py <user_id> 
    ```

    例如：

    ```shell
    python client.py 1
    ```

- 用户启动后，可以执行以下命令:
  - 展示目录: `list`
  - 创建目录：`makedir <dir>`
  - 改变目录：`changedir <dir>`
  - 删除目录: `deletedir <dir>`
  - 写文件: `write <file>`
  - 读文件: `read <file>`
  - 删除文件: `delete <file>`
  - 退出: `exit`

