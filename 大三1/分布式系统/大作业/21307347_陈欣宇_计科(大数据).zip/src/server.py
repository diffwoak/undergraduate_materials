import os
from pathlib import Path
import hashlib
import argparse
from xmlrpc.server import SimpleXMLRPCServer
from xmlrpc.client import ServerProxy, Binary
from config import data_url
import shutil
def hash_file(file_path):
    hash_obj = hashlib.sha256()
    with open(file_path, 'rb') as rbFile:
        for block in iter(lambda: rbFile.read(4096), b""):
            hash_obj.update(block)
    return hash_obj.hexdigest()
def initialize_file(server_id, path, file):
    last_modified = os.path.getmtime(path)
    hash = hash_file(path) 
    rel_path = Path(path).relative_to(server_dir) # 相对路径
    is_backup = 0
    if '_backup' in file: 
        name_no_backup = file.replace('_backup', '')
        is_backup = 1
        rel_path = rel_path.with_name(name_no_backup )
    return  server_id, str(rel_path), file, is_backup, hash, last_modified
def path_check(rel_path):
    path = (server_dir / rel_path).resolve() #绝对路径(文件/目录)
    path_exists = path.exists()                         #存在
    path_valid = str(path).startswith(str(server_dir))  #有效
    new_rel_path = str(path).replace(str(server_dir),'')
    new_rel_path = new_rel_path[1:] if new_rel_path.startswith(os.sep) else new_rel_path
    return path_exists,path_valid,new_rel_path
def make_dir(rel_path):
    path_exists,path_valid,new_rel_path =  path_check(rel_path)
    path = server_dir / new_rel_path
    if path_valid and not path_exists:
        path.mkdir(parents=True)
        return True
    return False
def del_file(rel_path, backup=False):#删除文件和所有备份文件
    path_exists,path_valid,new_rel_path = path_check(rel_path)
    if not path_valid or not path_exists:return False 
    path = server_dir / rel_path
    if path.is_file():os.remove(str(path))
    else: return False
    if not backup: # 对于原文件，还需清除备份文件以及数据库记录
        with ServerProxy(data_url, allow_none=True) as data_pxy:
            addresses = data_pxy.get_file_backup_servers(new_rel_path)
            file_backup = data_pxy.get_file_backup_name(new_rel_path)
        if addresses:
            rel_path_backup= Path(new_rel_path).with_name(file_backup[0]) 
            for address in addresses:
                with ServerProxy(address, allow_none=True) as server_pxy:
                    if not server_pxy.del_file(str(rel_path_backup), True):
                        return False
            with ServerProxy(data_url, allow_none=True) as data_pxy:
                if not data_pxy.delete_file(new_rel_path):
                    return False
    return True
def del_dir(rel_path):
    path_exists,path_valid,new_rel_path =  path_check(rel_path)
    path = server_dir / new_rel_path
    if path_valid and path_exists:
        if path.is_dir():
            path.rmdir()
            return True
        else: print("Not Dir Type\n")
    return False
def get_files(rel_dir):
    path_exists,path_valid,new_rel_dir = path_check(rel_dir)
    dir_files = []
    if path_valid and path_exists:
        for it in (server_dir / new_rel_dir).iterdir():
            if '_backup' in it.name: continue # 不返回_backup文件
            dir_files.append((it.is_dir(),str(it.relative_to(server_dir))))
    return dir_files
def hash_check(rel_path,hash_check):
    path_exists,path_valid,new_rel_path =  path_check(rel_path)
    if not path_valid or not path_exists: return False
    path = (server_dir / new_rel_path).resolve()
    hash = hash_file(str(path))
    if hash == hash_check:
        return True
    else: return False
def read_path(rel_path,hash,backup=False):
    rig = hash_check(rel_path,hash)
    if rig:
        path = (server_dir / rel_path).resolve()
        if backup: #如果找到路径为备份文件路径，将其改名为原文件，
            back_path = path
            name_no_backup = (back_path.name).replace('_backup', '')
            path = back_path.with_name(name_no_backup )
            os.rename(back_path,path) #备份文件改名为原文件,改名后调用del_file不会被删
            new_rel_path = str(Path(rel_path).with_name(name_no_backup))#原文件相对路径
            del_file(new_rel_path) #删除原文件以及其他备份文件
            with ServerProxy(data_url, allow_none=True) as data_pxy:#删除数据库中该备份文件的记录，更新原文件记录
                files_ini = proxy.insert_files(initialize_file(args.server_id, str(path), str(path.name)))
                if files_ini:
                    update_backup(new_rel_path) #更新备份
        return str(path)
    if not backup:# 对于原文件损坏，继续查找备份文件
        path = server_dir / rel_path
        with ServerProxy(data_url, allow_none=True) as data_pxy:
            addresses = data_pxy.get_file_backup_servers(rel_path)
            file_backup = data_pxy.get_file_backup_name(rel_path)
            if addresses:
                rel_path_backup= Path(rel_path).with_name(file_backup[0]) #备份文件真实路径
                for address in addresses:
                    with ServerProxy(address, allow_none=True) as server_pxy:
                        path_backup = server_pxy.read_path(str(rel_path_backup),hash,True)
                        if path_backup!='':
                            os.remove(str(path)) # 删除原文件
                            return path_backup
    return '' 
def write_new_file(content,rel_path):
    path_exists,path_valid,new_rel_path = path_check(rel_path)
    if not path_valid: return False
    path = server_dir / new_rel_path
    parent_directory = Path(path).parent
    parent_directory.mkdir(parents=True, exist_ok=True)
    with open(path,'w') as file:
        file.write(content)
    return str(path)
def update_file(rel_path):# 更新数据库原文件
    path = (server_dir / rel_path).resolve()
    with ServerProxy(data_url, allow_none=True) as data_pxy:
        address = data_pxy.get_file_servers(rel_path)
        if address:
            data_pxy.remove_one_file(rel_path)
        data_pxy.insert_files([initialize_file(args.server_id, str(path), str(path.name))])
    return True
def update_backup(rel_path,backup =False):# 更新备份
    with ServerProxy(data_url, allow_none=True) as data_pxy:
        if backup:  # 作为备份
            hash = data_pxy.get_file_hash(rel_path)[0]
            file_backup = data_pxy.get_file_backup_name(rel_path)[0]
            rel_path_backup= str(Path(rel_path).with_name(file_backup))
            if not hash_check(rel_path_backup,hash):# 检查哈希值
                backup_path = server_dir / rel_path_backup
                os.remove(str(backup_path))
                data_pxy.delete_backup_file(args.server_id,rel_path)
                return True,str(backup_path),args.server_id
            return False,'',0
        #作为原文件
        addresses = data_pxy.get_file_backup_servers(rel_path)
        if addresses:   # 存在备份
            for address in addresses:# 作为原文件
                with ServerProxy(address, allow_none=True) as server_pxy:
                    up, backup_path, backup_id = server_pxy.update_backup(rel_path,True)
                    if up:
                        path = (server_dir / rel_path).resolve()
                        shutil.copy2(path, Path(backup_path))
                        data_pxy.insert_files([server_pxy.initialize_file(backup_id, str(backup_path), str(Path(backup_path).name))])
        else:# 不存在备份则在下一个服务器新建一个备份
            address = data_pxy.get_next_server()
            global server_url
            if address==server_url:return True,'',0
            file_name = str(Path(rel_path).name).replace('.','_backup.')
            rel_path_backup = str(Path(rel_path).with_name(file_name))
            with ServerProxy(address, allow_none=True) as server_pxy:
                server_pxy.create_backup(str(server_dir / rel_path),rel_path_backup)
    return True,'',0
def create_backup(path,rel_path_backup):
    backup_path = server_dir / rel_path_backup
    parent_directory = Path(backup_path).parent
    parent_directory.mkdir(parents=True, exist_ok=True)
    shutil.copy2(path, backup_path)
    with ServerProxy(data_url, allow_none=True) as data_pxy:
        return data_pxy.insert_files([initialize_file(args.server_id, str(backup_path), str(backup_path.name))])

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('server_id', help='ID of the server.', type=int)
    parser.add_argument('port', help='Port of the server.', type=int)
    args = parser.parse_args()
    
    with SimpleXMLRPCServer(('localhost', args.port)) as server: 
        server.register_function(path_check)
        server.register_function(make_dir)
        server.register_function(del_dir)
        server.register_function(del_file)
        server.register_function(get_files)
        server.register_function(hash_check)
        server.register_function(read_path)
        server.register_function(write_new_file)
        server.register_function(update_backup)
        server.register_function(update_file)
        server.register_function(create_backup)
        server.register_function(initialize_file)
        server.register_function(hash_file)
        


        server_url = 'http://{}:{}'.format(server.server_address[0], server.server_address[1])
        server_ini = False
        with ServerProxy(data_url, allow_none=True) as proxy:
            # 更新SERVERS表信息
            server_ini = proxy.insert_server(args.server_id,str(server_url))
        if server_ini:
            # 根目录设置在当前工作目录下，创建服务器目录
            root = Path.cwd() / 'distributed_server_files'
            server_dir = root / ('server_'+str(args.server_id))
            if not server_dir.exists():
                server_dir.mkdir(parents=True)
            # 遍历原有文件，更新FILES表信息
            file_list = []
            for root, dirs, files in os.walk(str(server_dir)):
                for file in files: 
                    path = os.path.join(root, file)
                    file_info = initialize_file(args.server_id, path, file)
                    print('initialize file:', file_info[2])
                    file_list.append(file_info)
            files_ini = False
            with ServerProxy(data_url, allow_none=True) as proxy:
                files_ini = proxy.insert_files(file_list)
            if files_ini:
                print("Server initialize successfully")
                try:
                    server.serve_forever()  # 保持监听客户端请求
                except KeyboardInterrupt:
                    with ServerProxy(data_url, allow_none=True) as proxy:
                        proxy.delete_server(args.server_id)
            else:
                print('Failed file registration.')
        else:
            print('Failed server registration.')
