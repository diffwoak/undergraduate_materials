data_info = ('localhost', 9999)
data_url = 'http://{}:{}'.format(data_info[0], data_info[1])