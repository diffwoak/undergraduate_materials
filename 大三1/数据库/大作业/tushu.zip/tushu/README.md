## 数据库大作业

 基于SpringBoot+Vue前后端分离的Java快速开发框架 实现图书管理销售系统

### 基本流程

1. 下载配置基本环境，参考jdk1.8，Mysql8.0.31，Redis5.0.14.1，Maven3.6，Node16.19.1，IDEA2023.1，VS Code1.85.1

2. 数据库

- 创建本地数据库
- 数据库运行`\tushu\sql\tushu.sql`文件

3. Redis

- 创建连接

4. 后端运行

- IDEA 打开整个项目
- 配置'\tushu\ruoyi-admin\src\main\resources'目录下`application.yml`和`application-druid.yml`文件
- 运行`\tushu\ruoyi-admin\src\main\java\com\ruoyi\RuoYiApplication.java`文件

5. 前端运行

- IDEA或VSCode 打开`\tushu\ruoyi-ui`
- 查看`ruoyi-ui`目录运行文档