package com.ruoyi.tushudb.mapper;

import java.util.List;
import com.ruoyi.tushudb.domain.Consumer;

/**
 * 客户信息Mapper接口
 * 
 * @author ruoyi
 * @date 2023-12-16
 */
public interface ConsumerMapper 
{
    /**
     * 查询客户信息
     * 
     * @param id 客户信息主键
     * @return 客户信息
     */
    public Consumer selectConsumerById(Long id);

    /**
     * 查询客户信息列表
     * 
     * @param consumer 客户信息
     * @return 客户信息集合
     */
    public List<Consumer> selectConsumerList(Consumer consumer);

    /**
     * 新增客户信息
     * 
     * @param consumer 客户信息
     * @return 结果
     */
    public int insertConsumer(Consumer consumer);

    /**
     * 修改客户信息
     * 
     * @param consumer 客户信息
     * @return 结果
     */
    public int updateConsumer(Consumer consumer);

    /**
     * 删除客户信息
     * 
     * @param id 客户信息主键
     * @return 结果
     */
    public int deleteConsumerById(Long id);

    /**
     * 批量删除客户信息
     * 
     * @param ids 需要删除的数据主键集合
     * @return 结果
     */
    public int deleteConsumerByIds(Long[] ids);
}
