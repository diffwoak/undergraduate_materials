package com.ruoyi.tushudb.mapper;

import java.util.List;
import com.ruoyi.tushudb.domain.Sales;

/**
 * 进货Mapper接口
 * 
 * @author ruoyi
 * @date 2023-12-16
 */
public interface SalesMapper 
{
    /**
     * 查询进货
     * 
     * @param id 进货主键
     * @return 进货
     */
    public Sales selectSalesById(Long id);

    /**
     * 查询进货列表
     * 
     * @param sales 进货
     * @return 进货集合
     */
    public List<Sales> selectSalesList(Sales sales);

    /**
     * 新增进货
     * 
     * @param sales 进货
     * @return 结果
     */
    public int insertSales(Sales sales);

    /**
     * 修改进货
     * 
     * @param sales 进货
     * @return 结果
     */
    public int updateSales(Sales sales);

    /**
     * 删除进货
     * 
     * @param id 进货主键
     * @return 结果
     */
    public int deleteSalesById(Long id);

    /**
     * 批量删除进货
     * 
     * @param ids 需要删除的数据主键集合
     * @return 结果
     */
    public int deleteSalesByIds(Long[] ids);
}
