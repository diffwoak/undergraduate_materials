package com.ruoyi.tushudb.mapper;

import java.util.List;
import com.ruoyi.tushudb.domain.Purchase;

/**
 * 销售Mapper接口
 * 
 * @author ruoyi
 * @date 2023-12-16
 */
public interface PurchaseMapper 
{
    /**
     * 查询销售
     * 
     * @param id 销售主键
     * @return 销售
     */
    public Purchase selectPurchaseById(Long id);

    /**
     * 查询销售列表
     * 
     * @param purchase 销售
     * @return 销售集合
     */
    public List<Purchase> selectPurchaseList(Purchase purchase);

    /**
     * 新增销售
     * 
     * @param purchase 销售
     * @return 结果
     */
    public int insertPurchase(Purchase purchase);

    /**
     * 修改销售
     * 
     * @param purchase 销售
     * @return 结果
     */
    public int updatePurchase(Purchase purchase);

    /**
     * 删除销售
     * 
     * @param id 销售主键
     * @return 结果
     */
    public int deletePurchaseById(Long id);

    /**
     * 批量删除销售
     * 
     * @param ids 需要删除的数据主键集合
     * @return 结果
     */
    public int deletePurchaseByIds(Long[] ids);
}
