package com.ruoyi.tushudb.domain;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import com.ruoyi.common.annotation.Excel;
import com.ruoyi.common.core.domain.BaseEntity;

/**
 * 图书集对象 book
 * 
 * @author ruoyi
 * @date 2023-12-16
 */
public class Book extends BaseEntity
{
    private static final long serialVersionUID = 1L;

    /** 编号 */
    private Long id;

    /** 书号 */
    @Excel(name = "书号")
    private String bookId;

    /** 书名 */
    @Excel(name = "书名")
    private String name;

    /** 出版社 */
    @Excel(name = "出版社")
    private String publish;

    public void setId(Long id) 
    {
        this.id = id;
    }

    public Long getId() 
    {
        return id;
    }
    public void setBookId(String bookId) 
    {
        this.bookId = bookId;
    }

    public String getBookId() 
    {
        return bookId;
    }
    public void setName(String name) 
    {
        this.name = name;
    }

    public String getName() 
    {
        return name;
    }
    public void setPublish(String publish) 
    {
        this.publish = publish;
    }

    public String getPublish() 
    {
        return publish;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this,ToStringStyle.MULTI_LINE_STYLE)
            .append("id", getId())
            .append("bookId", getBookId())
            .append("name", getName())
            .append("publish", getPublish())
            .toString();
    }
}
