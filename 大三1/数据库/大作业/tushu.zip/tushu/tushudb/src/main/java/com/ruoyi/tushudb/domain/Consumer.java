package com.ruoyi.tushudb.domain;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import com.ruoyi.common.annotation.Excel;
import com.ruoyi.common.core.domain.BaseEntity;

/**
 * 客户信息对象 consumer
 * 
 * @author ruoyi
 * @date 2023-12-16
 */
public class Consumer extends BaseEntity
{
    private static final long serialVersionUID = 1L;

    /** 编号 */
    private Long id;

    /** 客户号 */
    @Excel(name = "客户号")
    private String consumerId;

    /** 名字 */
    @Excel(name = "名字")
    private String name;

    /** 电话 */
    @Excel(name = "电话")
    private String tele;

    /** 地址 */
    @Excel(name = "地址")
    private String addr;

    /** 性别 */
    @Excel(name = "性别")
    private String sex;

    public void setId(Long id) 
    {
        this.id = id;
    }

    public Long getId() 
    {
        return id;
    }
    public void setConsumerId(String consumerId) 
    {
        this.consumerId = consumerId;
    }

    public String getConsumerId() 
    {
        return consumerId;
    }
    public void setName(String name) 
    {
        this.name = name;
    }

    public String getName() 
    {
        return name;
    }
    public void setTele(String tele) 
    {
        this.tele = tele;
    }

    public String getTele() 
    {
        return tele;
    }
    public void setAddr(String addr) 
    {
        this.addr = addr;
    }

    public String getAddr() 
    {
        return addr;
    }
    public void setSex(String sex) 
    {
        this.sex = sex;
    }

    public String getSex() 
    {
        return sex;
    }



    @Override
    public String toString() {
        return new ToStringBuilder(this,ToStringStyle.MULTI_LINE_STYLE)
            .append("id", getId())
            .append("consumerId", getConsumerId())
            .append("name", getName())
            .append("tele", getTele())
            .append("addr", getAddr())
            .append("sex", getSex())
            .toString();
    }
}
