package com.ruoyi.tushudb.domain;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import com.ruoyi.common.annotation.Excel;
import com.ruoyi.common.core.domain.BaseEntity;

/**
 * 进货对象 sales
 * 
 * @author ruoyi
 * @date 2023-12-16
 */
public class Sales extends BaseEntity
{
    private static final long serialVersionUID = 1L;

    /** 编号 */
    private Long id;

    /** 书号 */
    @Excel(name = "书号")
    private String bookId;

    /** 单号 */
    @Excel(name = "单号")
    private String salesId;

    /** 商家 */
    @Excel(name = "商家")
    private String supplier;

    /** 库存 */
    @Excel(name = "库存")
    private Long num;

    /** 单价 */
    @Excel(name = "单价")
    private Long price;

    public void setId(Long id) 
    {
        this.id = id;
    }

    public Long getId() 
    {
        return id;
    }
    public void setBookId(String bookId) 
    {
        this.bookId = bookId;
    }

    public String getBookId() 
    {
        return bookId;
    }
    public void setSalesId(String salesId) 
    {
        this.salesId = salesId;
    }

    public String getSalesId() 
    {
        return salesId;
    }
    public void setSupplier(String supplier) 
    {
        this.supplier = supplier;
    }

    public String getSupplier() 
    {
        return supplier;
    }
    public void setNum(Long num) 
    {
        this.num = num;
    }

    public Long getNum() 
    {
        return num;
    }
    public void setPrice(Long price) 
    {
        this.price = price;
    }

    public Long getPrice() 
    {
        return price;
    }

    public void setBook(Book book) {
        this.book = book;
    }

    private Book book;
    public Book getBook() {
        return book;
    }
    @Override
    public String toString() {
        return new ToStringBuilder(this,ToStringStyle.MULTI_LINE_STYLE)
            .append("id", getId())
            .append("bookId", getBookId())
            .append("salesId", getSalesId())
            .append("supplier", getSupplier())
            .append("num", getNum())
            .append("price", getPrice())
                .append("book", getBook())
            .toString();
    }
}
