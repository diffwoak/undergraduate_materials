package com.ruoyi.tushudb.domain;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import com.ruoyi.common.annotation.Excel;
import com.ruoyi.common.core.domain.BaseEntity;

/**
 * 库存对象 stock
 * 
 * @author ruoyi
 * @date 2023-12-16
 */
public class Stock extends BaseEntity
{
    private static final long serialVersionUID = 1L;

    /** 编号 */
    private Long id;

    /** 书号 */
    @Excel(name = "书号")
    private String bookId;

    /** 单价 */
    @Excel(name = "单价")
    private Long price;

    /** 库存量 */
    @Excel(name = "库存量")
    private Long num;

    public void setId(Long id) 
    {
        this.id = id;
    }

    public Long getId() 
    {
        return id;
    }
    public void setBookId(String bookId) 
    {
        this.bookId = bookId;
    }

    public String getBookId() 
    {
        return bookId;
    }
    public void setPrice(Long price) 
    {
        this.price = price;
    }

    public Long getPrice() 
    {
        return price;
    }
    public void setNum(Long num) 
    {
        this.num = num;
    }

    public Long getNum() 
    {
        return num;
    }

    public void setBook(Book book) {
    this.book = book;
}

    private Book book;
    public Book getBook() {
        return book;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this,ToStringStyle.MULTI_LINE_STYLE)
            .append("id", getId())
            .append("bookId", getBookId())
            .append("price", getPrice())
            .append("num", getNum())
                .append("book", getBook())
            .toString();
    }
}
