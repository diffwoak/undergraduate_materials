package com.ruoyi.tushudb.mapper;

import java.util.List;
import com.ruoyi.tushudb.domain.Book;

/**
 * 图书集Mapper接口
 * 
 * @author ruoyi
 * @date 2023-12-16
 */
public interface BookMapper 
{
    /**
     * 查询图书集
     * 
     * @param id 图书集主键
     * @return 图书集
     */
    public Book selectBookById(Long id);

    /**
     * 查询图书集列表
     * 
     * @param book 图书集
     * @return 图书集集合
     */
    public List<Book> selectBookList(Book book);

    /**
     * 新增图书集
     * 
     * @param book 图书集
     * @return 结果
     */
    public int insertBook(Book book);

    /**
     * 修改图书集
     * 
     * @param book 图书集
     * @return 结果
     */
    public int updateBook(Book book);

    /**
     * 删除图书集
     * 
     * @param id 图书集主键
     * @return 结果
     */
    public int deleteBookById(Long id);

    /**
     * 批量删除图书集
     * 
     * @param ids 需要删除的数据主键集合
     * @return 结果
     */
    public int deleteBookByIds(Long[] ids);
}
