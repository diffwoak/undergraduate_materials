package com.ruoyi.tushudb.domain;

import java.util.Date;
import com.fasterxml.jackson.annotation.JsonFormat;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import com.ruoyi.common.annotation.Excel;
import com.ruoyi.common.core.domain.BaseEntity;

/**
 * 销售对象 purchase
 * 
 * @author ruoyi
 * @date 2023-12-16
 */
public class Purchase extends BaseEntity
{
    private static final long serialVersionUID = 1L;

    /** 编号 */
    private Long id;

    /** 书号 */
    @Excel(name = "书号")
    private String bookId;

    /** 客户号 */
    @Excel(name = "客户号")
    private String consumerId;

    /** 销售数量 */
    @Excel(name = "销售数量")
    private Long num;

    /** 是否退货 */
    @Excel(name = "是否退货")
    private String refund;

    /** 销售时间 */
    @JsonFormat(pattern = "yyyy-MM-dd")
    @Excel(name = "销售时间", width = 30, dateFormat = "yyyy-MM-dd")
    private Date time;

    public void setId(Long id) 
    {
        this.id = id;
    }

    public Long getId() 
    {
        return id;
    }
    public void setBookId(String bookId) 
    {
        this.bookId = bookId;
    }

    public String getBookId() 
    {
        return bookId;
    }
    public void setConsumerId(String consumerId) 
    {
        this.consumerId = consumerId;
    }

    public String getConsumerId() 
    {
        return consumerId;
    }
    public void setNum(Long num) 
    {
        this.num = num;
    }

    public Long getNum() 
    {
        return num;
    }
    public void setRefund(String refund) 
    {
        this.refund = refund;
    }

    public String getRefund() 
    {
        return refund;
    }
    public void setTime(Date time) 
    {
        this.time = time;
    }

    public Date getTime() 
    {
        return time;
    }
    public void setBook(Book book) {
        this.book = book;
    }

    private Book book;
    public Book getBook() {
        return book;
    }
    @Override
    public String toString() {
        return new ToStringBuilder(this,ToStringStyle.MULTI_LINE_STYLE)
            .append("id", getId())
            .append("bookId", getBookId())
            .append("consumerId", getConsumerId())
            .append("num", getNum())
            .append("refund", getRefund())
            .append("time", getTime())
                .append("book", getBook())
            .toString();
    }
}
