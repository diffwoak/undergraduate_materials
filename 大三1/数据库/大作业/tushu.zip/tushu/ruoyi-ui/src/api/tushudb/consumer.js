import request from '@/utils/request'

// 查询客户信息列表
export function listConsumer(query) {
  return request({
    url: '/tushudb/consumer/list',
    method: 'get',
    params: query
  })
}

// 查询客户信息详细
export function getConsumer(id) {
  return request({
    url: '/tushudb/consumer/' + id,
    method: 'get'
  })
}

// 新增客户信息
export function addConsumer(data) {
  return request({
    url: '/tushudb/consumer',
    method: 'post',
    data: data
  })
}

// 修改客户信息
export function updateConsumer(data) {
  return request({
    url: '/tushudb/consumer',
    method: 'put',
    data: data
  })
}

// 删除客户信息
export function delConsumer(id) {
  return request({
    url: '/tushudb/consumer/' + id,
    method: 'delete'
  })
}
