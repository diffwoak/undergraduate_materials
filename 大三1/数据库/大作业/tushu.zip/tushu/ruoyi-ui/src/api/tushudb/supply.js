import request from '@/utils/request'

// 查询入货单列表
export function listSupply(query) {
  return request({
    url: '/tushudb/supply/list',
    method: 'get',
    params: query
  })
}

// 查询入货单详细
export function getSupply(id) {
  return request({
    url: '/tushudb/supply/' + id,
    method: 'get'
  })
}

// 新增入货单
export function addSupply(data) {
  return request({
    url: '/tushudb/supply',
    method: 'post',
    data: data
  })
}

// 修改入货单
export function updateSupply(data) {
  return request({
    url: '/tushudb/supply',
    method: 'put',
    data: data
  })
}

// 删除入货单
export function delSupply(id) {
  return request({
    url: '/tushudb/supply/' + id,
    method: 'delete'
  })
}
