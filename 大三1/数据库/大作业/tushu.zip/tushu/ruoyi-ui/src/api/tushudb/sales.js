import request from '@/utils/request'

// 查询进货列表
export function listSales(query) {
  return request({
    url: '/tushudb/sales/list',
    method: 'get',
    params: query
  })
}

// 查询进货详细
export function getSales(id) {
  return request({
    url: '/tushudb/sales/' + id,
    method: 'get'
  })
}

// 新增进货
export function addSales(data) {
  return request({
    url: '/tushudb/sales',
    method: 'post',
    data: data
  })
}

// 修改进货
export function updateSales(data) {
  return request({
    url: '/tushudb/sales',
    method: 'put',
    data: data
  })
}

// 删除进货
export function delSales(id) {
  return request({
    url: '/tushudb/sales/' + id,
    method: 'delete'
  })
}
