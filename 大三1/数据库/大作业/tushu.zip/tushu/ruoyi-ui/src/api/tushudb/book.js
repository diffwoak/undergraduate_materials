import request from '@/utils/request'

// 查询图书集列表
export function listBook(query) {
  return request({
    url: '/tushudb/book/list',
    method: 'get',
    params: query
  })
}

// 查询图书集详细
export function getBook(id) {
  return request({
    url: '/tushudb/book/' + id,
    method: 'get'
  })
}

// 新增图书集
export function addBook(data) {
  return request({
    url: '/tushudb/book',
    method: 'post',
    data: data
  })
}

// 修改图书集
export function updateBook(data) {
  return request({
    url: '/tushudb/book',
    method: 'put',
    data: data
  })
}

// 删除图书集
export function delBook(id) {
  return request({
    url: '/tushudb/book/' + id,
    method: 'delete'
  })
}
