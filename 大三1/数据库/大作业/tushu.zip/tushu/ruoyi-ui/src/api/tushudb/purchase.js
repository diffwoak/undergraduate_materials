import request from '@/utils/request'

// 查询销售列表
export function listPurchase(query) {
  return request({
    url: '/tushudb/purchase/list',
    method: 'get',
    params: query
  })
}

// 查询销售详细
export function getPurchase(id) {
  return request({
    url: '/tushudb/purchase/' + id,
    method: 'get'
  })
}

// 新增销售
export function addPurchase(data) {
  return request({
    url: '/tushudb/purchase',
    method: 'post',
    data: data
  })
}

// 修改销售
export function updatePurchase(data) {
  return request({
    url: '/tushudb/purchase',
    method: 'put',
    data: data
  })
}

// 删除销售
export function delPurchase(id) {
  return request({
    url: '/tushudb/purchase/' + id,
    method: 'delete'
  })
}
