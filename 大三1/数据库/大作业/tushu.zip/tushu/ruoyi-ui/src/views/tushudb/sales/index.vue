<template>
  <div class="app-container">
    <el-form :model="queryParams" ref="queryForm" size="small" :inline="true" v-show="showSearch" label-width="68px">
      <el-form-item label="书号" prop="bookId">
        <el-input
          v-model="queryParams.bookId"
          placeholder="请输入书号"
          clearable
          @keyup.enter.native="handleQuery"
        />
      </el-form-item>
      <el-form-item label="书名">
        <el-input
          v-model="queryParams['book.name']"
          placeholder="请输入书名"
          clearable
          @keyup.enter.native="handleQuery"
        />
      </el-form-item>
      <el-form-item label="出版社">
        <el-input
          v-model="queryParams['book.publish']"
          placeholder="请输入出版社"
          clearable
          @keyup.enter.native="handleQuery"
        />
      </el-form-item>
      <el-form-item label="单号" prop="salesId">
        <el-input
          v-model="queryParams.salesId"
          placeholder="请输入单号"
          clearable
          @keyup.enter.native="handleQuery"
        />
      </el-form-item>
      <el-form-item label="商家" prop="supplier">
        <el-input
          v-model="queryParams.supplier"
          placeholder="请输入商家"
          clearable
          @keyup.enter.native="handleQuery"
        />
      </el-form-item>
      <el-form-item label="库存" prop="num">
        <el-input
          v-model="queryParams.num"
          placeholder="请输入库存"
          clearable
          @keyup.enter.native="handleQuery"
        />
      </el-form-item>
      <el-form-item label="单价" prop="price">
        <el-input
          v-model="queryParams.price"
          placeholder="请输入单价"
          clearable
          @keyup.enter.native="handleQuery"
        />
      </el-form-item>
      <el-form-item>
        <el-button type="primary" icon="el-icon-search" size="mini" @click="handleQuery">搜索</el-button>
        <el-button icon="el-icon-refresh" size="mini" @click="resetQuery">重置</el-button>
      </el-form-item>
    </el-form>
    
    <el-row :gutter="10" class="mb8" v-if="character==='超级管理员'">
      <el-col :span="1.5">
        <el-button
          type="primary"
          plain
          icon="el-icon-plus"
          size="mini"
          @click="handleAdd"
          v-hasPermi="['tushudb:sales:add']"
        >新增</el-button>
      </el-col>
      <el-col :span="1.5">
        <el-button
          type="success"
          plain
          icon="el-icon-edit"
          size="mini"
          :disabled="single"
          @click="handleUpdate"
          v-hasPermi="['tushudb:sales:edit']"
        >修改</el-button>
      </el-col>
      <el-col :span="1.5">
        <el-button
          type="danger"
          plain
          icon="el-icon-delete"
          size="mini"
          :disabled="multiple"
          @click="handleDelete"
          v-hasPermi="['tushudb:sales:remove']"
        >删除</el-button>
      </el-col>
      <el-col :span="1.5">
        <el-button
          type="warning"
          plain
          icon="el-icon-download"
          size="mini"
          @click="handleExport"
          v-hasPermi="['tushudb:sales:export']"
        >导出</el-button>
      </el-col>
      <right-toolbar :showSearch.sync="showSearch" @queryTable="getList"></right-toolbar>
    </el-row>

    <el-table v-loading="loading" :data="salesList" @selection-change="handleSelectionChange">
      <el-table-column type="selection" width="55" align="center" />
      <!-- <el-table-column label="编号" align="center" prop="id" /> -->
      <el-table-column label="单号" align="center" prop="salesId" />
      <el-table-column label="书号" align="center" prop="bookId" />
      <el-table-column label="书名" align="center" prop="book.name" />
      <el-table-column label="出版社" align="center" prop="book.publish" />
      <el-table-column label="商家" align="center" prop="supplier" />
      <el-table-column label="库存" align="center" prop="num" />
      <el-table-column label="单价" align="center" prop="price" />
      <el-table-column label="操作" align="center" class-name="small-padding fixed-width">
        <template slot-scope="scope">
          <el-button
            size="mini"
            type="text"
            icon="el-icon-edit"
            @click="handleUpdate(scope.row)"
            v-hasPermi="['tushudb:sales:edit']"
            v-if="character==='超级管理员'"
          >修改</el-button>
          <el-button
            size="mini"
            type="text"
            icon="el-icon-edit"
            @click="handlesupply(scope.row)"
            v-hasPermi="['tushudb:sales:edit']"
            v-if="character==='超级管理员' ||character==='图书管理员'"
          >进货</el-button>
          <el-button
            size="mini"
            type="text"
            icon="el-icon-delete"
            @click="handleDelete(scope.row)"
            v-hasPermi="['tushudb:sales:remove']"
            v-if="character==='超级管理员'"
          >删除</el-button>
        </template>
      </el-table-column>
    </el-table>
    
    <pagination
      v-show="total>0"
      :total="total"
      :page.sync="queryParams.pageNum"
      :limit.sync="queryParams.pageSize"
      @pagination="getList"
    />

    <!-- 添加或修改进货对话框 -->
    <el-dialog :title="title" :visible.sync="open" width="500px" append-to-body>
      <el-form ref="form" :model="form" :rules="rules" label-width="80px">
        <el-form-item label="书号" prop="bookId">
          <el-input v-model="form.bookId" placeholder="请输入书号"/>
        </el-form-item>
        <el-form-item label="单号" prop="salesId">
          <el-input v-model="form.salesId" placeholder="请输入单号" />
        </el-form-item>
        <el-form-item label="商家" prop="supplier">
          <el-input v-model="form.supplier" placeholder="请输入商家" />
        </el-form-item>
        <el-form-item label="库存" prop="num">
          <el-input v-model="form.num" placeholder="请输入库存" />
        </el-form-item>
        <el-form-item label="单价" prop="price">
          <el-input v-model="form.price" placeholder="请输入单价" />
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button type="primary" @click="submitForm">确 定</el-button>
        <el-button @click="cancel">取 消</el-button>
      </div>
    </el-dialog>
    <!-- 进货对话框 -->
    <el-dialog :title="title" :visible.sync="supplyopen" width="500px" append-to-body>
      <el-form ref="form" :model="form" :rules="rules" label-width="80px">
        <el-form-item label="单号" prop="salesId">
          <el-input v-model="form.salesId" readonly/>
        </el-form-item>
        <el-form-item label="书号" prop="bookId">
          <el-input v-model="form.bookId" readonly />
        </el-form-item>
        <el-form-item label="商家" prop="supplier">
          <el-input v-model="form.supplier" readonly />
        </el-form-item>
        <el-form-item label="单价" prop="price">
          <el-input v-model="form.price" readonly />
        </el-form-item>
        <el-form-item label="商家库存" prop="num">
          <el-input v-model="form.num" readonly />
        </el-form-item>
        <el-form-item label="进货量" prop="supplynum">
          <el-slider :max='form.num' :step='1' v-model="form.supplynum"></el-slider>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button type="primary" @click="submitsupply">确定入货</el-button>
        <el-button @click="cancel">取 消</el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script>
import { listSales, getSales, delSales, addSales, updateSales } from "@/api/tushudb/sales";
import {getUserProfile} from "@/api/system/user";
import {addSupply } from "@/api/tushudb/supply";
export default {
  name: "Sales",
  data() {
    return {
      character: null,
      // 遮罩层
      loading: true,
      // 选中数组
      ids: [],
      // 非单个禁用
      single: true,
      // 非多个禁用
      multiple: true,
      // 显示搜索条件
      showSearch: true,
      // 总条数
      total: 0,
      // 进货表格数据
      salesList: [],
      // 弹出层标题
      title: "",
      // 是否显示添加或修改弹出层
      open: false,
      // 是否显示进货弹出层
      supplyopen:false,
      // 查询参数
      queryParams: {
        pageNum: 1,
        pageSize: 10,
        bookId: null,
        salesId: null,
        supplier: null,
        num: null,
        price: null,
        'book.name':'',
        'book.publish':''
      },
      // 表单参数
      form: {},
      // 表单校验
      rules: {
      },
    };
  },
  created() {
    getUserProfile().then(response => {
      // console.log(response);
      this.character = response.roleGroup;
      this.getList();
    });
  },
  methods: {
    /** 查询进货列表 */
    getList() {
      this.loading = true;
      listSales(this.queryParams).then(response => {
        this.salesList = response.rows;
        this.total = response.total;
        this.loading = false;
      });
    },
    // 取消按钮
    cancel() {
      this.open = false;
      this.supplyopen = false;
      this.reset();
    },
    // 表单重置
    reset() {
      this.form = {
        id: null,
        bookId: null,
        salesId: null,
        supplier: null,
        num: null,
        price: null,
        'book.name':'',
        'book.publish':'',
        supplynum: null,
        time:null
      };
      this.resetForm("form");
    },
    /** 搜索按钮操作 */
    handleQuery() {
      this.queryParams.pageNum = 1;
      this.getList();
    },
    /** 重置按钮操作 */
    resetQuery() {
      this.queryParams['book.name']="";
      this.queryParams['book.publish']="";
      this.resetForm("queryForm");
      this.handleQuery();
    },
    // 多选框选中数据
    handleSelectionChange(selection) {
      this.ids = selection.map(item => item.id)
      this.single = selection.length!==1
      this.multiple = !selection.length
    },
    /** 新增按钮操作 */
    handleAdd() {
      this.reset();
      this.open = true;
      this.title = "添加进货";
    },
    /** 修改按钮操作 */
    handleUpdate(row) {
      this.reset();
      const id = row.id || this.ids
      getSales(id).then(response => {
        this.form = response.data;
        this.open = true;
        this.title = "修改进货";
      });
    },
    /** 进货按钮操作 */
    handlesupply(row){
      this.reset();
      const id = row.id || this.ids
      getSales(id).then(response =>{
        this.form = response.data;
        this.supplyopen = true;
        this.title = "进货详情";
      });
    },
    /** 确认进货按钮 */
    submitsupply(){
      this.form.num = this.form.num - this.form.supplynum;
      this.form.time = new Date();
      console.log(this.form);
      this.$refs["form"].validate(valid => {
        if (valid) {
          if (this.form.id != null) {
            updateSales(this.form).then(response => {
              this.$modal.msgSuccess("进货成功");
              this.supplyopen = false;
              this.getList();
            });
            this.form.id = null;
            this.form.num = this.form.supplynum;
            addSupply(this.form).then(response => {
              this.$modal.msgSuccess("成功生成进货单");
            });
          }
        }
      });
    },
    /** 提交按钮 */
    submitForm() {
      this.$refs["form"].validate(valid => {
        if (valid) {
          if (this.form.id != null) {
            updateSales(this.form).then(response => {
              this.$modal.msgSuccess("修改成功");
              this.open = false;
              this.getList();
            });
          } else {
            addSales(this.form).then(response => {
              this.$modal.msgSuccess("新增成功");
              this.open = false;
              this.getList();
            });
          }
        }
      });
    },
    /** 删除按钮操作 */
    handleDelete(row) {
      const ids = row.id || this.ids;
      this.$modal.confirm('是否确认删除进货编号为"' + ids + '"的数据项？').then(function() {
        return delSales(ids);
      }).then(() => {
        this.getList();
        this.$modal.msgSuccess("删除成功");
      }).catch(() => {});
    },
    /** 导出按钮操作 */
    handleExport() {
      this.download('tushudb/sales/export', {
        ...this.queryParams
      }, `sales_${new Date().getTime()}.xlsx`)
    }
  }
};
</script>
