clear 
clc
%给图像赋值
image1 = zeros(256,256);
for i = 1:256
    image1(:,i) = i-1;
end
%subplot(1,2,1);
%imshow(uint8(image1));
image1 = logical(halftoning(image1));
%subplot(1,2,2);
imshow(image1);


im_face = imread("Fig0222(a)(face).tif");
im_cameraman = imread("Fig0222(b)(cameraman).tif");
im_crowd = imread("Fig0222(c)(crowd).tif");

im_face_1 = logical(halftoning(im_face));
im_cameraman_1 = logical(halftoning(im_cameraman));
im_crowd = logical(halftoning(im_crowd));

%subplot(1,2,1);
%imshow(uint8(im_face));
%subplot(1,2,2);
%imshow(im_face_1);