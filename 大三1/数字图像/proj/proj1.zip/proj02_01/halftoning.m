function out = halftoning(input) 
%这里设置输出图像的dpi为96,M、N为图片矩阵长宽最大值
dpi = 96;
M = dpi*8.5/3;
N = dpi*11/3;
[m,n] = size(input);
%判断图片是否需要缩放并执行缩放操作
if m>M || n>N 
    input = imresize(input,min(M/m,N/n));
end
[m,n] = size(input);
%将图片转化为十灰度级
image = floor(double(input)/25.6);
%将不同灰度级按表格转化为对应像素格
matrix = zeros(10,3,3);
matrix(2,:,:) = [0 1 0 ; 0 0 0 ; 0 0 0];
matrix(3,:,:) = [0 1 0 ; 0 0 0 ; 0 0 1];
matrix(4,:,:) = [1 1 0 ; 0 0 0 ; 0 0 1];
matrix(5,:,:) = [1 1 0 ; 0 0 0 ; 1 0 1];
matrix(6,:,:) = [1 1 1 ; 0 0 0 ; 1 0 1];
matrix(7,:,:) = [1 1 1 ; 0 0 1 ; 1 0 1];
matrix(8,:,:) = [1 1 1 ; 0 0 1 ; 1 1 1];
matrix(9,:,:) = [1 1 1 ; 1 0 1 ; 1 1 1];
matrix(10,:,:) = [1 1 1 ; 1 1 1 ; 1 1 1];
out = zeros(m*3,n*3);
for i = 1:m
    for j = 1:n
        out(i*3-2:i*3,j*3-2:j*3) = matrix(image(i,j)+1,:,:);
    end
end


