function [hg] = hist(image)
%hist 计算图像直方图
% 输入 图像灰度矩阵
% 输出 直方图数组
[h,w]=size(image);
hg = zeros(1,256); 
for i=1:h
    for j=1:w
        t = int16(image(i,j));
        hg(t+1) = hg(t+1)+1;
    end
end
for i=1:length(hg)
    hg(i) = (hg(i)/(h*w));
end
end
