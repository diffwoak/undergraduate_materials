function [S] = equal(hg)
%equal 均衡化映射函数
% 输入 原直方图数组
% 输出 映射数组
S=zeros(1,256);
S(1)=hg(1);
for i=2:length(hg)
    S(i)=S(i-1)+hg(i);
end
S=round(S*255);
end