function [S] = equaln()
%equaln 均衡化映射函数,对数变换
S=zeros(1,256);
for i=1:256
    S(i)=round(255*log(i)/log(256));
end
end