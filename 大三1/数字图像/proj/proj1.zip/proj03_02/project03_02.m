clear
clc
img = imread('3.8(a).tif');
img = im2uint8(mat2gray(img));
img = im2uint8(mat2gray(img));
[h,w]=size(img);
[hg] = hist(img); %计算直方图
[S] = equal(hg); %映射函数
img1=img;
for i=1:h
    for j=1:w
        img1(i,j)=S(uint16(img(i,j))+1);
    end
end
[hg1] = hist(img1);
figure(1)
subplot(2,3,1),bar(0:255,hg),title('原直方图');
subplot(2,3,2),bar(0:255,hg1),title('均衡化后直方图');
subplot(2,3,3),plot(0:255,S),title('映射函数');
subplot(2,3,4),imshow(img),title('原图');
subplot(2,3,5),imshow(img1),title('均衡化后图像');

z=equaln();
figure(2)
plot(0:255,z),title('对数变换映射图');
img2=img;
for i=1:h
    for j=1:w
        img2(i,j)=z(uint16(img(i,j))+1);
    end
end
figure(3)
subplot(1,3,1),imshow(img),title('原图');
subplot(1,3,2),imshow(img1),title('原均衡化图像');
subplot(1,3,3),imshow(img2),title('改进后均衡化图像');

