img = imread('3.40(a).tif');
img = im2uint8(mat2gray(img));
mask = [0 1 0 ; 1 -4 1 ; 0 1 0];%第一次锐化使用
mask1 = [-1 -1 -1 ; -1 8 -1 ; -1 -1 -1];%第二次锐化使用
hg = SpatialFiltering(img,mask);%第一次锐化拉普拉斯图像
hg1 = scale(hg);%缩放灰度后拉普拉斯图像
img1 = (img+uint8(hg));%第一次锐化后图像
img2 = (img+uint8(SpatialFiltering(img,mask1)));%第二次锐化图像
subplot(2,3,1),imshow(img),title('原图');
subplot(2,3,2),imshow(uint8(hg)),title('拉普拉斯图像1');
subplot(2,3,3),imshow(img1),title('锐化后图像1');
subplot(2,3,4),imshow(img2),title('锐化后图像2');
subplot(2,3,5),imshow(uint8(hg1)),title('缩放灰度后拉普拉斯图像');
%imwrite(img1,"img1.tif");imwrite(img2,"img2.tif");imwrite(uint8(hg),"hg.tif");imwrite(uint8(hg1),"hg1.tif");
