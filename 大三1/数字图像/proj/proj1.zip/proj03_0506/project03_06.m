img = imread('3.43(a).tif');
img = im2uint8(mat2gray(img));
A = 1.7;
mask = [0 -1 0;-1 A+4 -1;0 -1 0];%逼近
%mask = 1/9*[1 1 1 ; 1 1 1 ; 1 1 1];%3.34(a)掩码
%mask1 = 1/16*[1 2 1; 2 4 2 ; 1 2 1];%3.34(b)掩码

img1 = uint8(SpatialFiltering(img,mask));
subplot(1,2,1),imshow(img),title('原图');
subplot(1,2,2),imshow(img1),title('增强图像');
%imwrite(img1,"img1.tif");