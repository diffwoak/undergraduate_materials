function C = Arithmetic
    C.Addimage=@Addimage;
    C.Subimage=@Subimage;
    C.Mulimage=@Mulimage;
    C.Divimage=@Divimage;
end
function C = Addimage(A,B)
    C = A + B;
end
function C = Subimage(A,B)
    C = A - B;
end
function C = Mulimage(A,B)
    C = A.* B;
end
function C = Divimage(A,B)
    C = A./ B;
end