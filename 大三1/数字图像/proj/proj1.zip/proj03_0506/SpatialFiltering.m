function C = SpatialFiltering(input,mask)
    [h,w] = size(input);
    A = zeros(h+2,w+2);
    C = zeros(h,w);
    A(2:h+1,2:w+1) = input; 
    for i = 1:h
        for j = 1:w
            x = A(i:i+2,j:j+2);
            C(i,j) = sum(sum(x.*mask));
        end
    end
end

