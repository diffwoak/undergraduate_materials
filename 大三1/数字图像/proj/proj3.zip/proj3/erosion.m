function im1 = erosion(im)
[m,n] = size(im);
a=2;b=2;              %结构元素大小
S = false(a,b);        %结构元素
im1 = im;
%腐蚀
for i = 1:m-a+1
    for j = 1:n-b+1
        if (im(i:i+a-1,j:j+b-1))
        else
            im1(i:i+a-1,j:j+b-1) = S;
        end
    end
end

end