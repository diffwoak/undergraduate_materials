clear;
clc;
im = double(imread("6.png"));
[m,n,p] = size(im);
subplot(2,2,1),imshow(uint8(im)),title('原图');
%将图片转换到YCrCb颜色空间
Y = 0.299*im(:,:,1)+0.587*im(:,:,2)+0.114*im(:,:,3);
Cr = 0.713*(im(:,:,1)-Y)+128;
Cb = 0.564*(im(:,:,3)-Y)+128;
%取出142<Cr<175，100<Cb<120 的像素点
Cr(Cr(:,:)<=142|Cr(:,:)>=175) = 0;
Cb(Cb(:,:)<=100|Cb(:,:)>=120) = 0;
F = logical(Cr)&logical(Cb);
subplot(2,2,2),imshow(F),title('YCrCb空间筛选图');
%腐蚀
F = erosion(F);
subplot(2,2,3),imshow(F),title('腐蚀后');
%膨胀
F = dilation(F);
subplot(2,2,4),imshow(F),title('膨胀后');
%人脸识别
connComp = bwconncomp(F);%得到各连通部分
%得到连通部分的面积Area和中心位置Centroid
props = regionprops(connComp, 'Area', 'Centroid');
[maxArea, index] = max([props.Area]);
% 筛选连通最小面积
minArea = maxArea*0.7;
% 框的大小
hw = (maxArea)^(0.5);
figure;
imshow(uint8(im));
hold on;
for i = 1:length(props)
    if props(i).Area > minArea 
        rectangle('Position', [props(i).Centroid(1)-hw/2, props(i).Centroid(2)-hw/2, hw, hw], 'EdgeColor', 'r','LineWidth',1);
    end
end
hold off;

