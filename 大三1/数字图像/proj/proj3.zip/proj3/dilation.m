function im1 = dilation(im)
[m,n] = size(im);
a=3;b=3;              %结构元素大小
S = true(a,b);         %结构元素
im1 = im;
%膨胀
for i = 1:m-a+1
    for j = 1:n-b+1
        if max(im(i:i+a-1,j:j+b-1))==1
            im1(i:i+a-1,j:j+b-1) = S;
        end
    end
end

end