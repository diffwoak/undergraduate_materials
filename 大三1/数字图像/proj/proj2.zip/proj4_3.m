clear;
clc;
img = imread('4.18(a).tif');
img = rgb2gray(img);
% 指定截止频率为5、15、30、80、230
img1 = gaussian_lowpass(img,5);
img2 = gaussian_lowpass(img,15);
img3 = gaussian_lowpass(img,30);
img4 = gaussian_lowpass(img,80);
img5 = gaussian_lowpass(img,230);
subplot(3,2,1),imshow(uint8(img)),title('原图');
subplot(3,2,2),imshow(uint8(img1)),title('D0=5');
subplot(3,2,3),imshow(uint8(img2)),title('D0=15');
subplot(3,2,4),imshow(uint8(img3)),title('D0=30');
subplot(3,2,5),imshow(uint8(img4)),title('D0=80');
subplot(3,2,6),imshow(uint8(img5)),title('D0=230');