function img = gaussian_lowpass(img,D0)
[m,n] = size(img);
A = proj4_1;
% 得到高斯滤波
H = gaussian_fliter(m,n,D0);
% 图像 到 H(u,v)*F(u,v)结果
filt = A.filtering(img,H);
img = ifft2(filt);% 傅里叶反变换
img = A.handle(img);% 后处理
end