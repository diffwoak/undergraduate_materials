clear;
clc;
img = imread('4.18(a).tif');
img = rgb2gray(img);
[m,n] = size(img);
A = proj4_1;
% 计算频谱
s = A.spectrum(img);
% 对数变换
spec = log(1+s);
% 映射到0~255
spec = spec - min(min(spec));
spec = spec*255/max(max(spec));
imshow(uint8(spec));
% 计算图像平均值,对应直流分量F(0,0)
avg = s(int16(m+1)/2,int16(n+1)/2)/(m*n);
