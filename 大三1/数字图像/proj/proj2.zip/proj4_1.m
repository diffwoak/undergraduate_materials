function C = proj4_1
    C.centered = @centered;     %(-1)^(x+y)居中
    C.c_fft = @c_fft;           %(居中)快速傅里叶变换
    C.filtering = @filtering;   %与实数函数相乘
    C.handle = @handle;         %后处理：图像反居中取实部
    C.spectrum = @spectrum;     %由图像直接得到频谱
end

function C = centered(img)
    % 取实部，int16扩大到负数范围
    img = int16(real(img));
    [m,n] = size(img);
    %乘以(-1)^(x+y)
    for i = 1:m
        j = mod(i,2)+1;
        while j <= n
            img(i,j) = - img(i,j);
            j=j+2;
        end
    end
    C = img;
end
function C = c_fft(img)
    % 先居中再调用快速傅里叶变换
    img = centered(img);
    C = fft2(img);
end
function C = filtering(img,H)
    %变换后的图像与相同大小滤波器相乘
    imf = c_fft(img);
    C = imf.*H;
end
function C = handle(img)
    % 后处理
    % 取实部
    img1 = real(img);
    % 乘以(-1)^(x+y)
    C = centered(img1);
end
function C = spectrum(img)
    % 由图像到计算出频谱
    imf = c_fft(img);
    C = abs(imf);
end 

