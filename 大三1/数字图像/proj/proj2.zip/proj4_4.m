clear;
clc;
img = imread('4.18(a).tif');
img = int16(rgb2gray(img));

img1 = int16(gaussian_lowpass(img,15));
sharp_img1 = img-img1;
img2 = int16(gaussian_lowpass(img,30));
sharp_img2 = img-img2;
img3 = int16(gaussian_lowpass(img,80));
sharp_img3 = img-img3;

subplot(1,3,1),imshow(uint8(sharp_img1)),title('D0=15');
subplot(1,3,2),imshow(uint8(sharp_img2)),title('D0=30');
subplot(1,3,3),imshow(uint8(sharp_img3)),title('D0=80');

