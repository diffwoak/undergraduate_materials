function H = gaussian_fliter(m,n,D0)
H = zeros(m,n);
for i = 1:m
    for j = 1:n
        d = (i-m/2)^2+(j-n/2)^2;
        H(i,j) = exp(-d/2/D0^2);
    end
end
end