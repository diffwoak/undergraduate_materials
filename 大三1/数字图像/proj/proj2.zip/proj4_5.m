clear;
clc;
imga = imread('4.41(a).tif');imgb = imread('4.41(b).tif');
imga = rgb2gray(imga);imgb = rgb2gray(imgb);
A = proj4_1;
[m1,n1] = size(imga);[m2,n2] = size(imgb);
% 延拓
d = max(m1+m2,n1+n2);
imga1 = uint8(zeros(d,d));imgb1 = uint8(zeros(d,d));
imga1(1:m1,1:n1) = imga;imgb1(1:m2,1:n2) = imgb;
% (居中)快速傅里叶变换
imfa = A.c_fft(imga1);
imfb = A.c_fft(imgb1);
% 取模板b的复共轭
imfb1 = conj(imfb);
% 变换相乘 取反变换得到相关函数
imf = imfa.*imfb1;
img = abs(ifft2(imf));
% 缩放到0~255
img = img - min(min(img));
img = img*255/max(max(img));
imshow(uint8(img));
subplot(1,3,1),imshow(uint8(imga)),title('图a');
subplot(1,3,2),imshow(uint8(imgb)),title('图b');
subplot(1,3,3),imshow(uint8(img)),title('相关函数');
% 相关函数最大值位置x,y
[v1,y] = max(max(img));
[v2,x] = max(img(:,y));