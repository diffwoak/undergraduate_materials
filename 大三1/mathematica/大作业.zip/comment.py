import re
import requests
from bs4 import BeautifulSoup as BS
import pandas as pd
import os

def get_bilibili_comment(url,v_result_file):
    headers = {
        'authority': 'api.bilibili.com',
        'accept': '*/*',
        'accept-language': 'en,zh;q=0.9,zh-CN;q=0.8',
        'cookie': "buvid3=ED8FFA4F-A362-03A2-746D-437D9665CE6850094infoc; b_nut=1697939750; i-wanna-go-back=-1; b_ut=7; _uuid=13B374DD-FD710-DDCA-10316-1067554A8727F50075infoc; buvid_fp=737697a2c4c2b74d3b2a124c1ce7626d; enable_web_push=DISABLE; CURRENT_FNVAL=4048; rpdid=|(k|k)~~~u)~0J'uYm)lmkmYY; header_theme_version=CLOSE; home_feed_column=4; browser_resolution=1232-605; buvid4=C2F9AE5B-B5A2-54E5-05F8-B825AA1BEE9811258-022102923-GLR8k1fJ/XthseghSHpKsg==; DedeUserID=513135773; DedeUserID__ckMd5=960976c3dbbc6ebc; PVID=1; b_lsid=CA10D2196_18C0967D0E1; SESSDATA=bc4a7722,1716516849,9eeb2*b2CjCR3bSPhCsSx9DWvaaEZ-_QdJpwwuPjI85bTb0oj2yKO36fxmZUfWCfBBRzmxLKZokSVi1INmc1SUNNTzk4bmZwY2J3NkJXbGtGQms4bXpmbzlLbXlGb1NOZ0NPcTlpRTZKYkdNM295QzdpV3RtdmpWY19ac1JxNkVpUjlsNmhNUzlLVjhtVEdBIIEC; bili_jct=8cb773e3dbcc7ffc0fd782d3db4a9c97; sid=ft7c07aa",
        'origin': 'https://www.bilibili.com',
        'referer': 'https://www.bilibili.com/video/BV1yc411R7EF/?buvid=Z74247770D0AD00F429A99CA4727386ECD64&from_spmid=creation.hot-tab.0.0&is_story_h5=false&mid=VwGYrBvB2et1BaEm7O4kyQ==&p=1&plat_id=114&share_from=ugc&share_medium=iphone&share_plat=ios&share_session_id=17B9C029-8984-4B4C-B5BF-00C9A0D14FF1&share_source=WEIXIN&share_source=weixin&share_tag=s_i&spmid=united.player-video-detail.0.0&timestamp=1699580189&unique_k=WQ9431N&up_id=20165629&vd_source=6b153427393db22a222ff8aec7bb5efb',
        'sec-ch-ua': '"Google Chrome";v="111", "Not(A:Brand";v="8", "Chromium";v="111"',
        'sec-ch-ua-mobile': '?0',
        'sec-ch-ua-platform': '"Windows"',
        'sec-fetch-dest': 'empty',
        'sec-fetch-mode': 'cors',
        'sec-fetch-site': 'same-site',
        'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/111.0.0.0 Safari/537.36'
    }
    html = requests.get(url=url,headers=headers).text
    aid = re.findall('"aid":(.*?),',html)[0]
    n = 1
    num,comment_list,like_list,rcount_list = [],[],[],[]
    for i in range(100):
        com_url = "https://api.bilibili.com/x/v2/reply?jsonp=jsonp&pn="+str(i+1)+"&type=1&oid="+aid+"&sort=1&nohot=1"
        response = requests.get(url=com_url,headers=headers)
        data_list = response.json()['data']['replies']
        for a in data_list:
            num.append(n);n+=1
            comment_list.append(a['content']['message'])
            like_list.append(a['like'])
            rcount_list.append(a['rcount'])
    df = pd.DataFrame()
    df['序号'] = num
    df['评论内容'] = comment_list
    df['点赞数'] = like_list
    df['回复数'] = rcount_list
    if os.path.exists(v_result_file):
        header = None
    else:
        header = ['序号','评论内容','点赞数','回复数']
    df.to_csv(v_result_file,encoding='utf_8_sig',mode='a+',index=False,header=header)

if __name__ == "__main__":
    csv_file = '评论.csv'
    if os.path.exists(csv_file):
        print('{}已存在，删除文件'.format(csv_file))
        os.remove(csv_file)
        print('{}已删除文件'.format(csv_file))
    # 可输入多个的Bv号
    bv_list = ['BV16X4y1g7wT',]
    for bv in bv_list:
        get_bilibili_comment(url='https://www.bilibili.com/video/{}'.format(bv),v_result_file='评论.csv')
    print('执行结束')