import re
import requests
from bs4 import BeautifulSoup as BS
import pandas as pd
import os


def get_bilibili_danmu(url,v_result_file):
    headers = {'User-Agent':"Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko)",}
    html = requests.get(url=url,headers=headers).text
    cid = re.findall('"cid":(.*?),',html)[0]
    danmu_res = requests.get('http://comment.bilibili.com/{}.xml'.format(cid))
    danmu_html = danmu_res.text.encode('raw_unicode_escape')    # 编码格式
    danmu_list = BS(danmu_html,'lxml').find_all('d')
    print('共{}条弹幕'.format(len(danmu_list)))
    text_list = []
    for d in danmu_list:
        text_list.append(d.text)
    df = pd.DataFrame()
    df['弹幕内容'] = text_list
    if os.path.exists(v_result_file):
        header = None
    else:
        header = ['弹幕内容']
    df.to_csv(v_result_file,encoding='utf_8_sig',mode='a+',index=False,header=header)

if __name__ == "__main__":
    csv_file = '弹幕.csv'
    if os.path.exists(csv_file):
        print('{}已存在，删除文件'.format(csv_file))
        os.remove(csv_file)
        print('{}已删除文件'.format(csv_file))
    bv_list = ['BV16X4y1g7wT','BV1Nf4y1G7ZS','BV1kW4y1a75Z',]
    for bv in bv_list:
        get_bilibili_danmu(url='https://www.bilibili.com/video/{}'.format(bv),v_result_file='弹幕.csv')
    print('执行结束')